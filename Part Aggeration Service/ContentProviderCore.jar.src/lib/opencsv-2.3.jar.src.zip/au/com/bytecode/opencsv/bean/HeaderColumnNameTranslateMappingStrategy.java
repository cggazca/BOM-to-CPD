/*    */ package au.com.bytecode.opencsv.bean;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeaderColumnNameTranslateMappingStrategy<T>
/*    */   extends HeaderColumnNameMappingStrategy<T>
/*    */ {
/* 22 */   private Map<String, String> columnMapping = new HashMap<String, String>();
/*    */   protected String getColumnName(int col) {
/* 24 */     return (col < this.header.length) ? this.columnMapping.get(this.header[col].toUpperCase()) : null;
/*    */   }
/*    */   public Map<String, String> getColumnMapping() {
/* 27 */     return this.columnMapping;
/*    */   }
/*    */   public void setColumnMapping(Map<String, String> columnMapping) {
/* 30 */     for (String key : columnMapping.keySet())
/* 31 */       this.columnMapping.put(key.toUpperCase(), columnMapping.get(key)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\opencsv-2.3.jar!\au\com\bytecode\opencsv\bean\HeaderColumnNameTranslateMappingStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */