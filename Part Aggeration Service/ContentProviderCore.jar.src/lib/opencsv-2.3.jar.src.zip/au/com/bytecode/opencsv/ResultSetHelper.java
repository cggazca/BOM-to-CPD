package au.com.bytecode.opencsv;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultSetHelper {
  String[] getColumnNames(ResultSet paramResultSet) throws SQLException;
  
  String[] getColumnValues(ResultSet paramResultSet) throws SQLException, IOException;
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\opencsv-2.3.jar!\au\com\bytecode\opencsv\ResultSetHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */