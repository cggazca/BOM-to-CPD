/*    */ package au.com.bytecode.opencsv.bean;
/*    */ 
/*    */ import au.com.bytecode.opencsv.CSVReader;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnPositionMappingStrategy<T>
/*    */   extends HeaderColumnNameMappingStrategy<T>
/*    */ {
/* 24 */   private String[] columnMapping = new String[0];
/*    */   
/*    */   public void captureHeader(CSVReader reader) throws IOException {}
/*    */   
/*    */   protected String getColumnName(int col) {
/* 29 */     return (null != this.columnMapping && col < this.columnMapping.length) ? this.columnMapping[col] : null;
/*    */   }
/*    */   public String[] getColumnMapping() {
/* 32 */     return (this.columnMapping != null) ? (String[])this.columnMapping.clone() : null;
/*    */   }
/*    */   public void setColumnMapping(String[] columnMapping) {
/* 35 */     this.columnMapping = (columnMapping != null) ? (String[])columnMapping.clone() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\opencsv-2.3.jar!\au\com\bytecode\opencsv\bean\ColumnPositionMappingStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */