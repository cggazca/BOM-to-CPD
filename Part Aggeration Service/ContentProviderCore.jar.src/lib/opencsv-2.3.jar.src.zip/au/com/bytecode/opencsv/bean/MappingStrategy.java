package au.com.bytecode.opencsv.bean;

import au.com.bytecode.opencsv.CSVReader;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.IOException;

public interface MappingStrategy<T> {
  PropertyDescriptor findDescriptor(int paramInt) throws IntrospectionException;
  
  T createBean() throws InstantiationException, IllegalAccessException;
  
  void captureHeader(CSVReader paramCSVReader) throws IOException;
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\opencsv-2.3.jar!\au\com\bytecode\opencsv\bean\MappingStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */