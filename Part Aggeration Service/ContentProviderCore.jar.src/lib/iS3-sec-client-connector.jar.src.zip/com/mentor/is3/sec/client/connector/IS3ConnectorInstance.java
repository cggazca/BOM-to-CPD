/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.client.connector.exceptions.ConnectorBaseException;
/*     */ import com.mentor.is3.sec.common.CommonConnectionUtils;
/*     */ import com.mentor.is3.sec.common.ReloadableX509TrustManager;
/*     */ import com.mentor.is3.sec.server.api.sysconfig.SysConfigServiceRemote;
/*     */ import com.mentor.is3.server.api.adminsession.GetSessionStatusRequest;
/*     */ import com.mentor.is3.server.api.adminsession.GetSessionStatusResponse;
/*     */ import com.mentor.is3.server.api.adminsession.heartbeat.SessionHeartbeatTracker;
/*     */ import com.mentor.is3.server.api.adminsession.heartbeat.SessionHeartbeatTrackerRemote;
/*     */ import com.mentor.is3.server.api.adminsession.heartbeat.UnregisterHeartbeatRequest;
/*     */ import com.mentor.is3.server.api.config.ConfigRemoteException;
/*     */ import com.mentor.is3.server.api.config.ConfigServiceRemote;
/*     */ import com.mentor.is3.server.api.frontcontroller.AbstractRequest;
/*     */ import com.mentor.is3.server.api.frontcontroller.FrontController;
/*     */ import com.mentor.is3.server.api.frontcontroller.FrontControllerRemote;
/*     */ import com.mentor.is3.server.api.frontcontroller.FrontControllerStateful;
/*     */ import com.mentor.is3.server.api.internationalization.MessageProvider;
/*     */ import com.mentor.is3.server.api.internationalization.MessageProviderRemote;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.LogoutResultValue;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.SessionTokenTO;
/*     */ import com.mentor.is3.server.api.utils.PasswordResetStatus;
/*     */ import jakarta.jms.JMSException;
/*     */ import jakarta.jms.Queue;
/*     */ import jakarta.jms.QueueConnection;
/*     */ import jakarta.jms.Topic;
/*     */ import jakarta.jms.TopicConnection;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URL;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.activemq.artemis.api.core.TransportConfiguration;
/*     */ import org.apache.activemq.artemis.core.client.impl.ServerLocatorImpl;
/*     */ import org.apache.activemq.artemis.core.protocol.core.impl.PacketImpl;
/*     */ import org.apache.activemq.artemis.jms.client.ActiveMQDestination;
/*     */ import org.apache.activemq.artemis.jms.client.ActiveMQJMSConnectionFactory;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3ConnectorInstance
/*     */ {
/*  69 */   static Logger log = Logger.getLogger(IS3ConnectorInstance.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IS3Connection currentConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IS3SessionIdentity sessionIdentity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IS3ConnectionProperties connectionProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClusterNodeDiscovery clusterNodeDiscovery;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3SessionIdentity connect(IS3ConnectionProperties props) throws ConfigRemoteException, Exception {
/* 117 */     return connect(props, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3SessionIdentity connect(IS3ConnectionProperties props, boolean isBatch) throws ConfigRemoteException, Exception {
/* 123 */     log.debugf("Connecting to iS3 using properties %s", props);
/* 124 */     if (this.currentConnection != null) {
/* 125 */       throw new RuntimeException("Must first disconnect before connecting again.");
/*     */     }
/* 127 */     this.connectionProperties = props;
/* 128 */     IS3Connection userConn = null;
/* 129 */     SessionTokenTO sessionToken = null;
/*     */     try {
/* 131 */       userConn = IS3ConnectorHelper.connect(props, isBatch);
/* 132 */       log.debug("Connecting as: " + props.getUser());
/* 133 */       FrontController fc = lookupFrontController();
/* 134 */       log.debug("Retrieved remote reference to FrontController: " + String.valueOf(fc));
/* 135 */       String port = "";
/* 136 */       if (props.isSSLUsed()) {
/* 137 */         port = props.getHttpsPort();
/*     */       } else {
/*     */         
/* 140 */         port = props.getWebPort();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 146 */       if (props.hasLoadBalncer()) {
/* 147 */         port = props.getBalancerPort();
/* 148 */         if (this.clusterNodeDiscovery == null) {
/* 149 */           this.clusterNodeDiscovery = new ClusterNodeDiscovery(props.getHost(), port, props.getWebPort(), props.isSSLUsed());
/*     */         }
/* 151 */         this.clusterNodeDiscovery.startDiscovery();
/*     */       } 
/*     */       
/* 154 */       log.debug("starting login from machine: " + props.getMachineId());
/* 155 */       sessionToken = IS3ConnectorHelper.logIn(fc, props.getMachineId(), new String(props.getPassword()), props.getHost(), port, props
/* 156 */           .getMachineName(), props.isNoSessionCheck(), props.getAuthMethod());
/* 157 */       log.debug("Logged in as " + props.getUser() + " and retrieved session token " + IS3ConnectorHelper.toString(sessionToken));
/* 158 */     } catch (Exception e) {
/* 159 */       log.debug("Caught and throwing exception of type: " + e.getClass().getName() + ", message: " + e.getMessage());
/* 160 */       throw e;
/*     */     } finally {
/*     */       
/* 163 */       if (userConn != null) {
/* 164 */         userConn.close();
/* 165 */         log.debug("User Connection closed");
/*     */       } 
/*     */     } 
/*     */     
/* 169 */     if (sessionToken.getPasswordResetStatus() == PasswordResetStatus.NONE) {
/* 170 */       log.debug("Password reset status is NONE. It does not need to be changed.");
/* 171 */       IS3ConnectionProperties sessProps = IS3ConnectionProperties.create(sessionToken.getSessionToken(), sessionToken
/* 172 */           .getPassword().toCharArray(), props);
/* 173 */       this.currentConnection = IS3ConnectorHelper.connect(sessProps, isBatch);
/* 174 */       this.connectionProperties = sessProps;
/* 175 */       log.debug("Connected with sessionToken: " + IS3ConnectorHelper.toString(sessionToken));
/* 176 */       updateTrustStore(lookupFrontController(), sessProps);
/*     */     } 
/* 178 */     this
/* 179 */       .sessionIdentity = new IS3SessionIdentity(sessionToken.getSessionToken(), sessionToken.getPassword().toCharArray(), Integer.valueOf(sessionToken.getId()));
/* 180 */     this.sessionIdentity.setSessionToken(sessionToken);
/*     */     
/* 182 */     return this.sessionIdentity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3SessionIdentity connectAsSessionUser(IS3ConnectionProperties sessProps) {
/* 194 */     return connectAsSessionUser(sessProps, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IS3SessionIdentity connectAsSessionUser(IS3ConnectionProperties sessProps, boolean isBatch) {
/* 199 */     this.currentConnection = IS3ConnectorHelper.connect(sessProps, isBatch);
/* 200 */     this.connectionProperties = sessProps;
/* 201 */     log.debug("Connecting as %s" + sessProps.getUser());
/* 202 */     FrontController fc = lookupFrontController();
/* 203 */     GetSessionStatusResponse res = (GetSessionStatusResponse)fc.execute((AbstractRequest)new GetSessionStatusRequest());
/* 204 */     if (res.getSessionToken() == null) {
/* 205 */       log.debug("Session " + String.valueOf(res.getSessionToken()) + " has already expired");
/* 206 */       closeConnection();
/* 207 */       IS3ConnectorHelper.handleException(new LoginException("Session expired"));
/*     */     } 
/* 209 */     updateTrustStore(fc, sessProps);
/* 210 */     this.sessionIdentity = new IS3SessionIdentity(sessProps.getUser(), sessProps.getPassword(), Integer.valueOf(res.getSessionToken().getId()));
/* 211 */     this.sessionIdentity.setSessionToken(res.getSessionToken());
/* 212 */     log.debug("logged in with session: " + String.valueOf(this.sessionIdentity));
/* 213 */     return this.sessionIdentity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() throws ConfigRemoteException, Exception {
/* 226 */     disconnect(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect(boolean force) throws ConfigRemoteException, Exception {
/* 241 */     log.debug("Disconnecting from iS3, force: " + force);
/* 242 */     FrontController fc = lookupFrontController();
/* 243 */     log.debug("Retrieved remote reference to FrontController" + String.valueOf(fc));
/* 244 */     IS3ConnectorHelper.logout(fc, force);
/* 245 */     log.debug("Logged out");
/* 246 */     closeConnection();
/* 247 */     log.debug("Disconnected from iS3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutResultValue disconnect(boolean force, BeforeLogoutCallback beforeLogoutCallback) throws ConfigRemoteException, Exception {
/* 266 */     log.debug("Disconnecting from iS3");
/* 267 */     FrontController fc = lookupFrontController();
/* 268 */     if (this.clusterNodeDiscovery != null) {
/* 269 */       this.clusterNodeDiscovery.stopDiscovery();
/* 270 */       this.clusterNodeDiscovery = null;
/*     */     } 
/* 272 */     log.debug("Retrieved remote reference to FrontController" + String.valueOf(fc));
/* 273 */     LogoutResultValue result = null;
/* 274 */     if (!force) {
/* 275 */       log.debug("Sending preLogout request");
/* 276 */       LogoutResultValue logoutResult = IS3ConnectorHelper.prelogout(fc);
/* 277 */       log.debug("Prelogout received status: " + String.valueOf(logoutResult));
/* 278 */       if (logoutResult == LogoutResultValue.OK) {
/* 279 */         result = handleLogout(fc, false, beforeLogoutCallback);
/*     */       } else {
/*     */         
/* 282 */         result = logoutResult;
/*     */       } 
/*     */     } else {
/*     */       
/* 286 */       result = handleLogout(fc, true, beforeLogoutCallback);
/*     */     } 
/* 288 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private LogoutResultValue handleLogout(FrontController fc, boolean force, BeforeLogoutCallback beforeLogoutCallback) {
/*     */     LogoutResultValue result;
/*     */     try {
/* 295 */       if (beforeLogoutCallback != null) {
/* 296 */         log.debug("Invoking beforeLogout method from callback");
/* 297 */         beforeLogoutCallback.beforeLogout();
/*     */       }
/*     */     
/* 300 */     } catch (Throwable t) {
/* 301 */       log.error("Exception caught during \"beforeLogout\" method invokation.", t);
/*     */     } finally {
/*     */       
/* 304 */       log.debug("Logging out...");
/* 305 */       result = IS3ConnectorHelper.logout(fc, force);
/* 306 */       log.debug("Logged out");
/* 307 */       closeConnection();
/* 308 */       log.debug("Disconnected from iS3");
/*     */     } 
/* 310 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeConnection() {
/* 317 */     if (this.currentConnection != null) {
/* 318 */       this.currentConnection.close();
/* 319 */       this.currentConnection = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 329 */     return (this.currentConnection != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConnectedAndNotClosed() {
/* 337 */     if (this.currentConnection == null || this.connectionProperties == null) {
/* 338 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 342 */       String url = getConnectionUrl();
/* 343 */       NetworkUtils.getServerConfForInput(url);
/* 344 */       return true;
/* 345 */     } catch (UnknownHostException e) {
/*     */       
/* 347 */       return false;
/* 348 */     } catch (ConnectorBaseException e) {
/*     */       
/* 350 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <Svc> Svc lookupService(String moduleName, String beanName, Class<Svc> serviceInterface) {
/* 371 */     Object remoteRef = IS3ConnectorHelper.lookupRemoteEjb(moduleName, beanName, serviceInterface.getName(), this.connectionProperties);
/* 372 */     return (Svc)remoteRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <Svc> Svc lookupCoreStatefulService(String beanName, Class<Svc> serviceInterface) {
/* 390 */     Object remoteRef = IS3ConnectorHelper.lookupRemoteEjb("is3-server-ejb", beanName, serviceInterface
/* 391 */         .getName() + "?stateful", this.connectionProperties);
/* 392 */     return (Svc)remoteRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <Svc> Svc lookupCoreService(String beanName, Class<Svc> serviceInterface) {
/* 410 */     return lookupService("is3-server-ejb", beanName, serviceInterface);
/*     */   }
/*     */   
/*     */   public <Svc> Svc lookupSecService(String beanName, Class<Svc> serviceInterface) {
/* 414 */     return lookupService("iS3-sec-server", beanName, serviceInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrontController lookupFrontController() {
/* 425 */     return (FrontController)lookupCoreService("FrontControllerBean", FrontControllerRemote.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrontControllerStateful lookupFrontControllerStateful() {
/* 436 */     return lookupCoreStatefulService("FrontControllerStatefulBean", FrontControllerStateful.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageProvider lookupMessageProvider() {
/* 448 */     return (MessageProvider)lookupCoreService("InternationalizationBean", MessageProviderRemote.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionHeartbeatTracker lookupSessionHeartbeatTracker() {
/* 459 */     return (SessionHeartbeatTracker)lookupCoreService("SessionHeartbeatTrackingBean", SessionHeartbeatTrackerRemote.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigServiceRemote lookupConfigService() {
/* 470 */     return lookupCoreService("RemoteConfigBean", ConfigServiceRemote.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SysConfigServiceRemote lookupSysConfigService() {
/* 480 */     return lookupSecService("SysConfigRemoteBean", SysConfigServiceRemote.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3SessionIdentity getSessionIdentity() {
/* 489 */     return this.sessionIdentity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Queue createQueue(String queueName) {
/* 503 */     String queueAddress = String.format("%s%s", new Object[] { PacketImpl.OLD_QUEUE_PREFIX, queueName });
/* 504 */     log.debug(String.format("creating queue: [name = %s] [address = %s]", new Object[] { queueName, queueAddress }));
/* 505 */     return (Queue)ActiveMQDestination.createQueue(queueAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Topic createTopic(String topicName) {
/* 519 */     String topicAddress = String.format("%s%s", new Object[] { PacketImpl.OLD_TOPIC_PREFIX, topicName });
/* 520 */     log.debug(String.format("creating topic: [name = %s] [address = %s]", new Object[] { topicName, topicAddress }));
/* 521 */     return (Topic)ActiveMQDestination.createTopic(topicAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueueConnection createQueueConnection() throws JMSException {
/* 532 */     log.debug("Creating queue connection as session token user: " + this.sessionIdentity.getTokenId());
/* 533 */     ActiveMQJMSConnectionFactory connectionFactory = getJMSConnectionFactory();
/* 534 */     return connectionFactory.createQueueConnection(this.sessionIdentity.getTokenId(), this.sessionIdentity.getPasswordAsString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueueConnection createQueueConnection(boolean useReconnection) throws JMSException {
/* 556 */     QueueConnection queueConnection = (useReconnection == true) ? createQueueConnection(-1, 1048576, 7200000L) : createQueueConnection();
/* 557 */     return queueConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueueConnection createQueueConnection(int reconnectAttempts, int confirmationWindowSize, long connectionTTL) throws JMSException {
/* 574 */     log.debug("Creating queue connection with reconnection (attempts = " + reconnectAttempts + ", windowSize = " + confirmationWindowSize + ", ttl = " + connectionTTL + "), as session token user: " + this.sessionIdentity
/*     */         
/* 576 */         .getTokenId());
/* 577 */     ActiveMQJMSConnectionFactory connectionFactory = getJMSConnectionFactory();
/*     */ 
/*     */     
/* 580 */     connectionFactory.setReconnectAttempts(reconnectAttempts);
/* 581 */     connectionFactory.setConfirmationWindowSize(confirmationWindowSize);
/* 582 */     connectionFactory.setConnectionTTL(connectionTTL);
/* 583 */     return connectionFactory.createQueueConnection(this.sessionIdentity.getTokenId(), this.sessionIdentity.getPasswordAsString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TopicConnection createTopicConnection() throws JMSException {
/* 595 */     log.debug("Creating topic connection as session token user: " + this.sessionIdentity.getTokenId());
/* 596 */     ActiveMQJMSConnectionFactory connectionFactory = getJMSConnectionFactory();
/* 597 */     return connectionFactory.createTopicConnection(this.sessionIdentity.getTokenId(), this.sessionIdentity.getPasswordAsString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3ConnectionProperties getConnectionProperties() {
/* 606 */     return this.connectionProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getConnectionUrl() {
/* 614 */     String prefix = "http://";
/* 615 */     String host = this.connectionProperties.getHost();
/* 616 */     String port = this.connectionProperties.getWebPort();
/* 617 */     if (this.connectionProperties.isSSLUsed()) {
/* 618 */       prefix = "https://";
/* 619 */       port = this.connectionProperties.getHttpsPort();
/*     */     } 
/* 621 */     return prefix + prefix + ":" + host;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void changePassword(IS3ConnectionProperties props, Integer userId, char[] oldPassword, char[] newPassword) throws Exception {
/*     */     try {
/* 628 */       FrontController fc = lookupFrontController();
/* 629 */       log.debug("Retrieved remote reference to FrontController: " + String.valueOf(fc));
/* 630 */       IS3ConnectorHelper.changePassword(fc, userId, oldPassword, newPassword);
/*     */     }
/* 632 */     catch (Exception e) {
/* 633 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3ConnectionDescriptor getCurrentConnectionDescriptor(String url) throws Exception {
/* 649 */     if (this.currentConnection == null) {
/* 650 */       throw new Exception("Not connected. Must first create iS3 session.");
/*     */     }
/* 652 */     URL serverUrl = new URL(String.format("%s/%s", new Object[] { this.connectionProperties.getHttpUrl(), url }));
/* 653 */     return new IS3ConnectionDescriptor(this.connectionProperties.getUser(), new String(this.connectionProperties.getPassword()), serverUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterHeartbeat(String applicationUuid, String sessionToken) {
/* 659 */     if (this.currentConnection != null) {
/*     */       
/*     */       try {
/* 662 */         FrontController fc = lookupFrontController();
/* 663 */         if (log.isDebugEnabled())
/* 664 */           log.debug("Using frontController: " + String.valueOf(fc)); 
/* 665 */         fc.execute((AbstractRequest)new UnregisterHeartbeatRequest(applicationUuid, sessionToken));
/*     */       }
/* 667 */       catch (Throwable e) {
/*     */         
/* 669 */         if (log.isDebugEnabled())
/*     */         {
/* 671 */           log.debug("unregisterHeartbeat failed. Reason :" + String.valueOf(e), e);
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 676 */     else if (log.isDebugEnabled()) {
/* 677 */       log.debug("unregisterHeartbeat: disconnected");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTrustStore(FrontController fc, IS3ConnectionProperties props) {
/* 684 */     if (props.isSSLUsed()) {
/*     */       
/* 686 */       log.debug("starting SSL truststore update");
/* 687 */       if (fc == null) {
/* 688 */         fc = lookupFrontController();
/*     */       }
/*     */       try {
/* 691 */         ReloadableX509TrustManager trustManager = SSLConnectionCheckCache.getInstance().getSslTrustManager();
/* 692 */         CommonConnectionUtils.updateTruststore(trustManager, fc);
/* 693 */       } catch (Exception e) {
/* 694 */         if (log.isDebugEnabled()) {
/* 695 */           log.debug("Caught exception of type " + e.getClass().getName() + ": " + e.getMessage());
/*     */         }
/* 697 */         log.error("Failed to reload trust manager");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ReloadableX509TrustManager getReloadableTrustManager() {
/* 704 */     return SSLConnectionCheckCache.getInstance().getSslTrustManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties getCommonProps() throws JMSException {
/* 721 */     Properties props = new Properties();
/* 722 */     props.put("java.naming.factory.initial", "org.wildfly.naming.client.WildFlyInitialContextFactory");
/*     */     
/* 724 */     props.put("java.naming.factory.url.pkgs", "org.jboss.ejb.client.naming");
/*     */ 
/*     */     
/* 727 */     if (this.connectionProperties.isSSLUsed()) {
/*     */       
/* 729 */       String enabledProtocol = "TLSv1.2";
/* 730 */       log.debug("setting up SSL properties with protocol: " + enabledProtocol);
/* 731 */       props.put("java.naming.provider.url", this.connectionProperties.gethttpsProviderUrl());
/* 732 */       props.put("jboss.naming.client.remote.connectionprovider.create.options.org.xnio.Options.SSL_ENABLED", "true");
/* 733 */       props.put("jboss.naming.client.connect.options.org.xnio.Options.SSL_STARTTLS", "true");
/*     */ 
/*     */       
/*     */       try {
/* 737 */         String enabledCipher = SSLConnectionCheckCache.getInstance().getSSLPortCheckObject(this.connectionProperties.getHost(), Integer.parseInt(this.connectionProperties.getHttpsPort())).getServerCipher();
/* 738 */         if (enabledCipher != null && !enabledCipher.isEmpty()) {
/* 739 */           log.debug("set cipherSuite to " + enabledCipher);
/* 740 */           props.put("jboss.naming.client.connect.options.org.xnio.Options.SSL_ENABLED_CIPHER_SUITES", enabledCipher);
/*     */         } 
/* 742 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 745 */       props.put("jboss.naming.client.connect.options.org.xnio.Options.SSL_ENABLED_PROTOCOLS", enabledProtocol);
/*     */       
/*     */       try {
/* 748 */         ReloadableX509TrustManager reloadableX509TrustManager = SSLConnectionCheckCache.getInstance().getSslTrustManager();
/* 749 */         KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
/* 750 */         ks.load(null, null);
/*     */         
/* 752 */         X509Certificate[] trustedCerts = reloadableX509TrustManager.getAcceptedIssuers();
/* 753 */         for (int i = 0; i < trustedCerts.length; i++) {
/* 754 */           String name = "trustedCert_" + i;
/* 755 */           ks.setCertificateEntry(name, trustedCerts[i]);
/*     */         } 
/*     */         
/* 758 */         File file = File.createTempFile("tmptruststore", "jks");
/* 759 */         file.deleteOnExit();
/* 760 */         String pw = "changeit";
/* 761 */         ks.store(new FileOutputStream(file), pw.toCharArray());
/*     */         
/* 763 */         System.setProperty("org.apache.activemq.ssl.trustStore", file.getAbsolutePath());
/* 764 */         System.setProperty("org.apache.activemq.ssl.trustStorePassword", pw);
/*     */       }
/* 766 */       catch (Exception e) {
/* 767 */         log.debug("Caught exception of type " + e.getClass().getName() + ": " + e.getMessage());
/* 768 */         throw new JMSException(e.getMessage());
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 773 */       log.debug("setting up non-SSL properties");
/* 774 */       if (this.connectionProperties.hasLoadBalncer()) {
/* 775 */         String serverurls = this.clusterNodeDiscovery.gethttpProviderUrls();
/* 776 */         if (serverurls.isEmpty()) {
/* 777 */           serverurls = this.connectionProperties.gethttpProviderUrls();
/*     */         }
/* 779 */         props.put("java.naming.provider.url", serverurls);
/*     */       } else {
/* 781 */         props.put("java.naming.provider.url", this.connectionProperties.gethttpProviderUrl());
/*     */       } 
/* 783 */       props.put("jboss.naming.client.remote.connectionprovider.create.options.org.xnio.Options.SSL_ENABLED", "false");
/* 784 */       props.put("jboss.naming.client.connect.options.org.xnio.Options.SSL_STARTTLS", "false");
/* 785 */       props.put("jboss.naming.client.connect.options.org.xnio.Options.SASL_POLICY_NOPLAINTEXT", "false");
/*     */     } 
/* 787 */     props.put("java.naming.security.principal", this.sessionIdentity.getTokenId());
/* 788 */     props.put("java.naming.security.credentials", this.sessionIdentity.getPasswordAsString());
/* 789 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ActiveMQJMSConnectionFactory getJMSConnectionFactory() throws JMSException {
/* 813 */     return getJMSConnectionFactory(-1, 1048576, 1860000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ActiveMQJMSConnectionFactory getJMSConnectionFactory(int reconnectAttempts, int confirmationWindowSize, long connectionTTL) throws JMSException {
/* 840 */     ActiveMQJMSConnectionFactory connectionFactory = null;
/* 841 */     Properties props = getCommonProps();
/*     */     try {
/* 843 */       log.debug("starting");
/* 844 */       Context ctx = new InitialContext(props);
/* 845 */       connectionFactory = (ActiveMQJMSConnectionFactory)ctx.lookup("jms/RemoteConnectionFactory");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 850 */       ServerLocatorImpl sl = (ServerLocatorImpl)connectionFactory.getServerLocator();
/* 851 */       Field initialConnectorsField = ServerLocatorImpl.class.getDeclaredField("initialConnectors");
/* 852 */       initialConnectorsField.setAccessible(true);
/* 853 */       TransportConfiguration[] initialConnectors = (TransportConfiguration[])initialConnectorsField.get(sl);
/* 854 */       if (!this.connectionProperties.hasLoadBalncer()) {
/* 855 */         initialConnectors[0].getParams().put("host", this.connectionProperties
/* 856 */             .getServerHost());
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 863 */     catch (Exception e) {
/* 864 */       log.debug("Caught exception of type " + e.getClass().getName() + ": " + e.getMessage());
/* 865 */       throw new JMSException("Failed to Create HornetQJMSConnectionFactory Factory. " + e.getLocalizedMessage());
/*     */     } 
/* 867 */     connectionFactory.setReconnectAttempts(reconnectAttempts);
/* 868 */     connectionFactory.setConfirmationWindowSize(confirmationWindowSize);
/* 869 */     connectionFactory.setConnectionTTL(connectionTTL);
/* 870 */     return connectionFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3ConnectorInstance.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */