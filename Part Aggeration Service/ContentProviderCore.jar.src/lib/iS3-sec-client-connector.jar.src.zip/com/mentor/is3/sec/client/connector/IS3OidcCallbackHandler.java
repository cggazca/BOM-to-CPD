/*    */ package com.mentor.is3.sec.client.connector;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IS3OidcCallbackHandler
/*    */   implements CallbackHandler
/*    */ {
/*    */   private String username;
/*    */   private String password;
/*    */   
/*    */   public IS3OidcCallbackHandler(String username, String password) {
/* 25 */     this.username = username;
/* 26 */     this.password = password;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 32 */     for (Callback callback : callbacks) {
/*    */       
/* 34 */       if (callback instanceof PasswordCallback) {
/*    */         
/* 36 */         PasswordCallback pc = (PasswordCallback)callback;
/* 37 */         pc.setPassword(this.password.toCharArray());
/*    */       }
/* 39 */       else if (callback instanceof NameCallback) {
/*    */         
/* 41 */         NameCallback nc = (NameCallback)callback;
/* 42 */         nc.setName(this.username);
/*    */       }
/*    */       else {
/*    */         
/* 46 */         throw new UnsupportedCallbackException(callback, "Unrecognized callback in IS3OidcCallbackHandler");
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3OidcCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */