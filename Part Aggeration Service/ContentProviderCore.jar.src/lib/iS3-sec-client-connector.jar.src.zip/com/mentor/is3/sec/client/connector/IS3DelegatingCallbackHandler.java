/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.client.utils.BrowserCommunicator;
/*     */ import com.mentor.is3.sec.client.utils.SamlBrowserCommunicator;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.security.AuthOptionKey;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3DelegatingCallbackHandler
/*     */   implements CallbackHandler
/*     */ {
/*  27 */   private static final Logger logger = Logger.getLogger(IS3DelegatingCallbackHandler.class);
/*     */ 
/*     */   
/*     */   private CallbackHandler realCallbackHandler;
/*     */ 
/*     */   
/*     */   public IS3DelegatingCallbackHandler(IS3ConnectionProperties is3ConnectionProperties, boolean isBatch) throws IOException {
/*  34 */     this
/*  35 */       .realCallbackHandler = new IS3CallbackHandler(is3ConnectionProperties.getUser(), is3ConnectionProperties.getPassword());
/*     */     
/*  37 */     if (is3ConnectionProperties.getAuthMethod() == AuthOptionKey.KERBEROS_AUTH) {
/*     */ 
/*     */ 
/*     */       
/*  41 */       System.getProperties().setProperty("javax.security.auth.useSubjectCredsOnly", "false");
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  46 */         String user = is3ConnectionProperties.getUser();
/*  47 */         UUID.fromString(user);
/*     */         
/*  49 */         if (logger.isDebugEnabled()) {
/*  50 */           logger.debug("IS3DelegatingCallbackHandler - " + AuthOptionKey.KERBEROS_AUTH.getName() + " - will use IS3CallbackHandler");
/*     */         }
/*  52 */       } catch (IllegalArgumentException e) {
/*  53 */         if (logger.isDebugEnabled()) {
/*  54 */           logger.debug("IS3DelegatingCallbackHandler - " + AuthOptionKey.KERBEROS_AUTH.getName() + " - will use IS3KrbCallbackHandler");
/*     */         }
/*     */         
/*  57 */         String username = is3ConnectionProperties.getUser();
/*  58 */         String server = is3ConnectionProperties.getHost();
/*  59 */         this.realCallbackHandler = new IS3KrbCallbackHandler(username, server);
/*     */ 
/*     */         
/*  62 */         if (!SystemTokenUtils.isWinAuthAvailable() && 
/*  63 */           !SystemTokenUtils.hasValidTicketInCache(username)) {
/*  64 */           String error = "Login failed. Please run kinit and restart the application.";
/*  65 */           if (logger.isDebugEnabled()) {
/*  66 */             logger.debug("IS3DelegatingCallbackHandler - " + error);
/*     */           }
/*  68 */           throw new IOException(error);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*  73 */     } else if (is3ConnectionProperties.getAuthMethod() == AuthOptionKey.OIDC_AUTH) {
/*     */       
/*  75 */       String username = is3ConnectionProperties.getUser();
/*     */ 
/*     */       
/*     */       try {
/*  79 */         UUID.fromString(username);
/*     */         
/*  81 */         if (logger.isDebugEnabled()) {
/*  82 */           logger.debug("IS3DelegatingCallbackHandler - " + AuthOptionKey.OIDC_AUTH.getName() + " - will use IS3CallbackHandler due to finding a session");
/*     */         }
/*  84 */       } catch (IllegalArgumentException e) {
/*  85 */         logger.info("Starting OIDC authentication flow for user.");
/*  86 */         BrowserCommunicator browserCommunicator = new BrowserCommunicator();
/*  87 */         Map<String, String> result = browserCommunicator.getUsernameAndIdToken(is3ConnectionProperties.getServerUrl(), is3ConnectionProperties.getOidcClientId(), is3ConnectionProperties.getOidcAuthEndpoint());
/*  88 */         logger.debug("OIDC credentials retrieved for user: " + (String)result.get("username") + ". Proceeding with token verification.");
/*  89 */         this.realCallbackHandler = new IS3OidcCallbackHandler(result.get("username"), result.get("idToken"));
/*     */       } 
/*  91 */     } else if (is3ConnectionProperties.getAuthMethod() == AuthOptionKey.SAML_AUTH) {
/*     */       
/*  93 */       String username = is3ConnectionProperties.getUser();
/*     */ 
/*     */       
/*     */       try {
/*  97 */         UUID.fromString(username);
/*     */         
/*  99 */         if (logger.isDebugEnabled()) {
/* 100 */           logger.debug("IS3DelegatingCallbackHandler - " + AuthOptionKey.SAML_AUTH.getName() + " - will use IS3CallbackHandler due to finding a session");
/*     */         }
/*     */       }
/* 103 */       catch (IllegalArgumentException e) {
/*     */         
/* 105 */         SamlBrowserCommunicator samlBrowserCommunicator = new SamlBrowserCommunicator(isBatch);
/* 106 */         samlBrowserCommunicator
/* 107 */           .extractSamlResponseAndUsernameFromBrowser(is3ConnectionProperties.getServerUrl());
/* 108 */         String samlResponseBody = samlBrowserCommunicator.getSamlResponseBody();
/* 109 */         username = samlBrowserCommunicator.getUsername();
/*     */         
/* 111 */         this.realCallbackHandler = new IS3SamlCallbackHandler(username, samlResponseBody);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 118 */     this.realCallbackHandler.handle(callbacks);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3DelegatingCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */