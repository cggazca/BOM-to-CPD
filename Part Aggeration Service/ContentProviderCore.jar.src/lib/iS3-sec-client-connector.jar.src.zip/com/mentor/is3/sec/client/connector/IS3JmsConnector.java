/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import jakarta.jms.JMSException;
/*     */ import jakarta.jms.Queue;
/*     */ import jakarta.jms.QueueConnection;
/*     */ import jakarta.jms.QueueConnectionFactory;
/*     */ import jakarta.jms.Topic;
/*     */ import jakarta.jms.TopicConnection;
/*     */ import jakarta.jms.TopicConnectionFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.activemq.artemis.api.core.TransportConfiguration;
/*     */ import org.apache.activemq.artemis.api.jms.ActiveMQJMSClient;
/*     */ import org.apache.activemq.artemis.api.jms.JMSFactoryType;
/*     */ import org.apache.activemq.artemis.core.remoting.impl.netty.NettyConnectorFactory;
/*     */ import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3JmsConnector
/*     */ {
/*  38 */   private static final Logger log = Logger.getLogger(IS3JmsConnector.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Queue createQueue(String queueName) {
/*  49 */     log.debug("Create queue: " + queueName);
/*  50 */     return ActiveMQJMSClient.createQueue(queueName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Topic createTopic(String topicName) {
/*  62 */     log.debug("Create topic: " + topicName);
/*  63 */     return ActiveMQJMSClient.createTopic(topicName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QueueConnection createQueueConnection(IS3ConnectionProperties props) throws JMSException {
/*  79 */     log.debug("Creating queue connection as user: " + props.getUser());
/*  80 */     QueueConnectionFactory factory = (QueueConnectionFactory)createConnectionFactory(props, JMSFactoryType.QUEUE_CF);
/*  81 */     return factory.createQueueConnection(props.getUser(), String.valueOf(props.getPassword()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static TopicConnection createTopicConnection(IS3ConnectionProperties props) throws JMSException {
/*  99 */     log.debug("Creating topic connection as user: " + props.getUser());
/* 100 */     TopicConnectionFactory factory = (TopicConnectionFactory)createConnectionFactory(props, JMSFactoryType.TOPIC_CF);
/* 101 */     return factory.createTopicConnection(props.getUser(), String.valueOf(props.getPassword()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TopicConnection JNDIcreateTopicConnection(IS3ConnectionProperties connectionProperties, IS3ConnectorInstance test) throws JMSException {
/*     */     try {
/* 121 */       IS3SessionIdentity connId = test.connect(connectionProperties);
/* 122 */       TopicConnection topicconnection = test.createTopicConnection();
/* 123 */       return topicconnection;
/*     */     }
/* 125 */     catch (Exception e) {
/* 126 */       throw new JMSException("Failed to Create Connection Factory" + e.getLocalizedMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static ActiveMQConnectionFactory createConnectionFactory(IS3ConnectionProperties props, JMSFactoryType type) {
/* 131 */     log.debug("Creating connection factory withoutHA");
/* 132 */     Map<String, Object> params = new HashMap<>();
/* 133 */     if (props.hasLoadBalncer()) {
/* 134 */       params.put("host", props.getServerHost());
/*     */     } else {
/* 136 */       params.put("host", props.getHost());
/*     */     } 
/* 138 */     params.put("port", props.getWebPort());
/* 139 */     params.put("httpUpgradeEnabled", Boolean.valueOf(true));
/* 140 */     params.put("httpUpgradeEndpoint", "http-acceptor");
/* 141 */     TransportConfiguration transportConf = new TransportConfiguration(NettyConnectorFactory.class.getName(), params);
/*     */     
/* 143 */     ActiveMQConnectionFactory connectionFactory = ActiveMQJMSClient.createConnectionFactoryWithoutHA(type, new TransportConfiguration[] { transportConf });
/*     */     
/* 145 */     connectionFactory.setReconnectAttempts(-1);
/* 146 */     connectionFactory.setConfirmationWindowSize(1048576);
/* 147 */     connectionFactory.setConnectionTTL(1860000L);
/* 148 */     return connectionFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3JmsConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */