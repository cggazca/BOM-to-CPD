/*    */ package com.mentor.is3.sec.client.connector;
/*    */ 
/*    */ import com.mentor.infrasec.keycertutils.KerberosUtils;
/*    */ import java.io.IOException;
/*    */ import java.util.Base64;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ import javax.security.sasl.SaslException;
/*    */ import org.jboss.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IS3KrbCallbackHandler
/*    */   implements CallbackHandler
/*    */ {
/* 27 */   private static final Logger logger = Logger.getLogger(IS3KrbCallbackHandler.class);
/*    */   
/*    */   private String username;
/*    */   private String server;
/*    */   
/*    */   public IS3KrbCallbackHandler(String username, String server) {
/* 33 */     this.username = username;
/* 34 */     this.server = server;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 40 */     for (int i = 0; i < callbacks.length; i++) {
/*    */       
/* 42 */       if (callbacks[i] instanceof PasswordCallback) {
/*    */         
/* 44 */         if (logger.isDebugEnabled()) {
/* 45 */           logger.debug("IS3KrbCallbackHandler - handling PasswordCallback");
/*    */         }
/*    */         
/* 48 */         PasswordCallback pc = (PasswordCallback)callbacks[i];
/*    */ 
/*    */         
/*    */         try {
/* 52 */           String protocol = "http";
/*    */ 
/*    */           
/* 55 */           if (!SystemTokenUtils.isWinAuthAvailable()) {
/*    */             
/* 57 */             byte[] token = KerberosUtils.getKerberosTokenForUser(this.username, this.server);
/*    */             
/* 59 */             String token64 = new String(Base64.getEncoder().encode(token));
/* 60 */             if (logger.isDebugEnabled()) {
/* 61 */               logger.debug("IS3KrbCallbackHandler - created token: " + token64);
/*    */             }
/*    */             
/* 64 */             pc.setPassword(token64.toCharArray());
/*    */           }
/*    */           else {
/*    */             
/* 68 */             byte[] token = SystemTokenUtils.getWindowsToken(protocol + "/" + protocol);
/* 69 */             String token64 = new String(Base64.getEncoder().encode(token));
/*    */             
/* 71 */             if (logger.isDebugEnabled()) {
/* 72 */               logger.debug("IS3KrbCallbackHandler - retrieved token from system: " + token64);
/*    */             }
/*    */             
/* 75 */             pc.setPassword(token64.toCharArray());
/*    */           } 
/* 77 */         } catch (Exception e) {
/* 78 */           if (logger.isDebugEnabled()) {
/* 79 */             logger.debug("IS3KrbCallbackHandler - got exception: " + e.getLocalizedMessage(), e);
/*    */           }
/* 81 */           throw new SaslException("Failure to initialize security context", e);
/*    */         }
/*    */       
/* 84 */       } else if (callbacks[i] instanceof NameCallback) {
/*    */         
/* 86 */         if (logger.isDebugEnabled()) {
/* 87 */           logger.debug("IS3KrbCallbackHandler - handling NameCallback - " + this.username);
/*    */         }
/* 89 */         NameCallback nc = (NameCallback)callbacks[i];
/* 90 */         nc.setName(this.username);
/*    */       } else {
/*    */         
/* 93 */         throw new UnsupportedCallbackException(callbacks[i], "Unrecognized Callback in IS3KrbCallbackHandler.");
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3KrbCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */