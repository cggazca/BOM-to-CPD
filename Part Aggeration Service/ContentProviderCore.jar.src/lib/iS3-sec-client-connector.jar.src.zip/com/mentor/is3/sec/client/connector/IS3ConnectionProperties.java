/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.client.connector.exceptions.ConnectorBaseException;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.security.AuthOptionKey;
/*     */ import com.mentor.is3.server.api.transfer.config.ServerIdTO;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3ConnectionProperties
/*     */   implements Cloneable
/*     */ {
/*     */   static final String CONNECTION_TIMEOUT_OVERRIDE = "CONNECTION_TIMEOUT_OVERRIDE";
/*     */   private String host;
/*     */   private String ejbPort;
/*     */   private String jmsPort;
/*     */   private String webPort;
/*     */   private String httpsPort;
/*     */   private boolean isSSLUsed = false;
/*     */   private String machineId;
/*     */   private String machineName;
/*     */   private String user;
/*     */   private char[] password;
/*     */   private boolean noSessionCheck = false;
/*     */   private boolean singleSignOn = false;
/*     */   private boolean identityPerThread = false;
/*  96 */   private long connectionTimeoutValue = 0L;
/*     */   
/*  98 */   private AuthOptionKey authMethod = AuthOptionKey.IS3_AUTH;
/*     */ 
/*     */ 
/*     */   
/*     */   private String balancerPort;
/*     */ 
/*     */   
/* 105 */   private List<String> clusterNodes = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private String oidcClientId;
/*     */ 
/*     */ 
/*     */   
/*     */   private String oidcAuthEndpoint;
/*     */ 
/*     */ 
/*     */   
/*     */   private String samlPostUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   private String samlRedirectUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   private String samlUserLoginAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password) {
/* 131 */     return (new IS3ConnectionProperties()).setUser(user).setPassword(password).setHost("localhost").setEjbPort(IS3ConnectionDefaultProperties.REMOTING_PORT)
/* 132 */       .setMachineId(IS3ConnectionDefaultProperties.MACHINE_ID).setJmsPort("5445")
/* 133 */       .setIdentityPerThread(IS3ConnectionDefaultProperties.PROPERTY_IDENTITY_PER_THREAD
/* 134 */         .booleanValue()).setWebPort("31001");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, int webPort) throws ConnectorBaseException {
/* 141 */     return createForEjb(user, password, host, webPort, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, int webPort, boolean isBatch) throws ConnectorBaseException {
/* 147 */     ServerIdTO serverId = null;
/*     */     try {
/* 149 */       serverId = NetworkUtils.getServerConfForInput(host, webPort, isBatch);
/*     */     }
/* 151 */     catch (UnknownHostException ue) {
/*     */ 
/*     */ 
/*     */       
/* 155 */       ConnectorBaseException ce = new ConnectorBaseException(ue);
/* 156 */       throw ce;
/*     */     } 
/* 158 */     IS3ConnectionProperties props = createForEjb(user, password);
/* 159 */     props.setHost(host);
/* 160 */     props.setEjbPort(String.valueOf(serverId.getJndiPort()));
/* 161 */     props.setJmsPort(String.valueOf(serverId.getJmsPort()));
/* 162 */     props.setWebPort(String.valueOf(serverId.getWebPort()));
/* 163 */     props.setAuthMethod(AuthOptionKey.IS3_AUTH);
/*     */     
/* 165 */     props.setSamlPostUrl(serverId.getSamlPostUrl());
/* 166 */     props.setSamlRedirectUrl(serverId.getSamlRedirectUrl());
/* 167 */     props.setSamlUserLoginAttribute(serverId.getSamlUserLoginAttribute());
/*     */     
/* 169 */     boolean isSsl = serverId.isSslEnabled();
/* 170 */     props.setSSLUsed(isSsl);
/* 171 */     if (isSsl) {
/* 172 */       props.setHttpsPort(String.valueOf(serverId.getHttpsPort()));
/*     */     }
/*     */     
/* 175 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String balancerPort, String ejbPort, String jmsPort, String webPort, List<String> clusterNodes) {
/* 193 */     return createForEjb(user, password, host, balancerPort, ejbPort, jmsPort, webPort, false, clusterNodes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, String webPort) {
/* 217 */     return createForEjb(user, password, host, ejbPort, jmsPort, webPort, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, String webPort, boolean noSessionCheck) {
/* 242 */     return createForEjb(user, password, host, ejbPort, jmsPort, webPort, noSessionCheck, AuthOptionKey.IS3_AUTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String balancerPort, String ejbPort, String jmsPort, String webPort, boolean noSessionCheck, List<String> clusterNodes) {
/* 270 */     return createForEjb(user, password, host, balancerPort, ejbPort, jmsPort, webPort, noSessionCheck, AuthOptionKey.IS3_AUTH, clusterNodes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, String webPort, boolean noSessionCheck, AuthOptionKey authMethod) {
/* 276 */     return createForEjb(user, password, host, null, ejbPort, jmsPort, webPort, noSessionCheck, authMethod, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String balancerPort, String ejbPort, String jmsPort, String webPort, boolean noSessionCheck, AuthOptionKey authMethod, List<String> clusterNodes) {
/* 283 */     String machineName = "", machineId = "";
/* 284 */     IS3ConnectionProperties props = createForEjb(user, password);
/*     */     try {
/* 286 */       machineName = InetAddress.getLocalHost().getHostName();
/* 287 */       machineId = InetAddress.getLocalHost().getHostAddress() + "/" + InetAddress.getLocalHost().getHostAddress();
/* 288 */       props = createForEjb(user, password, host, Integer.parseInt(webPort), false);
/*     */     }
/* 290 */     catch (UnknownHostException|NumberFormatException|ConnectorBaseException e) {
/*     */ 
/*     */       
/* 293 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 297 */     return props.setEjbPort(ejbPort).setMachineId(machineId).setJmsPort(jmsPort).setMachineName(machineName)
/* 298 */       .setNoSessionCheck(noSessionCheck).setAuthMethod(authMethod).setBalancerPort(balancerPort)
/* 299 */       .setClusterNodes(clusterNodes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, String language, Boolean identityPerThread, String webPort) {
/* 329 */     return createForEjb(user, password, host, ejbPort, jmsPort, language, identityPerThread, webPort, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, String language, Boolean identityPerThread, String webPort, boolean isBatch) {
/* 336 */     return createForEjb(user, password, host, ejbPort, jmsPort, webPort, isBatch)
/* 337 */       .setIdentityPerThread(identityPerThread.booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, Boolean identityPerThread, String webPort) {
/* 364 */     return createForEjb(user, password, host, ejbPort, jmsPort, identityPerThread, webPort, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForEjb(String user, char[] password, String host, String ejbPort, String jmsPort, Boolean identityPerThread, String webPort, boolean isBatch) {
/* 369 */     return createForEjb(user, password, host, ejbPort, jmsPort, webPort, isBatch)
/* 370 */       .setIdentityPerThread(identityPerThread.booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties createForJms(String user, char[] password) {
/* 383 */     return (new IS3ConnectionProperties()).setUser(user).setPassword(password).setHost("localhost").setJmsPort("5445")
/* 384 */       .setMachineId(IS3ConnectionDefaultProperties.MACHINE_ID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3ConnectionProperties create(String user, char[] password, IS3ConnectionProperties source) {
/*     */     try {
/* 402 */       IS3ConnectionProperties newInstance = (IS3ConnectionProperties)source.clone();
/* 403 */       return newInstance.setUser(user).setPassword(password);
/*     */     }
/* 405 */     catch (CloneNotSupportedException e) {
/*     */       
/* 407 */       return IS3ConnectorHelper.<IS3ConnectionProperties>handleException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getProviderUrl() {
/* 412 */     return "remote://" + getServerHost() + ":" + getEjbPort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String gethttpProviderUrl() {
/* 417 */     return "remote+http://" + getServerHost() + ":" + getWebPort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String gethttpsProviderUrl() {
/* 422 */     return "remote+https://" + getServerHost() + ":" + getHttpsPort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String gethttpProviderUrls() {
/* 427 */     StringBuffer sb = new StringBuffer();
/* 428 */     if (hasLoadBalncer()) {
/* 429 */       for (String node : this.clusterNodes)
/*     */       {
/* 431 */         sb.append("remote+http://").append(node).append(":").append(getWebPort()).append(",");
/*     */       }
/* 433 */       sb.deleteCharAt(sb.length() - 1);
/* 434 */       return sb.toString();
/*     */     } 
/* 436 */     return gethttpProviderUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerProviderUrl() {
/* 449 */     return String.format("%s://%s:%s", new Object[] {
/*     */           
/* 451 */           this.isSSLUsed ? "remote+https" : "remote+http", getServerHost(), 
/* 452 */           this.isSSLUsed ? getHttpsPort() : getWebPort()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHttpProviderUrl() {
/* 462 */     return getServerProviderUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerUrl() {
/* 472 */     return String.format("%s://%s:%s", new Object[] {
/* 473 */           this.isSSLUsed ? "https" : "http", getHost(), 
/* 474 */           this.isSSLUsed ? getHttpsPort() : getWebPort()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHttpUrl() {
/* 484 */     return getServerUrl();
/*     */   }
/*     */   
/*     */   public String getHost() {
/* 488 */     return this.host;
/*     */   }
/*     */   
/*     */   public String getServerHost() {
/* 492 */     if (this.clusterNodes != null && this.clusterNodes.size() > 0) {
/* 493 */       return this.clusterNodes.get(0);
/*     */     }
/* 495 */     return this.host;
/*     */   }
/*     */ 
/*     */   
/*     */   public IS3ConnectionProperties setHost(String host) {
/* 500 */     this.host = host;
/* 501 */     return this;
/*     */   }
/*     */   
/*     */   public String getEjbPort() {
/* 505 */     return this.ejbPort;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setEjbPort(String port) {
/* 509 */     this.ejbPort = port;
/* 510 */     return this;
/*     */   }
/*     */   
/*     */   public String getJmsPort() {
/* 514 */     return this.jmsPort;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setJmsPort(String jmsPort) {
/* 518 */     this.jmsPort = jmsPort;
/* 519 */     return this;
/*     */   }
/*     */   
/*     */   public String getMachineId() {
/* 523 */     return this.machineId;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setMachineId(String machineId) {
/* 527 */     this.machineId = machineId;
/* 528 */     return this;
/*     */   }
/*     */   
/*     */   public String getMachineName() {
/* 532 */     return this.machineName;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setMachineName(String machineName) {
/* 536 */     this.machineName = machineName;
/* 537 */     return this;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 541 */     return this.user;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setUser(String user) {
/* 545 */     this.user = user;
/* 546 */     return this;
/*     */   }
/*     */   
/*     */   public char[] getPassword() {
/* 550 */     return this.password;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setPassword(char[] password) {
/* 554 */     this.password = password;
/* 555 */     return this;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setAuthMethod(AuthOptionKey authMethod) {
/* 559 */     this.authMethod = authMethod;
/* 560 */     return this;
/*     */   }
/*     */   
/*     */   public AuthOptionKey getAuthMethod() {
/* 564 */     return this.authMethod;
/*     */   }
/*     */   
/*     */   public String getWebPort() {
/* 568 */     return this.webPort;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setWebPort(String webPort) {
/* 572 */     this.webPort = webPort;
/* 573 */     return this;
/*     */   }
/*     */   
/*     */   public String getHttpsPort() {
/* 577 */     return this.httpsPort;
/*     */   }
/*     */   
/*     */   public void setHttpsPort(String httpsPort) {
/* 581 */     this.httpsPort = httpsPort;
/*     */   }
/*     */   
/*     */   public boolean isSSLUsed() {
/* 585 */     return this.isSSLUsed;
/*     */   }
/*     */   
/*     */   public void setSSLUsed(boolean isSSLUsed) {
/* 589 */     this.isSSLUsed = isSSLUsed;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setSingleSignOn(boolean singleSignOn) {
/* 593 */     this.singleSignOn = singleSignOn;
/* 594 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isSingleSignOn() {
/* 598 */     return this.singleSignOn;
/*     */   }
/*     */   
/*     */   public boolean isNoSessionCheck() {
/* 602 */     return this.noSessionCheck;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setNoSessionCheck(boolean noSessionCheck) {
/* 606 */     this.noSessionCheck = noSessionCheck;
/* 607 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getClusterNodes() {
/* 612 */     return this.clusterNodes;
/*     */   }
/*     */   
/*     */   public String getBalancerPort() {
/* 616 */     return this.balancerPort;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setBalancerPort(String balancerPort) {
/* 620 */     this.balancerPort = balancerPort;
/* 621 */     return this;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setClusterNodes(List<String> nodes) {
/* 625 */     this.clusterNodes = nodes;
/* 626 */     return this;
/*     */   }
/*     */   
/*     */   public boolean hasLoadBalncer() {
/* 630 */     if (this.clusterNodes != null && this.clusterNodes.size() > 0) {
/* 631 */       return true;
/*     */     }
/* 633 */     return false;
/*     */   }
/*     */   
/*     */   public String getOidcClientId() {
/* 637 */     return this.oidcClientId;
/*     */   }
/*     */   
/*     */   public void setOidcClientId(String oidcClientId) {
/* 641 */     this.oidcClientId = oidcClientId;
/*     */   }
/*     */   
/*     */   public String getOidcAuthEndpoint() {
/* 645 */     return this.oidcAuthEndpoint;
/*     */   }
/*     */   
/*     */   public void setOidcAuthEndpoint(String oidcAuthEndpoint) {
/* 649 */     this.oidcAuthEndpoint = oidcAuthEndpoint;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 654 */     return "IS3ConnectionProperties[" + getProviderUrl() + "," + this.machineId + "," + this.user + "," + String.valueOf(this.password) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIdentityPerThread() {
/* 662 */     return this.identityPerThread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IS3ConnectionProperties setIdentityPerThread(boolean identityPerThread) {
/* 671 */     this.identityPerThread = identityPerThread;
/* 672 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getConnectionTimeoutValue() {
/* 679 */     return this.connectionTimeoutValue;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setConnectionTimeoutValue(long newConnectionTimeoutValue) {
/* 683 */     this.connectionTimeoutValue = newConnectionTimeoutValue;
/* 684 */     return this;
/*     */   }
/*     */   
/*     */   public String getSamlPostUrl() {
/* 688 */     return this.samlPostUrl;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setSamlPostUrl(String samlPostUrl) {
/* 692 */     this.samlPostUrl = samlPostUrl;
/* 693 */     return this;
/*     */   }
/*     */   
/*     */   public String getSamlRedirectUrl() {
/* 697 */     return this.samlRedirectUrl;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setSamlRedirectUrl(String samlRedirectUrl) {
/* 701 */     this.samlRedirectUrl = samlRedirectUrl;
/* 702 */     return this;
/*     */   }
/*     */   
/*     */   public String getSamlUserLoginAttribute() {
/* 706 */     return this.samlUserLoginAttribute;
/*     */   }
/*     */   
/*     */   public IS3ConnectionProperties setSamlUserLoginAttribute(String samlUserLoginAttribute) {
/* 710 */     this.samlUserLoginAttribute = samlUserLoginAttribute;
/* 711 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3ConnectionProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */