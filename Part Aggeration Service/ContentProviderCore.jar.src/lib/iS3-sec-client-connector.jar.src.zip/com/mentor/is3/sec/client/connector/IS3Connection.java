/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.server.api.transfer.adminsession.security.AuthOptionKey;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.AccessController;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.swing.JOptionPane;
/*     */ import org.jboss.ejb.client.EJBClientConnection;
/*     */ import org.jboss.ejb.client.EJBClientContext;
/*     */ import org.jboss.ejb.client.EJBTransportProvider;
/*     */ import org.jboss.ejb.client.legacy.ElytronLegacyConfiguration;
/*     */ import org.jboss.ejb.protocol.remote.RemoteTransportProvider;
/*     */ import org.jboss.logging.Logger;
/*     */ import org.jboss.remoting3.Connection;
/*     */ import org.jboss.remoting3.Endpoint;
/*     */ import org.jboss.remoting3.EndpointBuilder;
/*     */ import org.jboss.remoting3.RemotingOptions;
/*     */ import org.wildfly.common.context.Contextual;
/*     */ import org.wildfly.security.auth.client.AuthenticationConfiguration;
/*     */ import org.wildfly.security.auth.client.AuthenticationContext;
/*     */ import org.wildfly.security.auth.client.AuthenticationContextConfigurationClient;
/*     */ import org.xnio.IoFuture;
/*     */ import org.xnio.OptionMap;
/*     */ import org.xnio.Xnio;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3Connection
/*     */ {
/*  52 */   private static Logger log = Logger.getLogger(IS3Connection.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Endpoint endpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Connection connection;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   static List<EJBClientContext> ejbClientContexts = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Endpoint getEndpoint() {
/*  75 */     return this.endpoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() {
/*  84 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private X509Certificate[] getSSLCert(IS3ConnectionProperties props, boolean isBatch) throws Exception {
/* 101 */     X509Certificate[] certs = null;
/* 102 */     if (!props.isSSLUsed()) {
/*     */ 
/*     */       
/* 105 */       int webport = Integer.valueOf(props.getWebPort()).intValue();
/* 106 */       log.debug("non-SSL connect on webport " + webport);
/*     */       
/* 108 */       SSLServerChecks sslcheck = SSLConnectionCheckCache.getInstance().getSSLPortCheckObject(props.getServerHost(), webport, isBatch);
/*     */       
/* 110 */       boolean sslEnabled = sslcheck.isServerSSLConfigured();
/* 111 */       log.debug("SSL " + (sslEnabled ? "is" : "is not") + " enabled");
/* 112 */       props.setSSLUsed(sslEnabled);
/* 113 */       props.setHttpsPort(props.getWebPort());
/* 114 */       if (sslEnabled && !sslcheck.isAES256Configured()) {
/* 115 */         log.debug("sslEnabled but AES256 is not configured, run clientPrep");
/* 116 */         throw new Exception("Missing policy files in Client JRE, install and connect to server");
/*     */       } 
/*     */       try {
/* 119 */         log.debug("setup SSL connection information");
/* 120 */         if (sslEnabled && !sslcheck.setupSSLInfo()) {
/* 121 */           log.debug("Failed to correctly set up SSL connection");
/* 122 */           throw new Exception("Failed to validate Server Certificate");
/*     */         }
/*     */       
/* 125 */       } catch (Exception e) {
/* 126 */         log.debug("caught exception of type " + e.getClass().getName() + ": " + e.getMessage());
/* 127 */         throw new Exception(e.getLocalizedMessage());
/*     */       } 
/* 129 */       certs = sslcheck.getCertificateChain();
/*     */     } 
/* 131 */     return certs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(IS3ConnectionProperties props) {
/* 139 */     connect(props, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(IS3ConnectionProperties props, boolean isBatch) {
/*     */     try {
/* 146 */       OptionMap connectionOptions = null;
/* 147 */       OptionMap providerOptions = null;
/*     */ 
/*     */       
/* 150 */       getSSLCert(props, isBatch);
/* 151 */       if (props.isSSLUsed()) {
/*     */ 
/*     */         
/* 154 */         log.debug("setting options for ssl connections");
/* 155 */         int webport = Integer.valueOf(props.getHttpsPort()).intValue();
/* 156 */         SSLServerChecks sslcheck = SSLConnectionCheckCache.getInstance().getSSLPortCheckObject(props.getServerHost(), webport, isBatch);
/*     */         
/* 158 */         connectionOptions = IS3ConnectionDefaultProperties.getSSLConnectionOptions(sslcheck.getServerCipher());
/* 159 */         providerOptions = IS3ConnectionDefaultProperties.getSSLConnectionProviderOptions();
/*     */       } else {
/*     */         
/* 162 */         log.debug("setting options for non-ssl connections");
/* 163 */         connectionOptions = IS3ConnectionDefaultProperties.getConnectionOptions();
/* 164 */         providerOptions = IS3ConnectionDefaultProperties.getConnectionProviderOptions();
/* 165 */         props.setSSLUsed(false);
/*     */       } 
/*     */       
/* 168 */       String endpointName = "ejb-remote-client-endpoint";
/* 169 */       log.debug("Starting create " + endpointName);
/* 170 */       EndpointBuilder builder = Endpoint.builder();
/* 171 */       builder.buildXnioWorker(Xnio.getInstance()).populateFromOptions(providerOptions).setDaemon(true);
/* 172 */       builder.setEndpointName(endpointName);
/* 173 */       this.endpoint = builder.build();
/*     */ 
/*     */ 
/*     */       
/* 177 */       IS3DelegatingCallbackHandler callbackHandler = new IS3DelegatingCallbackHandler(props, isBatch);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       AuthenticationContextConfigurationClient client = AccessController.<AuthenticationContextConfigurationClient>doPrivileged(AuthenticationContextConfigurationClient.ACTION);
/* 183 */       ElytronLegacyConfiguration elytronLegacyConfiguration = new ElytronLegacyConfiguration();
/*     */       
/* 185 */       AuthenticationContext authenticationContext = elytronLegacyConfiguration.getConfiguredAuthenticationContext();
/*     */       
/* 187 */       AuthenticationConfiguration authenticationConfiguration = AuthenticationConfiguration.empty().useCallbackHandler(callbackHandler);
/* 188 */       authenticationConfiguration = RemotingOptions.mergeOptionsIntoAuthenticationConfiguration(connectionOptions, authenticationConfiguration);
/*     */ 
/*     */       
/* 191 */       SSLContext sslContext = null;
/* 192 */       URI uriToUse = new URI(props.getHttpProviderUrl());
/*     */       try {
/* 194 */         sslContext = client.getSSLContext(uriToUse, authenticationContext);
/* 195 */       } catch (GeneralSecurityException e) {
/*     */         
/* 197 */         String message = "Caught GeneralSecurityException when trying getSSLContext: " + e.getMessage();
/* 198 */         log.error(message);
/* 199 */         Exception toThrow = new Exception(message);
/* 200 */         IS3ConnectorHelper.handleException(toThrow);
/*     */       } 
/* 202 */       IoFuture<Connection> futureConnection = this.endpoint.connect(uriToUse, null, connectionOptions, sslContext, authenticationConfiguration);
/*     */ 
/*     */       
/* 205 */       if (log.isDebugEnabled()) {
/* 206 */         String remotingProtocol = props.isSSLUsed() ? "remote+https" : "remote+http";
/* 207 */         log.debug("Using " + remotingProtocol + ", start connection");
/*     */       } 
/* 209 */       IoFuture.Status status = futureConnection.await(500L, TimeUnit.SECONDS);
/* 210 */       if (status == IoFuture.Status.DONE) {
/* 211 */         log.debug("Connection complete to " + props.getHttpUrl());
/* 212 */         this.connection = (Connection)futureConnection.get();
/*     */       } else {
/*     */         
/* 215 */         String message = "Cannot make futureConnection to server at " + props.getHttpUrl() + ", status: " + String.valueOf(status);
/* 216 */         log.error(message);
/* 217 */         Exception toThrow = new Exception(message);
/* 218 */         IS3ConnectorHelper.handleException(toThrow);
/*     */       } 
/*     */ 
/*     */       
/* 222 */       setupEJBClientContext(props);
/*     */     }
/* 224 */     catch (IOException e) {
/* 225 */       if (props.getAuthMethod() == AuthOptionKey.KERBEROS_AUTH) {
/* 226 */         log.debug("Using Kerberos, caught IOException: " + e.getMessage());
/* 227 */         String message = "Kerberos login failed";
/* 228 */         if (e.getMessage().contains("PLAIN: No implementation found"))
/* 229 */           message = e.getMessage(); 
/* 230 */         Exception toThrow = new Exception(message);
/* 231 */         IS3ConnectorHelper.handleException(toThrow);
/*     */       } else {
/* 233 */         log.debug("Caught IOException: " + e.getMessage());
/* 234 */         IS3ConnectorHelper.handleException(e);
/*     */       }
/*     */     
/* 237 */     } catch (URISyntaxException e) {
/* 238 */       log.debug("Caught URISyntaxException: " + e.getMessage());
/* 239 */       IS3ConnectorHelper.handleException(e);
/*     */     }
/* 241 */     catch (Exception e) {
/* 242 */       log.debug("Caught general exception of type " + e.getClass().getName() + ": " + e.getMessage());
/* 243 */       IS3ConnectorHelper.handleException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupEJBClientContext(IS3ConnectionProperties props) {
/* 254 */     log.debug("* Starting setupEJBClientContext");
/* 255 */     log.debug("*       look through " + ejbClientContexts.size() + " EJBClientContexts");
/* 256 */     Iterator<EJBClientContext> ejbClientContextIt = ejbClientContexts.iterator();
/* 257 */     EJBClientContext ejbClientContext = null;
/* 258 */     boolean foundExisting = false;
/* 259 */     while (ejbClientContextIt.hasNext()) {
/* 260 */       ejbClientContext = ejbClientContextIt.next();
/* 261 */       if (ejbClientContext != null) {
/* 262 */         Iterator<EJBClientConnection> connectionIt = ejbClientContext.getConfiguredConnections().iterator();
/* 263 */         while (connectionIt.hasNext()) {
/* 264 */           EJBClientConnection clientCon = connectionIt.next();
/* 265 */           if (clientCon.getDestination().equals(this.connection.getPeerURI())) {
/* 266 */             log.debug("*    using existing EJBClientContext");
/* 267 */             foundExisting = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 272 */       if (foundExisting == true) {
/*     */         break;
/*     */       }
/*     */     } 
/* 276 */     if (!foundExisting) {
/*     */       
/* 278 */       log.debug("*     Create a new EJBClientContext, create Builder");
/* 279 */       EJBClientContext.Builder ejbClientContextBuilder = new EJBClientContext.Builder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 292 */       long invocationTimeout = props.getConnectionTimeoutValue();
/* 293 */       String variable = System.getenv("CONNECTION_TIMEOUT_OVERRIDE");
/*     */       try {
/* 295 */         if (variable != null) {
/* 296 */           long newVal = Long.parseLong(variable);
/* 297 */           if (newVal >= 0L)
/* 298 */             invocationTimeout = newVal; 
/*     */         } 
/* 300 */       } catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */       
/* 303 */       log.debug("*     Setting connection timeout: " + invocationTimeout);
/* 304 */       ejbClientContextBuilder.setInvocationTimeout(invocationTimeout);
/* 305 */       ejbClientContextBuilder.addTransportProvider((EJBTransportProvider)new RemoteTransportProvider());
/*     */ 
/*     */       
/* 308 */       log.debug("*     Create a Builder for EJBClientConnection and configure");
/* 309 */       EJBClientConnection.Builder ejbClientConnectionBuilder = new EJBClientConnection.Builder();
/*     */ 
/*     */       
/* 312 */       ejbClientConnectionBuilder.setForDiscovery(true);
/* 313 */       ejbClientConnectionBuilder.setDestination(this.connection.getPeerURI());
/* 314 */       log.debug("*     Execute EJBClientConnectionBuilder and add to EJBClientContext.Builder");
/* 315 */       ejbClientContextBuilder.addClientConnection(ejbClientConnectionBuilder.build());
/*     */       
/* 317 */       log.debug("*     Create a new EJBClientContext");
/* 318 */       ejbClientContext = ejbClientContextBuilder.build();
/* 319 */       ejbClientContexts.add(ejbClientContext);
/*     */     } 
/*     */ 
/*     */     
/* 323 */     log.debug("*     Configure supplier in ContextManager of EJBClientContext at URI: " + 
/* 324 */         String.valueOf(((EJBClientConnection)ejbClientContext.getConfiguredConnections().iterator().next()).getDestination()));
/* 325 */     if (props.isIdentityPerThread()) {
/* 326 */       EJBClientContext.getContextManager().setThreadDefault((Contextual)ejbClientContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 331 */     EJBClientContext.getContextManager().setGlobalDefault((Contextual)ejbClientContext);
/* 332 */     log.debug("* Ending setupEJBClientContext");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 339 */     if (this.connection != null) {
/*     */       try {
/* 341 */         log.debug("closing connection");
/* 342 */         this.connection.close();
/*     */ 
/*     */ 
/*     */         
/* 346 */         this.connection.awaitClosed();
/* 347 */         log.debug("   connection is fully closed");
/*     */       }
/* 349 */       catch (IOException e) {
/* 350 */         log.debug("Caught IOException: " + e.getMessage());
/* 351 */         IS3ConnectorHelper.handleException(e);
/*     */       }
/* 353 */       catch (InterruptedException e) {
/*     */         
/* 355 */         log.debug("   recieved InterruptedException awaiting fully closed connection: " + e.getMessage());
/*     */       } 
/*     */     }
/*     */     
/* 359 */     if (this.endpoint != null) {
/*     */       try {
/* 361 */         log.debug("closing endpoint");
/* 362 */         this.endpoint.close();
/*     */       }
/* 364 */       catch (IOException e) {
/* 365 */         log.debug("Caught IOException: " + e.getMessage());
/* 366 */         IS3ConnectorHelper.handleException(e);
/*     */       } 
/*     */     }
/* 369 */     this.connection = null;
/* 370 */     this.endpoint = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 377 */     if (args.length != 3) {
/* 378 */       log.error("Incorrect number of arguments, should be 'hostname', 'port' and 'isBatch'");
/* 379 */       System.exit(5);
/*     */     } 
/* 381 */     String hostname = args[0];
/* 382 */     String port = args[1];
/* 383 */     boolean isBatch = !(Integer.parseInt(args[2]) == 0);
/*     */ 
/*     */     
/* 386 */     boolean sslEnabled = false;
/* 387 */     boolean trustedCert = true;
/*     */     try {
/* 389 */       log.debug("Start isServerSSLConfigured to server " + hostname + ":" + port);
/* 390 */       SSLServerChecks sslcheck = SSLConnectionCheckCache.getInstance().getSSLPortCheckObject(hostname, Integer.valueOf(port).intValue(), isBatch);
/* 391 */       sslEnabled = sslcheck.isServerSSLConfigured();
/* 392 */       if (sslEnabled) {
/* 393 */         log.debug("Server " + hostname + " is SSL configured, setupSSLInfo and getCertificateChain to create PEM file");
/* 394 */         trustedCert = sslcheck.setupSSLInfo();
/*     */       } 
/* 396 */       sslcheck.getCertificateChain();
/*     */     }
/* 398 */     catch (Exception e) {
/* 399 */       log.error("Caught Exception of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 400 */       String msg = "ERROR: ";
/* 401 */       if (e.getMessage().contains("handshake")) {
/* 402 */         msg = msg + "Restricted policy files in Client Java Runtime.\nDownload Client Prep utility from https://" + msg + ":" + hostname + "/\nUnzip archive and execute ClientPrep utility.  Now retry connection.";
/*     */       } else {
/*     */         
/* 405 */         msg = msg + msg;
/* 406 */       }  JOptionPane.showMessageDialog(null, msg);
/* 407 */       System.out.println("returning with status 2");
/* 408 */       System.exit(2);
/*     */     } 
/*     */     
/* 411 */     int returnVal = trustedCert ? 0 : 1;
/* 412 */     log.debug("returning with status " + returnVal);
/* 413 */     System.out.println("returning with status " + returnVal);
/* 414 */     System.exit(returnVal);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3Connection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */