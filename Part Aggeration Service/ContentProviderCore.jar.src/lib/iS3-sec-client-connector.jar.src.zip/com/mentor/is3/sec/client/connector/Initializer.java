package com.mentor.is3.sec.client.connector;

interface Initializer<V> {
  V init();
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\Initializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */