package com.mentor.is3.sec.client.connector;

public interface Constans {
  public static final int DEFAULT_HTTP_PORT = 31000;
  
  public static final int DEFAULT_HTTPS_PORT = 31443;
  
  public static final int DEFAULT_JNDI_PORT = 4447;
  
  public static final String WEB_CONNECTION_LINK = "%s://%s:%s";
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\Constans.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */