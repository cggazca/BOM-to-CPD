package com.mentor.is3.sec.client.connector;

import com.mentor.is3.sec.client.connector.exceptions.ConnectorBaseException;
import java.io.IOException;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;

public interface HttpGetExecutor {
  void execute(CloseableHttpResponse paramCloseableHttpResponse) throws ConnectorBaseException, IOException;
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\HttpGetExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */