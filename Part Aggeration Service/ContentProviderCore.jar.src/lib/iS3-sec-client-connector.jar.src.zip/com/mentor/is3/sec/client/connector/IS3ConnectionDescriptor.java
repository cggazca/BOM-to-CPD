/*    */ package com.mentor.is3.sec.client.connector;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IS3ConnectionDescriptor
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6955244185492588937L;
/*    */   private String user;
/*    */   private String password;
/*    */   private URL url;
/*    */   
/*    */   public IS3ConnectionDescriptor() {}
/*    */   
/*    */   public IS3ConnectionDescriptor(String user, String password, URL url) {
/* 36 */     this.user = user;
/* 37 */     this.password = password;
/* 38 */     this.url = url;
/*    */   }
/*    */   
/*    */   public String getUser() {
/* 42 */     return this.user;
/*    */   }
/*    */   
/*    */   public void setUser(String user) {
/* 46 */     this.user = user;
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 50 */     return this.password;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 54 */     this.password = password;
/*    */   }
/*    */   
/*    */   public URL getUrl() {
/* 58 */     return this.url;
/*    */   }
/*    */   
/*    */   public void setUrl(URL url) {
/* 62 */     this.url = url;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3ConnectionDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */