/*      */ package com.mentor.is3.sec.client.connector;
/*      */ 
/*      */ import com.mentor.is3.sec.client.connector.exceptions.ConnectorBaseException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.GeneralErrorException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.NetworkProblemException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.ServerCertificateInvalidException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.ServerNotAchievableException;
/*      */ import com.mentor.is3.sec.common.IS3HttpClient;
/*      */ import com.mentor.is3.server.api.transfer.adminsession.security.SessionInfoTO;
/*      */ import com.mentor.is3.server.api.transfer.config.ServerIdTO;
/*      */ import jakarta.xml.bind.JAXBContext;
/*      */ import jakarta.xml.bind.Unmarshaller;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.net.InetAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.SocketException;
/*      */ import java.net.URL;
/*      */ import java.net.URLEncoder;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Optional;
/*      */ import java.util.Properties;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.net.ssl.SSLHandshakeException;
/*      */ import javax.xml.parsers.SAXParserFactory;
/*      */ import javax.xml.transform.Source;
/*      */ import javax.xml.transform.sax.SAXSource;
/*      */ import org.apache.hc.client5.http.classic.methods.HttpGet;
/*      */ import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
/*      */ import org.apache.hc.core5.http.ClassicHttpRequest;
/*      */ import org.jboss.logging.Logger;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NetworkUtils
/*      */ {
/*      */   public static final int INVALID_PORT = -2147483648;
/*      */   private static final String LOCALHOST_REGEXP = "^\\s*((localhost)|(127\\.0\\.0\\.1))\\s*(:\\s*(\\d+)\\s*)?$";
/*   62 */   private static final Pattern SERVER_DISP_PATTERN = Pattern.compile("^((.+?)@((.+?)(()|(:(\\d+?)))))$");
/*      */   
/*   64 */   private static final Pattern HOST_PORT_PATTERN = Pattern.compile("^\\s*(http[s]?://)?([^\\s:]+)\\s*(:\\s*(\\d+)\\s*)?(/)?$");
/*      */   
/*      */   private static final int HOST_PORT_PREFIX = 1;
/*      */   
/*      */   private static final int HOST_PORT_HOSTNAME = 2;
/*      */   
/*      */   private static final int HOST_PORT_PORTNUM = 4;
/*      */   private static final String HTTP_PORT_SYSTEM_VARIABLE_NAME = "IS3_SERVER_WEB_DEFAULT_HTTP_PORT";
/*      */   private static final String HTTPS_PORT_SYSTEM_VARIABLE_NAME = "IS3_SERVER_WEB_DEFAULT_HTTPS_PORT";
/*   73 */   private static final Pattern ADDRESS_REGEXP = Pattern.compile("^(http(s)*:\\/\\/)*(.+?):(\\d+)$");
/*      */   
/*   75 */   private static final Logger log = Logger.getLogger(NetworkUtils.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InitialContext getInitialContext(URL serverAddress, int JNDIPort) throws MalformedURLException, UnknownHostException, NamingException {
/*   96 */     InetAddress hostAddr = InetAddress.getByName(serverAddress.getHost());
/*      */ 
/*      */     
/*   99 */     Properties props = new Properties();
/*  100 */     props.put("java.naming.factory.initial", "org.wildfly.naming.client.WildFlyInitialContextFactory");
/*  101 */     props.put("java.naming.provider.url", hostAddr.getHostAddress() + ":" + hostAddr.getHostAddress());
/*      */ 
/*      */     
/*  104 */     InitialContext ctx = new InitialContext(props);
/*      */     
/*  106 */     return ctx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static URL parseServerURL(String serverPath) throws MalformedURLException {
/*  119 */     if (serverPath == null || serverPath.isEmpty()) {
/*  120 */       return null;
/*      */     }
/*      */     
/*  123 */     if (isAdressTypedInTokenForm(serverPath)) {
/*  124 */       serverPath = getIS3ServerAddr(serverPath);
/*      */     }
/*      */     
/*  127 */     if (!serverPath.startsWith("http://")) {
/*  128 */       serverPath = "http://" + serverPath;
/*      */     }
/*  130 */     URL url = new URL(serverPath);
/*  131 */     return url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int parsePortFromAddress(String input) {
/*  143 */     Matcher match = ADDRESS_REGEXP.matcher(input);
/*      */     
/*  145 */     if (match.find()) {
/*  146 */       return Integer.parseInt(match.group(4));
/*      */     }
/*      */     
/*  149 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String parseHostNameFromAddress(String input) {
/*  161 */     Matcher match = ADDRESS_REGEXP.matcher(input);
/*      */     
/*  163 */     if (match.find()) {
/*  164 */       return match.group(3);
/*      */     }
/*      */     
/*  167 */     return null;
/*      */   }
/*      */   
/*      */   public static String getIS3ServerName(String input) {
/*  171 */     return getMatch(2, input);
/*      */   }
/*      */   
/*      */   public static String getIS3ServerAddrAndPort(String input) {
/*  175 */     return getMatch(3, input);
/*      */   }
/*      */   
/*      */   public static String getIS3ServerAddr(String input) {
/*  179 */     return getMatch(4, input);
/*      */   }
/*      */   
/*      */   public static String getIS3ServerHttpPort(String input) {
/*  183 */     return getMatch(8, input);
/*      */   }
/*      */   
/*      */   public static boolean isAdressTypedInTokenForm(String input) {
/*  187 */     return (getMatch(0, input) != null);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getMatch(int group, String input) {
/*  192 */     Matcher matcher = SERVER_DISP_PATTERN.matcher(input);
/*      */     
/*  194 */     if (matcher.find()) {
/*  195 */       return matcher.group(group);
/*      */     }
/*      */     
/*  198 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void httpGetExecute(String host, int httpPort, boolean isBatch, boolean canUseSSL, String uri, HttpGetExecutor executor) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*  234 */     Optional<Boolean> figureItOut = Optional.empty();
/*  235 */     httpGetExecute(host, httpPort, isBatch, canUseSSL, uri, figureItOut, executor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void httpGetExecute(String host, int httpPort, boolean isBatch, boolean canUseSSL, String uri, Optional<Boolean> connectOnlySSL, HttpGetExecutor executor) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*      */     try {
/*  276 */       SSLServerChecks sslcheck = SSLConnectionCheckCache.getInstance().getSSLPortCheckObject(host, httpPort, isBatch);
/*  277 */       boolean sslEnabled = (canUseSSL && sslcheck.isServerSSLConfigured(connectOnlySSL));
/*  278 */       if (sslEnabled && !sslcheck.setupSSLInfo()) {
/*  279 */         throw new ServerCertificateInvalidException(String.format("Failed to validate SSL certificate for server on host '%s' with port '%d'.", new Object[] { host, Integer.valueOf(httpPort) }));
/*      */       }
/*      */       
/*  282 */       Matcher matcher = HOST_PORT_PATTERN.matcher(host);
/*  283 */       if (matcher.find()) {
/*  284 */         host = matcher.group(2);
/*      */       }
/*      */       
/*  287 */       URL hostUrl = parseServerURL(host);
/*      */       
/*  289 */       if (executor != null) {
/*      */         
/*  291 */         IS3HttpClient is3HttpClient = new IS3HttpClient(sslEnabled, SSLConnectionCheckCache.getInstance().getSslTrustManager());
/*      */         
/*  293 */         try { String httpLink = String.format("%s://%s:%s", new Object[] { sslEnabled ? "https" : "http", hostUrl
/*  294 */                 .getHost(), Integer.valueOf(httpPort) });
/*      */           
/*  296 */           URL url = new URL(httpLink + httpLink);
/*  297 */           HttpGet request = new HttpGet(url.toURI());
/*  298 */           log.debug("Starting httprequest: " + url.toString());
/*  299 */           CloseableHttpResponse response = is3HttpClient.execute((ClassicHttpRequest)request); 
/*  300 */           try { executor.execute(response);
/*  301 */             if (response != null) response.close();  } catch (Throwable throwable) { if (response != null)
/*  302 */               try { response.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  is3HttpClient.close(); } catch (Throwable throwable) { try { is3HttpClient.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*      */       
/*      */       } 
/*  305 */     } catch (SSLHandshakeException exc) {
/*  306 */       log.debug("caught SSLHandshakeException: " + exc.getMessage());
/*  307 */       throw new ServerCertificateInvalidException(String.format("Failed to validate SSL certificate for server on host '%s' with port '%d'.", new Object[] { host, Integer.valueOf(httpPort) }), exc);
/*      */     }
/*  309 */     catch (ServerCertificateInvalidException ex) {
/*  310 */       log.debug("caught ServerCertificateInvalidException: " + ex.getMessage());
/*  311 */       throw ex;
/*      */     }
/*  313 */     catch (SocketException ex) {
/*  314 */       log.debug("caught SocketException: " + ex.getMessage());
/*  315 */       throw new ServerNotAchievableException("Web service is not achieveable.", ex);
/*      */     }
/*  317 */     catch (UnknownHostException ex) {
/*  318 */       log.debug("caught UnknownHostException: " + ex.getMessage() + " for server: " + host + " with port: " + httpPort);
/*  319 */       throw ex;
/*      */     }
/*  321 */     catch (IOException ex) {
/*  322 */       String msg = "unknown";
/*  323 */       if (ex.getMessage() == null) {
/*  324 */         if (ex.getCause() != null && ex.getCause().getMessage() != null)
/*  325 */           msg = ex.getCause().getMessage(); 
/*      */       } else {
/*  327 */         msg = ex.getMessage();
/*      */       } 
/*  329 */       log.debug("caught IOException: " + msg);
/*  330 */       throw new ServerNotAchievableException(String.format("Server on host '%s' with port '%d' is not achievable.", new Object[] { host, Integer.valueOf(httpPort) }), ex);
/*      */     }
/*  332 */     catch (IllegalArgumentException ex) {
/*      */       
/*  334 */       log.debug("caught IllegalArgumentException: " + ex.getMessage());
/*  335 */       throw ex;
/*      */     }
/*  337 */     catch (Exception ex) {
/*  338 */       log.debug("caught Exception of type " + ex.getClass().getName() + ": " + ex.getMessage());
/*  339 */       throw new GeneralErrorException(String.format("General error occurred while contacting server on host '%s' with port '%s'.", new Object[] { host, Integer.valueOf(httpPort) }), ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String httpGetExecute(String serverUrl, boolean isBatch, boolean canUseSSL, String uri) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*  364 */     String host = parseHostNameFromAddress(serverUrl);
/*  365 */     int httpPort = parsePortFromAddress(serverUrl);
/*  366 */     return httpGetExecute(host, httpPort, isBatch, canUseSSL, uri);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String httpGetExecute(String host, int httpPort, boolean isBatch, boolean canUseSSL, String uri) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*  390 */     Optional<Boolean> figureItOut = Optional.empty();
/*  391 */     return httpGetExecute(host, httpPort, isBatch, canUseSSL, uri, figureItOut);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NetworkUtilsHttpGetResult httpGetExecuteFullResult(String host, int httpPort, boolean isBatch, boolean canUseSSL, String uri) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*  417 */     Optional<Boolean> figureItOut = Optional.empty();
/*  418 */     return httpGetExecuteFullResult(host, httpPort, isBatch, canUseSSL, uri, figureItOut);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String httpGetExecute(String host, int httpPort, boolean isBatch, boolean canUseSSL, String uri, Optional<Boolean> connectOnlySSL) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*      */     class Result
/*      */     {
/*  456 */       String responseLine = null;
/*      */     };
/*  458 */     final Result result = new Result();
/*      */     
/*  460 */     httpGetExecute(host, httpPort, isBatch, canUseSSL, uri, connectOnlySSL, new HttpGetExecutor()
/*      */         {
/*      */           public void execute(CloseableHttpResponse httpResponse) throws ConnectorBaseException, IOException {
/*  463 */             InputStream is = null;
/*  464 */             BufferedReader reader = null;
/*      */             try {
/*  466 */               is = httpResponse.getEntity().getContent();
/*  467 */               reader = new BufferedReader(new InputStreamReader(is));
/*  468 */               result.responseLine = reader.readLine();
/*      */             } finally {
/*      */               
/*      */               try {
/*  472 */                 if (reader != null) {
/*  473 */                   reader.close();
/*      */                 }
/*  475 */               } catch (IOException iOException) {}
/*      */               
/*      */               try {
/*  478 */                 if (is != null) {
/*  479 */                   is.close();
/*      */                 }
/*  481 */               } catch (IOException iOException) {}
/*      */             } 
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  487 */     return result.responseLine;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NetworkUtilsHttpGetResult httpGetExecuteFullResult(String host, int httpPort, boolean isBatch, boolean canUseSSL, String uri, Optional<Boolean> connectOnlySSL) throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*  519 */     final NetworkUtilsHttpGetResult networkUtilsGetResult = new NetworkUtilsHttpGetResult();
/*      */     
/*  521 */     httpGetExecute(host, httpPort, isBatch, canUseSSL, uri, connectOnlySSL, new HttpGetExecutor()
/*      */         {
/*      */           public void execute(CloseableHttpResponse httpResponse) throws ConnectorBaseException, IOException {
/*  524 */             InputStream is = null;
/*  525 */             BufferedReader reader = null;
/*      */             try {
/*  527 */               networkUtilsGetResult.setResponseCode(httpResponse.getCode());
/*  528 */               is = httpResponse.getEntity().getContent();
/*  529 */               reader = new BufferedReader(new InputStreamReader(is));
/*  530 */               networkUtilsGetResult.setResponseLine(reader.readLine());
/*      */             } finally {
/*      */               try {
/*  533 */                 if (reader != null)
/*  534 */                   reader.close(); 
/*  535 */               } catch (IOException iOException) {}
/*      */               
/*      */               try {
/*  538 */                 if (is != null)
/*  539 */                   is.close(); 
/*  540 */               } catch (IOException iOException) {}
/*      */             } 
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  546 */     return networkUtilsGetResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServerIdTO getServerConfForInput(String host, int httpPort, boolean isBatch) throws ConnectorBaseException, UnknownHostException {
/*  566 */     Optional<Boolean> connectType = Optional.empty();
/*  567 */     return getServerConfForInput(host, httpPort, isBatch, connectType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T safeUnmarshall(InputStream is, Class<T> clazz) throws Exception {
/*  579 */     SAXParserFactory spf = SAXParserFactory.newInstance();
/*  580 */     spf.setFeature("http://xml.org/sax/features/external-general-entities", false);
/*  581 */     spf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
/*  582 */     spf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  588 */     spf.setFeature("http://xml.org/sax/features/validation", false);
/*  589 */     spf.setFeature("http://xml.org/sax/features/namespaces", true);
/*  590 */     spf.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
/*      */     
/*  592 */     Source xmlSource = new SAXSource(spf.newSAXParser().getXMLReader(), new InputSource(is));
/*      */     
/*  594 */     JAXBContext ctx = JAXBContext.newInstance(new Class[] { clazz });
/*  595 */     Unmarshaller um = ctx.createUnmarshaller();
/*  596 */     return (T)um.unmarshal(xmlSource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T httpGetResponse(final String host, final int httpPort, boolean isBatch, Optional<Boolean> connectType, final String uri, final Class<T> responseClass) throws ConnectorBaseException, UnknownHostException {
/*  620 */     if (host == null || host.isBlank()) {
/*  621 */       return null;
/*      */     }
/*      */     
/*      */     class Response
/*      */     {
/*      */       T val;
/*      */     };
/*  628 */     final Response response = new Response();
/*      */     
/*      */     try {
/*  631 */       httpGetExecute(host, httpPort, isBatch, true, uri, connectType, new HttpGetExecutor()
/*      */           {
/*      */             public void execute(CloseableHttpResponse httpResponse) throws ConnectorBaseException, IOException
/*      */             {
/*  635 */               InputStream is = null;
/*      */               try {
/*  637 */                 is = httpResponse.getEntity().getContent();
/*  638 */                 response.val = NetworkUtils.safeUnmarshall(is, responseClass);
/*      */               }
/*  640 */               catch (Exception ex) {
/*  641 */                 throw new GeneralErrorException(String.format("Invalid server resonse from host '%s', port '%s', URI '%s'.", new Object[] { this.val$host, Integer.valueOf(this.val$httpPort), this.val$uri }), ex);
/*      */               } finally {
/*      */                 
/*      */                 try {
/*  645 */                   if (is != null) {
/*  646 */                     is.close();
/*      */                   }
/*      */                 }
/*  649 */                 catch (IOException iOException) {}
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */           });
/*      */     
/*      */     }
/*  657 */     catch (UnknownHostException ex) {
/*  658 */       String errMsg = String.format("Server on host '%s' cannot be found", new Object[] { host });
/*  659 */       log.debug(errMsg + ": " + errMsg);
/*  660 */       throw ex;
/*      */     }
/*  662 */     catch (IOException ex) {
/*  663 */       throw new ServerNotAchievableException(String.format("Server on host '%s' with port '%d' is not achievable.", new Object[] { host, Integer.valueOf(httpPort) }), ex);
/*      */     }
/*  665 */     catch (IllegalArgumentException ex) {
/*  666 */       throw new IllegalArgumentException(String.format("Illegal port %s while contacting server on host '%s'.", new Object[] { Integer.valueOf(httpPort), host }), ex);
/*      */     }
/*  668 */     catch (Exception ex) {
/*  669 */       throw new GeneralErrorException(String.format("General error occurred while contacting server on host '%s' with port '%s'.", new Object[] { host, Integer.valueOf(httpPort) }), ex);
/*      */     } 
/*      */     
/*  672 */     return response.val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServerIdTO getServerConfForInput(String host, int httpPort, boolean isBatch, Optional<Boolean> connectType) throws ConnectorBaseException, UnknownHostException {
/*  695 */     String uri = "/iS3SecWebServices/sec/sysconfig/getServerId";
/*  696 */     return httpGetResponse(host, httpPort, isBatch, connectType, uri, ServerIdTO.class);
/*      */   }
/*      */   
/*      */   public static ServerIdTO unmarshallServerIdTO(InputStream is) throws Exception {
/*  700 */     return safeUnmarshall(is, ServerIdTO.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SessionInfoTO getSessionInfo(String encodedSessionInfo, String url) throws ConnectorBaseException, UnknownHostException {
/*  715 */     return getSessionInfo(encodedSessionInfo, url, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SessionInfoTO getSessionInfo(final String encodedSessionInfo, String url, final boolean isBatch) throws ConnectorBaseException, UnknownHostException {
/*      */     try {
/*  733 */       SessionInfoTO sessionInfo = dispatchUrl(url, new UrlDispatch<SessionInfoTO>()
/*      */           {
/*      */             public SessionInfoTO invalid()
/*      */             {
/*  737 */               return null;
/*      */             }
/*      */ 
/*      */             
/*      */             public SessionInfoTO valid(String host, int port) throws ConnectorBaseException, UnknownHostException {
/*  742 */               return valid(host, port, Optional.empty());
/*      */             }
/*      */ 
/*      */             
/*      */             public SessionInfoTO valid(String host, int port, Optional<Boolean> connectType) throws ConnectorBaseException, UnknownHostException {
/*  747 */               return NetworkUtils.getSessionInfo(encodedSessionInfo, host, port, isBatch, connectType);
/*      */             }
/*      */           });
/*  750 */       return sessionInfo;
/*      */     }
/*  752 */     catch (ConnectorBaseException|UnknownHostException|RuntimeException ex) {
/*  753 */       throw ex;
/*      */     }
/*  755 */     catch (Exception ex) {
/*  756 */       throw new RuntimeException("Unexpected exception type", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static SessionInfoTO getSessionInfo(String encodedSessionInfo, String host, int httpPort, boolean isBatch, Optional<Boolean> connectType) throws ConnectorBaseException, UnknownHostException {
/*  762 */     String uri = "/iS3WebServices/is3API/sessionInfo/getSessionInfo?session=" + URLEncoder.encode(encodedSessionInfo, StandardCharsets.UTF_8);
/*  763 */     return httpGetResponse(host, httpPort, isBatch, connectType, uri, SessionInfoTO.class);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getHostFromInputStream(String input) {
/*  768 */     Matcher match = HOST_PORT_PATTERN.matcher(input);
/*      */     
/*  770 */     if (match.find()) {
/*  771 */       return match.group(2);
/*      */     }
/*      */     
/*  774 */     return input;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int getPortFromInputStream(String input) {
/*  779 */     Matcher match = HOST_PORT_PATTERN.matcher(input);
/*      */     
/*  781 */     if (match.find()) {
/*  782 */       String port = match.group(4);
/*      */       try {
/*  784 */         int portNum = Integer.parseInt(port);
/*  785 */         return portNum;
/*      */       }
/*  787 */       catch (NumberFormatException numberFormatException) {}
/*      */     } 
/*      */ 
/*      */     
/*  791 */     return Integer.MIN_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPrefixFromInputStream(String input) {
/*  800 */     Matcher match = HOST_PORT_PATTERN.matcher(input);
/*  801 */     String prefix = null;
/*  802 */     if (match.find()) {
/*  803 */       prefix = match.group(1);
/*      */     }
/*  805 */     return prefix;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String removeSpacesFromInputStream(String input) {
/*  810 */     Matcher match = HOST_PORT_PATTERN.matcher(input);
/*  811 */     if (match.find()) {
/*  812 */       String prefix = match.group(1);
/*  813 */       String host = match.group(2);
/*  814 */       String port = match.group(4);
/*  815 */       if (port != null && !port.isEmpty()) {
/*  816 */         String rval = (prefix != null) ? String.format("%s%s:%s", new Object[] { prefix, host, port }) : String.format("%s:%s", new Object[] { host, port });
/*  817 */         return rval;
/*      */       } 
/*  819 */       return host;
/*      */     } 
/*  821 */     return input;
/*      */   }
/*      */   
/*      */   public static int getDefaultHttpPort() {
/*  825 */     String variable = System.getenv("IS3_SERVER_WEB_DEFAULT_HTTP_PORT");
/*      */     try {
/*  827 */       Integer port = Integer.getInteger(variable);
/*  828 */       if (port != null) {
/*  829 */         return port.intValue();
/*      */       }
/*      */     }
/*  832 */     catch (Exception exc) {
/*  833 */       return 31000;
/*      */     } 
/*      */     
/*  836 */     return 31000;
/*      */   }
/*      */   
/*      */   public static int getDefaultHttpsPort() {
/*  840 */     String variable = System.getenv("IS3_SERVER_WEB_DEFAULT_HTTPS_PORT");
/*      */     try {
/*  842 */       Integer port = Integer.getInteger(variable);
/*  843 */       if (port != null) {
/*  844 */         return port.intValue();
/*      */       }
/*      */     }
/*  847 */     catch (Exception exc) {
/*  848 */       return 31443;
/*      */     } 
/*      */     
/*  851 */     return 31443;
/*      */   }
/*      */   
/*      */   public static String checkLocalhostCornerCase(String serverHostInput) {
/*  855 */     if (serverHostInput.matches("^\\s*((localhost)|(127\\.0\\.0\\.1))\\s*(:\\s*(\\d+)\\s*)?$")) {
/*  856 */       return convertHostForLocalhostCornerCase(serverHostInput, "^\\s*((localhost)|(127\\.0\\.0\\.1))\\s*(:\\s*(\\d+)\\s*)?$");
/*      */     }
/*      */     
/*  859 */     return serverHostInput;
/*      */   }
/*      */   
/*      */   private static String convertHostForLocalhostCornerCase(String server, String regexp) {
/*      */     try {
/*  864 */       InetAddress thisIp = InetAddress.getLocalHost();
/*  865 */       String ipAddress = thisIp.getHostAddress().toString();
/*      */       
/*  867 */       Pattern pattern = Pattern.compile(regexp);
/*  868 */       Matcher matcher = pattern.matcher(server);
/*      */       
/*  870 */       if (matcher.find()) {
/*  871 */         return server.replace(matcher.group(1), ipAddress);
/*      */       
/*      */       }
/*      */     }
/*  875 */     catch (Exception exception) {}
/*      */ 
/*      */     
/*  878 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> T dispatchUrl(String url, UrlDispatch<T> urlDispatch) throws Exception {
/*  891 */     if (url != null && !url.isBlank()) {
/*  892 */       String host = getHostFromInputStream(url);
/*  893 */       int port = getPortFromInputStream(url);
/*  894 */       if (url.equals(host)) {
/*  895 */         return urlDispatch.invalid();
/*      */       }
/*  897 */       String prefix = getPrefixFromInputStream(url);
/*      */       
/*  899 */       if (prefix == null) {
/*  900 */         return urlDispatch.valid(host, port);
/*      */       }
/*  902 */       if (prefix.toLowerCase().startsWith("https")) {
/*      */         
/*  904 */         Optional<Boolean> optional = Optional.of(Boolean.valueOf(true));
/*  905 */         return urlDispatch.valid(host, port, optional);
/*      */       } 
/*  907 */       if (prefix.toLowerCase().startsWith("http")) {
/*      */         
/*  909 */         Optional<Boolean> optional = Optional.of(Boolean.valueOf(false));
/*  910 */         return urlDispatch.valid(host, port, optional);
/*      */       } 
/*      */ 
/*      */       
/*  914 */       Optional<Boolean> connectOnlySSL = Optional.empty();
/*  915 */       return urlDispatch.valid(host, port, connectOnlySSL);
/*      */     } 
/*      */     
/*  918 */     return urlDispatch.invalid();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServerIdTO getServerConfForInput(String url) throws ConnectorBaseException, UnknownHostException {
/*  933 */     return getServerConfForInput(url, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServerIdTO getServerConfForInput(String url, final boolean isBatch) throws ConnectorBaseException, UnknownHostException {
/*      */     try {
/*  951 */       ServerIdTO sit = dispatchUrl(url, new UrlDispatch<ServerIdTO>()
/*      */           {
/*      */             public ServerIdTO invalid()
/*      */             {
/*  955 */               return null;
/*      */             }
/*      */ 
/*      */             
/*      */             public ServerIdTO valid(String host, int port) throws ConnectorBaseException, UnknownHostException {
/*  960 */               return NetworkUtils.getServerConfForInput(host, port, isBatch);
/*      */             }
/*      */ 
/*      */             
/*      */             public ServerIdTO valid(String host, int port, Optional<Boolean> connectType) throws ConnectorBaseException, UnknownHostException {
/*  965 */               return NetworkUtils.getServerConfForInput(host, port, isBatch, connectType);
/*      */             }
/*      */           });
/*  968 */       return sit;
/*      */     }
/*  970 */     catch (ConnectorBaseException|UnknownHostException|RuntimeException ex) {
/*  971 */       throw ex;
/*      */     }
/*  973 */     catch (Exception ex) {
/*  974 */       throw new RuntimeException("Unexpected exception type", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServerIdTO getServerConfForInput(String host, int httpPort) throws ConnectorBaseException, UnknownHostException {
/*  994 */     return getServerConfForInput(host, httpPort, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createHttpUrl(ServerIdTO serverIdTO, String server) {
/* 1009 */     return String.format("%s://%s:%s", new Object[] {
/* 1010 */           serverIdTO.isSslEnabled() ? "https" : "http", 
/* 1011 */           getHostFromInputStream((null == server) ? serverIdTO.getServerName() : server), 
/* 1012 */           Integer.valueOf(serverIdTO.isSslEnabled() ? serverIdTO.getHttpsPort() : serverIdTO.getWebPort())
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public static class NetworkUtilsHttpGetResult
/*      */   {
/*      */     private int responseCode;
/*      */     
/*      */     private String responseLine;
/*      */ 
/*      */     
/*      */     public void setResponseCode(int responseCode) {
/* 1025 */       this.responseCode = responseCode;
/*      */     }
/*      */     
/*      */     public int getResponseCode() {
/* 1029 */       return this.responseCode;
/*      */     }
/*      */     
/*      */     public void setResponseLine(String responseLine) {
/* 1033 */       this.responseLine = responseLine;
/*      */     }
/*      */     
/*      */     public String getResponseLine() {
/* 1037 */       return this.responseLine;
/*      */     }
/*      */   }
/*      */   
/*      */   private static interface UrlDispatch<T> {
/*      */     T invalid() throws Exception;
/*      */     
/*      */     T valid(String param1String, int param1Int) throws Exception;
/*      */     
/*      */     T valid(String param1String, int param1Int, Optional<Boolean> param1Optional) throws Exception;
/*      */   }
/*      */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\NetworkUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */