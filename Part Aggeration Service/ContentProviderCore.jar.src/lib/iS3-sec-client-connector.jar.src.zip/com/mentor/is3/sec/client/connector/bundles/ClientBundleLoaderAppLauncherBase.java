/*     */ package com.mentor.is3.sec.client.connector.bundles;
/*     */ 
/*     */ import com.mentor.is3.sec.client.utils.bundles.ClientBundleException;
/*     */ import com.mentor.is3.sec.client.utils.bundles.ClientBundleLoaderBuilderException;
/*     */ import com.mentor.is3.sec.client.utils.bundles.WdirSetter;
/*     */ import com.mentor.is3.sec.client.utils.messages.LoginLibMessages;
/*     */ import com.mentor.is3.sec.infra.bundles.BundleInfo;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientBundleLoaderAppLauncherBase
/*     */ {
/*  26 */   protected String bundleFileName = null;
/*  27 */   protected String serverUrl = null;
/*  28 */   protected String bundleSddHomeExePath = null;
/*  29 */   private String sddHomeEnv = null;
/*  30 */   private List<String> programArgs = new ArrayList<>();
/*     */   
/*  32 */   private String errorMessage = null;
/*  33 */   private String additionalErrorMessage = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientBundleLoaderAppLauncherBase(String bundleFileName, String serverUrl, String bundleSddHomeExePath, String sddHomeEnv, List<String> programArgs) {
/*  66 */     this.bundleFileName = bundleFileName;
/*  67 */     this.serverUrl = serverUrl;
/*  68 */     this.bundleSddHomeExePath = bundleSddHomeExePath;
/*  69 */     this.sddHomeEnv = sddHomeEnv;
/*  70 */     this.programArgs = programArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleInfo.Status getBundleInfoAndLaunch() throws ClientBundleException {
/*  81 */     return getBundleInfoAndLaunch(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BundleInfo.Status getBundleInfoAndLaunch(String errorMessage, String additionalMessage) throws ClientBundleException {
/* 103 */     if (this.bundleSddHomeExePath.toUpperCase().startsWith("SDD_HOME")) {
/*     */       
/* 105 */       String sddHomeString = "SDD_HOME";
/* 106 */       int startOffset = this.bundleSddHomeExePath.toUpperCase().indexOf(sddHomeString) + sddHomeString.length();
/* 107 */       this.bundleSddHomeExePath = this.bundleSddHomeExePath.substring(startOffset);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     BundleInfo bundleInfo = getBundleInfo();
/*     */     
/* 117 */     if (bundleInfo == null || bundleInfo.getStatus() == BundleInfo.Status.ERROR) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       errorMessage = "There was an error downloading the application.";
/* 124 */       this.additionalErrorMessage = null;
/* 125 */       if (bundleInfo != null && bundleInfo.getErrorMsg() != null && !bundleInfo.getErrorMsg().isEmpty()) {
/* 126 */         this.additionalErrorMessage = " " + bundleInfo.getErrorMsg();
/*     */       }
/*     */       
/* 129 */       return BundleInfo.Status.ERROR;
/*     */     } 
/* 131 */     if (bundleInfo.getStatus() == BundleInfo.Status.CANCEL) {
/* 132 */       return BundleInfo.Status.CANCEL;
/*     */     }
/* 134 */     launchApplication(bundleInfo);
/* 135 */     return BundleInfo.Status.SUCCESS;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 140 */     return this.errorMessage;
/*     */   }
/*     */   
/*     */   public String getAdditionalErrorMessage() {
/* 144 */     return this.additionalErrorMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BundleInfo getBundleInfo() {
/*     */     try {
/* 150 */       ClientBundleLoaderBaseBuilder clientBundleLoaderBaseBuilder = new ClientBundleLoaderBaseBuilder();
/* 151 */       clientBundleLoaderBaseBuilder.setBundleFileName(this.bundleFileName).setServerUrl(this.serverUrl);
/* 152 */       ClientBundleLoaderBase clientBundleLoaderBase = clientBundleLoaderBaseBuilder.build();
/* 153 */       return clientBundleLoaderBase.provideClientBundleInfo();
/*     */     }
/* 155 */     catch (ClientBundleLoaderBuilderException e) {
/* 156 */       BundleInfo bundleInfo = ClientBundleLoaderBase.getErrorBundleInfo(this.serverUrl, 
/* 157 */           LoginLibMessages.getString("ECSCBL_ERROR_UNKNOWN_ERROR"), "Error building client bundle loader: " + e
/* 158 */           .getMessage());
/* 159 */       return bundleInfo;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void launchApplication(BundleInfo bundleInfo) throws ClientBundleException {
/* 165 */     String bundleSddHome = bundleInfo.getSddHome();
/* 166 */     String sddPlatform = bundleInfo.getSddPlatform();
/* 167 */     String javaHome = bundleInfo.getJavaHome();
/* 168 */     String wdir = (new WdirSetter(bundleInfo)).getReleaseWdirForBundle();
/*     */     
/* 170 */     String pathToApplication = bundleSddHome + bundleSddHome + File.separator;
/* 171 */     if (this.programArgs == null) {
/* 172 */       this.programArgs = new ArrayList<>();
/*     */     }
/*     */ 
/*     */     
/* 176 */     this.programArgs.add(0, pathToApplication);
/*     */     
/* 178 */     ProcessBuilder pb = new ProcessBuilder(this.programArgs);
/* 179 */     pb.inheritIO();
/* 180 */     if (this.sddHomeEnv == null || this.sddHomeEnv.isBlank()) {
/* 181 */       pb.environment().put("SDD_HOME", bundleSddHome);
/*     */     } else {
/* 183 */       pb.environment().put("SDD_HOME", this.sddHomeEnv);
/*     */     } 
/* 185 */     pb.environment().put("SDD_PLATFORM", sddPlatform);
/* 186 */     pb.environment().put("SDD_VERSION", bundleInfo.getReleaseInfo().getSddVersion());
/* 187 */     pb.environment().put("JAVA_HOME", javaHome);
/* 188 */     pb.environment().put("SERVER_URL", bundleInfo.getServerUrl());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     pb.environment().put("WDIR", wdir);
/*     */     
/* 197 */     startProcess(pb);
/*     */   }
/*     */   
/*     */   protected void startProcess(ProcessBuilder pb) throws ClientBundleException {
/*     */     try {
/* 202 */       Process process = pb.start();
/*     */ 
/*     */       
/* 205 */       process.waitFor();
/* 206 */     } catch (IOException e) {
/* 207 */       throw new ClientBundleException("Got IOException while launching application.", e);
/* 208 */     } catch (InterruptedException e) {
/* 209 */       throw new ClientBundleException("Got InterruptedException while launching application.", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\bundles\ClientBundleLoaderAppLauncherBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */