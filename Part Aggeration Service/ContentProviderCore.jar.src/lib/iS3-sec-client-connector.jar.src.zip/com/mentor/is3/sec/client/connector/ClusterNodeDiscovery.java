/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.client.connector.exceptions.ConnectorBaseException;
/*     */ import com.mentor.is3.server.api.transfer.config.ServerIdTO;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterNodeDiscovery
/*     */ {
/*     */   private String host;
/*     */   private Integer port;
/*     */   private boolean ssl;
/*     */   private String webport;
/*     */   private Timer timer;
/*     */   private static final int TIME_INTERVAL = 30;
/*     */   private TimerTask nodeDiscoveryTask;
/*     */   private CopyOnWriteArrayList<String> clusterNodes;
/*     */   
/*     */   public ClusterNodeDiscovery(String server, String port, String remotingport, boolean https) {
/*  39 */     this.host = server;
/*  40 */     this.port = Integer.valueOf(Integer.parseInt(port));
/*  41 */     this.ssl = https;
/*  42 */     this.webport = remotingport;
/*  43 */     this.timer = new Timer("cluster ping timer", true);
/*  44 */     this.clusterNodes = new CopyOnWriteArrayList<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDiscovery() {
/*  49 */     scheduleTimer();
/*     */   }
/*     */   
/*     */   public void stopDiscovery() {
/*  53 */     this.nodeDiscoveryTask.cancel();
/*  54 */     this.timer.cancel();
/*     */   }
/*     */   
/*     */   public String gethttpProviderUrls() {
/*  58 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  60 */     for (String node : this.clusterNodes) {
/*  61 */       sb.append("http-remoting://").append(node).append(":")
/*  62 */         .append(this.webport).append(",");
/*     */     }
/*  64 */     if (sb.length() > 1) {
/*  65 */       sb.deleteCharAt(sb.length() - 1);
/*     */     }
/*     */     
/*  68 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private void scheduleTimer() {
/*  73 */     if (this.nodeDiscoveryTask != null)
/*  74 */       this.nodeDiscoveryTask.cancel(); 
/*  75 */     createNodeDiscoveryTask();
/*  76 */     this.timer.schedule(this.nodeDiscoveryTask, 30000L);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createNodeDiscoveryTask() {
/*  81 */     this.nodeDiscoveryTask = new TimerTask()
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           try {
/*  86 */             ClusterNodeDiscovery.this.discoverClusterNodes();
/*     */           }
/*  88 */           catch (Throwable throwable) {}
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void discoverClusterNodes() {
/*     */     try {
/*  99 */       scheduleTimer();
/* 100 */       ServerIdTO serverIdTO = NetworkUtils.getServerConfForInput(this.host, this.port.intValue(), true);
/* 101 */       this.clusterNodes.clear();
/* 102 */       this.clusterNodes.addAll(serverIdTO.getNodeList());
/* 103 */     } catch (ConnectorBaseException|java.net.UnknownHostException e) {
/*     */       
/* 105 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\ClusterNodeDiscovery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */