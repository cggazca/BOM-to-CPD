/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3SSLSocketFactory
/*     */   extends SocketFactory
/*     */ {
/*  31 */   private static IS3SSLSocketFactory instance = null;
/*     */   
/*  33 */   private SSLContext sslContext = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3SSLSocketFactory getDefault() {
/*  40 */     if (instance == null) {
/*     */       try {
/*  42 */         instance = new IS3SSLSocketFactory();
/*  43 */         instance.initFactory();
/*     */       }
/*  45 */       catch (Exception e) {
/*  46 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  50 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initFactory() throws Exception {
/*  60 */     this.sslContext = SSLContext.getInstance("TLS");
/*  61 */     this.sslContext.init(null, new TrustManager[] { new SavingTrustManager(new NonValidatingTM()) }, new SecureRandom());
/*     */   }
/*     */ 
/*     */   
/*     */   public Socket createSocket(String host, int port) throws IOException, UnknownHostException {
/*  66 */     return this.sslContext.getSocketFactory().createSocket(host, port);
/*     */   }
/*     */ 
/*     */   
/*     */   public Socket createSocket(InetAddress host, int port) throws IOException {
/*  71 */     return this.sslContext.getSocketFactory().createSocket(host, port);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException, UnknownHostException {
/*  77 */     return this.sslContext.getSocketFactory().createSocket(host, port, localHost, localPort);
/*     */   }
/*     */ 
/*     */   
/*     */   public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
/*  82 */     return this.sslContext.getSocketFactory().createSocket(address, port, localAddress, localPort);
/*     */   }
/*     */   
/*     */   public SSLContext getSSLContext() {
/*  86 */     return this.sslContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class NonValidatingTM
/*     */     implements X509TrustManager
/*     */   {
/*     */     public X509Certificate[] getAcceptedIssuers() {
/*  97 */       return new X509Certificate[0];
/*     */     }
/*     */ 
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] certs, String authType) {}
/*     */ 
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] certs, String authType) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static class SavingTrustManager
/*     */     implements X509TrustManager
/*     */   {
/*     */     private final X509TrustManager tm;
/*     */     
/*     */     protected static X509Certificate[] chain;
/*     */     
/*     */     SavingTrustManager(X509TrustManager tm) {
/* 116 */       this.tm = tm;
/*     */     }
/*     */     
/*     */     public X509Certificate[] getAcceptedIssuers() {
/* 120 */       return this.tm.getAcceptedIssuers();
/*     */     }
/*     */ 
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 125 */       this.tm.checkClientTrusted(chain, authType);
/*     */     }
/*     */ 
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 130 */       SavingTrustManager.chain = chain;
/* 131 */       this.tm.checkServerTrusted(chain, authType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static X509Certificate[] getChain() {
/* 139 */       return chain;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3SSLSocketFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */