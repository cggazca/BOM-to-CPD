/*    */ package com.mentor.is3.sec.client.connector;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.auth.callback.TextInputCallback;
/*    */ import javax.security.auth.callback.TextOutputCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ import javax.security.sasl.RealmCallback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IS3CallbackHandler
/*    */   implements CallbackHandler
/*    */ {
/*    */   private String username;
/*    */   private char[] password;
/*    */   
/*    */   public IS3CallbackHandler(String username, char[] password) {
/* 46 */     this.username = username;
/* 47 */     this.password = password;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 62 */     for (int i = 0; i < callbacks.length; i++) {
/* 63 */       if (callbacks[i] instanceof NameCallback) {
/* 64 */         NameCallback nc = (NameCallback)callbacks[i];
/* 65 */         nc.setName(this.username);
/*    */       }
/* 67 */       else if (callbacks[i] instanceof TextOutputCallback) {
/* 68 */         TextOutputCallback toc = (TextOutputCallback)callbacks[i];
/* 69 */         switch (toc.getMessageType()) {
/*    */           case 0:
/*    */           case 2:
/*    */           case 1:
/*    */             break;
/*    */ 
/*    */           
/*    */           default:
/* 77 */             throw new IOException("Unsupported message type: " + toc.getMessageType());
/*    */         } 
/*    */       
/* 80 */       } else if (callbacks[i] instanceof PasswordCallback) {
/* 81 */         PasswordCallback pc = (PasswordCallback)callbacks[i];
/* 82 */         pc.setPassword(this.password);
/*    */       }
/* 84 */       else if (callbacks[i] instanceof RealmCallback) {
/* 85 */         RealmCallback rcb = (RealmCallback)callbacks[i];
/* 86 */         if (rcb.getText() == null) {
/* 87 */           rcb.setText(rcb.getDefaultText());
/*    */         }
/* 89 */       } else if (callbacks[i] instanceof TextInputCallback) {
/*    */         
/* 91 */         TextInputCallback callback = (TextInputCallback)callbacks[i];
/* 92 */         callback.setText((new BufferedReader(new InputStreamReader(System.in))).readLine());
/*    */       } else {
/*    */         
/* 95 */         throw new UnsupportedCallbackException(callbacks[i], "Unrecognized Callback in IS3CallbackHandler.");
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3CallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */