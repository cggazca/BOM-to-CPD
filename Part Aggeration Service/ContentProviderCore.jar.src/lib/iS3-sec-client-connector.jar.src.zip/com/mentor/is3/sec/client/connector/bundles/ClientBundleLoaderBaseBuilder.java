/*    */ package com.mentor.is3.sec.client.connector.bundles;
/*    */ 
/*    */ import com.mentor.is3.sec.client.connector.NetworkUtils;
/*    */ import com.mentor.is3.sec.client.connector.SSLConnectionCheckCache;
/*    */ import com.mentor.is3.sec.client.connector.SSLServerChecks;
/*    */ import com.mentor.is3.sec.client.utils.bundles.ClientBundleLoaderBuilderException;
/*    */ import com.mentor.is3.sec.client.utils.bundles.ServerDialogInfo;
/*    */ import com.mentor.is3.sec.infra.CommonUtils;
/*    */ import java.security.KeyManagementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClientBundleLoaderBaseBuilder
/*    */ {
/* 24 */   private String bundleFileName = null;
/* 25 */   private String serverUrl = null;
/*    */   private boolean doNotPrompt = true;
/* 27 */   private int arch = 0;
/* 28 */   private boolean windows = CommonUtils.isWindows();
/*    */   
/*    */   private boolean debug = false;
/*    */   
/*    */   ClientBundleLoaderBase build() throws ClientBundleLoaderBuilderException {
/* 33 */     if (this.bundleFileName == null || this.bundleFileName.isBlank()) {
/* 34 */       throw new ClientBundleLoaderBuilderException("bundleFileName cannot be null or blank");
/*    */     }
/*    */     
/* 37 */     if (this.serverUrl == null || this.serverUrl.isBlank()) {
/* 38 */       throw new ClientBundleLoaderBuilderException("serverUrl cannot be null or blank");
/*    */     }
/*    */     
/* 41 */     if (this.arch != 32 && this.arch != 64) {
/* 42 */       this.arch = (System.getProperty("os.arch").endsWith("64") == true) ? 64 : 32;
/*    */     }
/*    */     
/* 45 */     ServerDialogInfo serverDialogInfo = new ServerDialogInfo();
/* 46 */     serverDialogInfo.setServerUrl(this.serverUrl);
/* 47 */     serverDialogInfo.setHost(NetworkUtils.getHostFromInputStream(serverDialogInfo.getServerUrl()));
/* 48 */     serverDialogInfo.setPort(NetworkUtils.getPortFromInputStream(serverDialogInfo.getServerUrl()));
/* 49 */     serverDialogInfo.setCancelled(false);
/*    */     
/*    */     try {
/* 52 */       SSLServerChecks sslcheck = SSLConnectionCheckCache.getInstance().getSSLPortCheckObject(serverDialogInfo.getHost(), serverDialogInfo
/* 53 */           .getPort(), false);
/* 54 */       serverDialogInfo.setSsl(sslcheck.isSslEnabled());
/* 55 */     } catch (KeyManagementException|java.security.NoSuchAlgorithmException|com.mentor.is3.sec.common.SSLInitializationException e) {
/* 56 */       serverDialogInfo.setSuccess(false);
/* 57 */       serverDialogInfo
/* 58 */         .setErrorMsg("Unable to connect to server using provided information: " + e.getLocalizedMessage());
/*    */     } 
/* 60 */     if (serverDialogInfo.isSsl()) {
/* 61 */       serverDialogInfo.setProtocol("https");
/*    */     } else {
/* 63 */       serverDialogInfo.setProtocol("http");
/*    */     } 
/* 65 */     ClientBundleLoaderBase clientBundleLoader = new ClientBundleLoaderBase(this.bundleFileName, this.serverUrl, this.doNotPrompt, this.arch, this.windows, this.debug, serverDialogInfo, null);
/*    */     
/* 67 */     return clientBundleLoader;
/*    */   }
/*    */   
/*    */   ClientBundleLoaderBaseBuilder setBundleFileName(String bundleFileName) {
/* 71 */     this.bundleFileName = bundleFileName;
/* 72 */     return this;
/*    */   }
/*    */   
/*    */   ClientBundleLoaderBaseBuilder setServerUrl(String serverUrl) {
/* 76 */     this.serverUrl = serverUrl;
/* 77 */     return this;
/*    */   }
/*    */   
/*    */   ClientBundleLoaderBaseBuilder setDoNotPrompt(boolean doNotPrompt) {
/* 81 */     this.doNotPrompt = doNotPrompt;
/* 82 */     return this;
/*    */   }
/*    */   
/*    */   ClientBundleLoaderBaseBuilder setArch(int arch) {
/* 86 */     this.arch = arch;
/* 87 */     return this;
/*    */   }
/*    */   
/*    */   ClientBundleLoaderBaseBuilder setWindows(boolean isWindows) {
/* 91 */     this.windows = isWindows;
/* 92 */     return this;
/*    */   }
/*    */   
/*    */   ClientBundleLoaderBaseBuilder setDebug(boolean debug) {
/* 96 */     this.debug = debug;
/* 97 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\bundles\ClientBundleLoaderBaseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */