/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.infrasec.cert.manager.CertificateManager;
/*     */ import com.mentor.infrasec.cert.manager.OpenDialog;
/*     */ import com.mentor.is3.sec.common.ReloadableX509TrustManager;
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.SocketException;
/*     */ import java.net.URL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Arrays;
/*     */ import java.util.Optional;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.SSLHandshakeException;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLServerChecks
/*     */ {
/*  31 */   private static Logger log = Logger.getLogger(SSLServerChecks.class); private boolean sslEnabled = false; private boolean isBatchLogin = false; private static final String MENTOR_TRUST_STORE = "mentor_sdd_cacerts"; private String host;
/*     */   private int port;
/*     */   private boolean sslcheckperformed;
/*     */   private boolean sslInfoSet;
/*     */   private boolean AES256Configured;
/*     */   private String servercipher;
/*     */   private X509Certificate[] certificateChain;
/*     */   
/*     */   public boolean isSslEnabled() {
/*  40 */     return this.sslEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLServerChecks(String server, int port) {
/*  52 */     this(server, port, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSslEnabled(boolean sslEnabled) {
/*  64 */     this.sslEnabled = sslEnabled;
/*     */   }
/*     */   
/*     */   public boolean isAES256Configured() {
/*  68 */     return this.AES256Configured;
/*     */   }
/*     */   
/*     */   public void setAES256Configured(boolean aES256Configured) {
/*  72 */     this.AES256Configured = aES256Configured;
/*     */   }
/*     */   
/*  75 */   public SSLServerChecks(String server, int port, boolean isBatch) { this.AES256Configured = true; this.host = server; this.port = port;
/*     */     this.sslcheckperformed = false;
/*     */     this.sslInfoSet = false;
/*  78 */     this.isBatchLogin = isBatch; } public String getServerCipher() { return this.servercipher; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Certificate[] getCertificateChain() {
/*  84 */     return this.certificateChain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setupSSLInfo() throws Exception {
/*     */     CertificateManager certMan;
/* 100 */     log.debug("setupSSLInfo, sslEnabled = " + this.sslEnabled + ", infoSet = " + this.sslInfoSet);
/* 101 */     if (!this.sslEnabled)
/* 102 */       return false; 
/* 103 */     if (this.sslInfoSet) {
/* 104 */       return true;
/*     */     }
/* 106 */     SSLSocket sslSocket = null;
/* 107 */     SocketFactory sslSocketFactory = IS3SSLSocketFactory.getDefault();
/* 108 */     log.debug("socketFactory created to: " + this.host + ":" + this.port + " created");
/* 109 */     sslSocket = (SSLSocket)sslSocketFactory.createSocket(this.host, this.port);
/* 110 */     this.certificateChain = null;
/*     */     try {
/* 112 */       sslSocket.startHandshake();
/* 113 */       this.certificateChain = IS3SSLSocketFactory.SavingTrustManager.getChain();
/* 114 */       log.debug("handshake complete");
/* 115 */       log.trace("certs: " + Arrays.toString((Object[])this.certificateChain));
/*     */     } finally {
/*     */       
/* 118 */       sslSocket.close();
/*     */     } 
/*     */ 
/*     */     
/* 122 */     if (this.isBatchLogin) {
/* 123 */       certMan = new CertificateManager(OpenDialog.COMMAND.REJECT);
/*     */     } else {
/* 125 */       certMan = new CertificateManager(OpenDialog.COMMAND.SHOW_GUI);
/*     */     } 
/*     */     
/* 128 */     certMan.setShowUntrustedDialog(false);
/*     */     
/* 130 */     boolean chainOkay = certMan.validateConnectionCert(this.host, this.certificateChain, "mentor_sdd_cacerts");
/*     */ 
/*     */     
/* 133 */     if (chainOkay) {
/* 134 */       log.debug("certificate is already valid");
/* 135 */       this.sslInfoSet = true;
/* 136 */       return true;
/*     */     } 
/*     */     
/* 139 */     if (!chainOkay && !this.isBatchLogin) {
/* 140 */       log.debug("certificate is not currently valid: " + certMan.getFailureReasonString());
/* 141 */       ReloadableX509TrustManager tm = SSLConnectionCheckCache.getInstance().getSslTrustManager();
/*     */       
/* 143 */       certMan.setShowUntrustedDialog(true);
/* 144 */       chainOkay = certMan.validateConnectionCert(this.host, this.certificateChain, "mentor_sdd_cacerts");
/* 145 */       if (!chainOkay) {
/*     */         
/* 147 */         log.debug("User canceled dialog, certificate is still not valid:" + certMan.getFailureReasonString());
/* 148 */         throw new Exception("Client rejected server certificate.");
/*     */       } 
/* 150 */       if (certMan.isUsingTempTrustStore()) {
/* 151 */         log.debug("Adding new cert to trustpath: " + certMan.getTempTrustStorePath());
/* 152 */         tm.addTrustStorePath(certMan.getTempTrustStorePath(), certMan.getTempTrustStorePassword());
/*     */       } 
/*     */ 
/*     */       
/* 156 */       if (chainOkay && certMan.isExpiredCert()) {
/* 157 */         ReloadableX509TrustManager.setIgnoreTimestamp(true);
/*     */       }
/* 159 */       log.debug("Start reload of TrustManager");
/* 160 */       tm.reloadTrustManager();
/*     */     } else {
/*     */       
/* 163 */       log.debug("CertificateManager says certchain is bad: " + certMan.getFailureReasonString());
/* 164 */       throw new Exception("Cannot validate server certificate. " + certMan.getFailureReasonString());
/*     */     } 
/* 166 */     this.sslInfoSet = true;
/* 167 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isServerSSLConfigured() throws Exception {
/* 183 */     if (this.sslcheckperformed) {
/* 184 */       return this.sslEnabled;
/*     */     }
/*     */     
/* 187 */     Exception toThrow = null;
/*     */ 
/*     */     
/* 190 */     HttpURLConnection connection = null;
/*     */     try {
/* 192 */       URL url = new URL("http://" + this.host + ":" + this.port);
/* 193 */       log.debug("Check non-ssl URL: " + url.toExternalForm());
/* 194 */       connection = (HttpURLConnection)url.openConnection();
/*     */ 
/*     */ 
/*     */       
/* 198 */       if (connection.getResponseCode() != 200) {
/* 199 */         throw new SocketException("Connection response code was not 200 (OK)");
/*     */       }
/* 201 */       this.sslEnabled = false;
/*     */     
/*     */     }
/* 204 */     catch (SocketException se) {
/*     */       
/* 206 */       log.debug("caught SocketException: " + se.getMessage());
/* 207 */       SSLSocket sslSocket = null;
/*     */       try {
/* 209 */         log.debug("Check ssl Connection to " + this.host + ":" + this.port);
/* 210 */         SocketFactory sslSocketFactory = IS3SSLSocketFactory.getDefault();
/* 211 */         sslSocket = (SSLSocket)sslSocketFactory.createSocket(this.host, this.port);
/*     */ 
/*     */ 
/*     */         
/* 215 */         sslSocket.setSoTimeout(1500);
/* 216 */         sslSocket.startHandshake();
/*     */ 
/*     */         
/* 219 */         log.debug("handshake complete, using cipher: " + sslSocket.getSession().getCipherSuite());
/* 220 */         this.servercipher = sslSocket.getSession().getCipherSuite();
/* 221 */         if (this.servercipher.contains("AES_256")) {
/* 222 */           this.AES256Configured = true;
/*     */         }
/* 224 */         this.sslEnabled = true;
/*     */       
/*     */       }
/* 227 */       catch (SSLHandshakeException ex) {
/*     */ 
/*     */         
/* 230 */         log.debug("Caught SSLHandshakeException: " + ex.getMessage());
/*     */         
/* 232 */         if (ex.getMessage().contains("handshake_failure")) {
/* 233 */           log.debug("Assume policy file issue");
/* 234 */           this.sslEnabled = true;
/* 235 */           this.AES256Configured = false;
/*     */         }
/*     */         else {
/*     */           
/* 239 */           toThrow = ex;
/*     */         }
/*     */       
/* 242 */       } catch (Exception e) {
/*     */         
/* 244 */         log.debug("Caught generic Exception of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 245 */         toThrow = e;
/*     */       } finally {
/*     */         
/*     */         try {
/* 249 */           if (sslSocket != null) {
/* 250 */             sslSocket.close();
/*     */           }
/* 252 */         } catch (IOException e) {
/*     */           
/* 254 */           log.debug("Caught IOException of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 255 */           toThrow = e;
/*     */         }
/*     */       
/*     */       } 
/* 259 */     } catch (Exception e) {
/*     */       
/* 261 */       log.debug("Caught unexpected exception of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 262 */       throw e;
/*     */     }
/*     */     finally {
/*     */       
/* 266 */       if (connection != null) {
/* 267 */         connection.disconnect();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 272 */     if (toThrow != null) {
/* 273 */       log.debug("throw previousl saved exception of type " + toThrow.getClass().getName() + ": " + toThrow.getMessage());
/* 274 */       throw toThrow;
/*     */     } 
/*     */     
/* 277 */     log.debug("finished checking connection to " + this.host + ":" + this.port);
/* 278 */     this.sslcheckperformed = true;
/* 279 */     return this.sslEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isServerSSLConfigured(Optional<Boolean> knownToBeSSL) throws Exception {
/* 297 */     if (this.sslcheckperformed) {
/* 298 */       return this.sslEnabled;
/*     */     }
/* 300 */     HttpURLConnection connection = null;
/* 301 */     Exception toThrow = null;
/* 302 */     if (knownToBeSSL.equals(Optional.of(Boolean.valueOf(true)))) {
/*     */       
/* 304 */       SSLSocket sslSocket = null;
/*     */       try {
/* 306 */         log.debug("Check user specified ssl Connection to " + this.host + ":" + this.port);
/* 307 */         SocketFactory sslSocketFactory = IS3SSLSocketFactory.getDefault();
/* 308 */         sslSocket = (SSLSocket)sslSocketFactory.createSocket(this.host, this.port);
/*     */ 
/*     */ 
/*     */         
/* 312 */         sslSocket.setSoTimeout(1500);
/* 313 */         sslSocket.startHandshake();
/*     */ 
/*     */         
/* 316 */         log.debug("handshake complete, using cipher: " + sslSocket.getSession().getCipherSuite());
/* 317 */         this.servercipher = sslSocket.getSession().getCipherSuite();
/* 318 */         if (this.servercipher.contains("AES_256")) {
/* 319 */           this.AES256Configured = true;
/*     */         }
/* 321 */         this.sslEnabled = true;
/*     */       }
/* 323 */       catch (SSLHandshakeException ex) {
/*     */ 
/*     */         
/* 326 */         log.debug("Caught SSLHandshakeException: " + ex.getMessage());
/* 327 */         if (ex.getMessage().contains("handshake_failure")) {
/* 328 */           log.debug("Assume policy file issue");
/* 329 */           this.sslEnabled = true;
/* 330 */           this.AES256Configured = false;
/*     */         }
/*     */         else {
/*     */           
/* 334 */           log.debug("Caught non-handshake_failure SSLHandshakeException: " + ex.getMessage());
/* 335 */           toThrow = ex;
/*     */         }
/*     */       
/* 338 */       } catch (Exception e) {
/*     */         
/* 340 */         log.debug("Caught generic Exception of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 341 */         toThrow = e;
/*     */       } finally {
/*     */ 
/*     */         
/*     */         try {
/* 346 */           if (sslSocket != null) {
/* 347 */             sslSocket.close();
/*     */           }
/* 349 */         } catch (IOException e) {
/*     */           
/* 351 */           log.debug("Caught sslSocket close IOException of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 352 */           toThrow = e;
/*     */         } 
/* 354 */         if (connection != null) {
/* 355 */           connection.disconnect();
/*     */         }
/*     */       } 
/* 358 */     } else if (knownToBeSSL.equals(Optional.of(Boolean.valueOf(false)))) {
/*     */       
/* 360 */       this.sslEnabled = false;
/*     */       try {
/* 362 */         URL url = new URL("http://" + this.host + ":" + this.port);
/* 363 */         log.debug("Check non-ssl URL: " + url.toExternalForm());
/* 364 */         connection = (HttpURLConnection)url.openConnection();
/*     */ 
/*     */ 
/*     */         
/* 368 */         connection.getResponseCode();
/* 369 */         this.sslEnabled = false;
/*     */       }
/* 371 */       catch (Exception e) {
/*     */         
/* 373 */         log.debug("Caught non-SSL connect generic Exception of type: " + e.getClass().getName() + ": " + e.getMessage());
/* 374 */         toThrow = e;
/*     */       } finally {
/*     */         
/* 377 */         if (connection != null) {
/* 378 */           connection.disconnect();
/*     */         }
/*     */       } 
/*     */     } else {
/* 382 */       this.sslEnabled = isServerSSLConfigured();
/*     */     } 
/*     */ 
/*     */     
/* 386 */     if (toThrow != null) {
/* 387 */       log.debug("throw previously saved exception of type " + toThrow.getClass().getName() + ": " + toThrow.getMessage());
/* 388 */       throw toThrow;
/*     */     } 
/* 390 */     String sslMessage = this.sslEnabled ? " SSL " : " ";
/* 391 */     log.debug("finished checking" + sslMessage + "connection to " + this.host + ":" + this.port);
/* 392 */     this.sslcheckperformed = true;
/* 393 */     return this.sslEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBatchLogin() {
/* 402 */     return this.isBatchLogin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBatchLogin(boolean isBatchLogin) {
/* 410 */     this.isBatchLogin = isBatchLogin;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\SSLServerChecks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */