/*    */ package com.mentor.is3.sec.client.connector.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NetworkProblemException
/*    */   extends ConnectorBaseException
/*    */ {
/*    */   private static final long serialVersionUID = 7625415810404482600L;
/*    */   
/*    */   public NetworkProblemException(String message) {
/* 24 */     super(message);
/*    */   }
/*    */   
/*    */   public NetworkProblemException(String message, Throwable cause) {
/* 28 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\exceptions\NetworkProblemException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */