/*      */ package com.mentor.is3.sec.client.connector.bundles;
/*      */ 
/*      */ import com.google.gson.Gson;
/*      */ import com.mentor.infrasec.keycertutils.CertificateImporter;
/*      */ import com.mentor.infrasec.keycertutils.exceptions.KeyCertIOException;
/*      */ import com.mentor.is3.sec.client.connector.HttpGetExecutor;
/*      */ import com.mentor.is3.sec.client.connector.IS3SSLSocketFactory;
/*      */ import com.mentor.is3.sec.client.connector.NetworkUtils;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.ConnectorBaseException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.GeneralErrorException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.NetworkProblemException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.ServerCertificateInvalidException;
/*      */ import com.mentor.is3.sec.client.connector.exceptions.ServerNotAchievableException;
/*      */ import com.mentor.is3.sec.client.utils.bundles.ClientBundleChecksumCalculator;
/*      */ import com.mentor.is3.sec.client.utils.bundles.ClientBundleDownloadException;
/*      */ import com.mentor.is3.sec.client.utils.bundles.ClientBundleLoaderBuilderException;
/*      */ import com.mentor.is3.sec.client.utils.bundles.PermissionManager;
/*      */ import com.mentor.is3.sec.client.utils.bundles.ServerDialogInfo;
/*      */ import com.mentor.is3.sec.client.utils.messages.LoginLibMessages;
/*      */ import com.mentor.is3.sec.infra.CommonUtils;
/*      */ import com.mentor.is3.sec.infra.bundles.BundleInfo;
/*      */ import com.mentor.is3.sec.infra.bundles.DebugPrinter;
/*      */ import com.mentor.is3.sec.infra.bundles.VersionInfo;
/*      */ import com.mentor.release.reader.ReleaseReader;
/*      */ import com.mentor.sdd.flow.id.SDDFlowID;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileReader;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLEncoder;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.file.CopyOption;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.Paths;
/*      */ import java.nio.file.StandardCopyOption;
/*      */ import java.nio.file.attribute.FileAttribute;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.Arrays;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Optional;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ import java.util.zip.ZipInputStream;
/*      */ import javax.net.ssl.SSLSocket;
/*      */ import org.apache.commons.io.FileUtils;
/*      */ import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClientBundleLoaderBase
/*      */ {
/*      */   public static final String ENV_VAR_DEBUG_FILE = "EBS_CBL_DEBUG_FILE";
/*      */   private static final String ENV_VAR_CBL_DIR = "EBS_CBL_DIR";
/*      */   private static final String ENV_VAR_ALWAYS_DOWNLOAD = "EBS_CBL_ALWAYS_DOWNLOAD";
/*      */   protected static final String HTTP_PREFIX = "http";
/*      */   protected static final String HTTPS_PREFIX = "https";
/*   81 */   private static final String WINDOWS_DEFAULT_DIR = System.getenv("ALLUSERSPROFILE") + System.getenv("ALLUSERSPROFILE") + "Siemens";
/*   82 */   private static final String LINUX_DEFAULT_DIR = "/usr/local/bin" + File.separator + "Siemens";
/*   83 */   private static final String MINI_TREE_SUB_PATH = File.separator + ".iS3" + File.separator + "minitree";
/*      */   
/*      */   private static final String INSTALL_VERSION_WS = "/iS3WebServices/is3API/Install/fullVersion";
/*      */   
/*      */   private static final String LEGACY_INSTALL_VERSION_WS = "/iS3WebServices/is3API/Install/version";
/*      */   
/*      */   private static final String DOWNLOAD_BUNDLE_WS = "/iS3WebServices/is3API/download";
/*      */   
/*      */   private static final String FILE_VERSIONS_DATABASE = "mgc.file";
/*      */   
/*      */   private static final String FLOWID_VX_2_4 = "X-ENTP VX.2.4";
/*      */   
/*      */   private static final String PATH_TO_JARFILE_2_4 = "SDD_HOME/idm/bin/is3-edm-client.jar";
/*      */   
/*      */   private static final int NUM_JRE_FILES = 250;
/*   98 */   private int PERCENT_BEFORE_DOWNLOAD = 3;
/*   99 */   private int PERCENT_AFTER_DOWNLOAD = 55;
/*  100 */   private int PERCENT_FOR_DOWNLOAD = this.PERCENT_AFTER_DOWNLOAD - this.PERCENT_BEFORE_DOWNLOAD;
/*  101 */   private int PERCENT_AFTER_VALIDATE = 57;
/*  102 */   private int PERCENT_AFTER_UNPACK = 97;
/*  103 */   private int PERCENT_FOR_UNPACK = this.PERCENT_AFTER_UNPACK - this.PERCENT_AFTER_VALIDATE;
/*  104 */   private int BUNDLE_SIZE = 140000000;
/*      */   
/*  106 */   protected int currentUnpackFileCount = 0;
/*  107 */   protected int totalUnpackFiles = 0;
/*      */ 
/*      */   
/*  110 */   private String DEBUG_FILE = System.getenv("EBS_CBL_DEBUG_FILE");
/*  111 */   private String DEBUG_FILE_OLD = System.getenv("com.mentor.is3.client.login.bundles.ClientBundleLoader");
/*      */   
/*      */   private String bundleConfigName;
/*      */   
/*      */   private String serverUrl;
/*      */   
/*      */   private boolean doNotPrompt;
/*      */   private int arch;
/*      */   private boolean windows;
/*      */   private boolean debug;
/*      */   private ServerDialogInfo serverDialogInfo;
/*      */   private LinkedHashSet<String> bundleDependenciesToSkip;
/*      */   protected boolean willShowProgressGui = false;
/*      */   private String sddPlatform;
/*      */   private String installVersionWsPlatform;
/*      */   private String bundleZipName;
/*      */   private PrintWriter debugFileOutput;
/*  128 */   private final PrintStream origStdErr = System.err;
/*  129 */   private final PrintStream origStdOut = System.out;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BundleInfo provideClientBundleInfo(String bundleConfigName, String serverUrl, boolean doNotPrompt) {
/*      */     try {
/*  147 */       ClientBundleLoaderBaseBuilder clientBundleLoaderBaseBuilder = new ClientBundleLoaderBaseBuilder();
/*  148 */       clientBundleLoaderBaseBuilder.setBundleFileName(bundleConfigName)
/*  149 */         .setServerUrl(serverUrl)
/*  150 */         .setDoNotPrompt(doNotPrompt);
/*  151 */       ClientBundleLoaderBase clientBundleLoaderBase = clientBundleLoaderBaseBuilder.build();
/*  152 */       BundleInfo bundleInfo = clientBundleLoaderBase.provideClientBundleInfo();
/*  153 */       return bundleInfo;
/*      */     }
/*  155 */     catch (ClientBundleLoaderBuilderException e) {
/*  156 */       BundleInfo bundleInfo = getErrorBundleInfo(serverUrl, 
/*  157 */           LoginLibMessages.getString("ECSCBL_ERROR_UNKNOWN_ERROR"), "Error building client bundle loader: " + e
/*  158 */           .getMessage());
/*  159 */       return bundleInfo;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClientBundleLoaderBase(String bundleConfigName, String serverUrl, boolean doNotPrompt, int arch, boolean windows, boolean debug, ServerDialogInfo serverDialogInfo, LinkedHashSet<String> bundleDependenciesToSkip) {
/*  179 */     this.bundleConfigName = bundleConfigName;
/*  180 */     this.serverUrl = serverUrl;
/*  181 */     this.doNotPrompt = doNotPrompt;
/*  182 */     this.arch = arch;
/*  183 */     this.windows = windows;
/*  184 */     this.debug = debug;
/*  185 */     this.serverDialogInfo = serverDialogInfo;
/*  186 */     this.bundleDependenciesToSkip = bundleDependenciesToSkip;
/*      */     
/*  188 */     if (this.bundleDependenciesToSkip == null) {
/*  189 */       this.bundleDependenciesToSkip = new LinkedHashSet<>();
/*      */     }
/*      */ 
/*      */     
/*  193 */     this.bundleDependenciesToSkip.add(bundleConfigName);
/*      */     
/*  195 */     if (serverDialogInfo == null)
/*      */     {
/*  197 */       this.willShowProgressGui = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  208 */     this.sddPlatform = getSddPlatform();
/*  209 */     this.installVersionWsPlatform = getInstallVersionWsPlatform();
/*  210 */     this.bundleZipName = getBundleZipName();
/*      */   }
/*      */ 
/*      */   
/*      */   private String getSddPlatform() {
/*  215 */     if (this.windows) {
/*  216 */       return "win" + this.arch;
/*      */     }
/*  218 */     if (this.arch == 64) {
/*  219 */       return "amd64_linux";
/*      */     }
/*  221 */     return "linux";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String getInstallVersionWsPlatform() {
/*  227 */     return this.windows ? ("win" + 
/*  228 */       this.arch) : ("lin" + 
/*      */       
/*  230 */       this.arch);
/*      */   }
/*      */ 
/*      */   
/*      */   private String getBundleZipName() {
/*  235 */     return this.windows ? ("win" + 
/*  236 */       this.arch) : ("linux" + 
/*      */       
/*  238 */       this.arch);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initOutput() {
/*  244 */     String debugFilePath = null;
/*  245 */     if (!CommonUtils.isNullOrEmpty(this.DEBUG_FILE)) {
/*  246 */       debugFilePath = this.DEBUG_FILE;
/*  247 */     } else if (!CommonUtils.isNullOrEmpty(this.DEBUG_FILE_OLD)) {
/*  248 */       debugFilePath = this.DEBUG_FILE_OLD;
/*      */     } 
/*      */     
/*  251 */     if (debugFilePath != null) {
/*  252 */       File debugFile = new File(debugFilePath);
/*  253 */       if (!debugFile.isDirectory() && debugFile.exists()) {
/*  254 */         debugFile.delete();
/*      */       }
/*      */       
/*      */       try {
/*  258 */         this.debugFileOutput = new PrintWriter(new FileWriter(debugFilePath, true));
/*  259 */       } catch (IOException e) {
/*  260 */         this.debugFileOutput = null;
/*      */       } 
/*      */     } else {
/*  263 */       this.debugFileOutput = null;
/*      */     } 
/*      */     
/*  266 */     if (!this.debug) {
/*      */ 
/*      */       
/*  269 */       System.setErr(new PrintStream(new OutputStream()
/*      */             {
/*      */               public void write(int b) {}
/*      */             }));
/*      */       
/*  274 */       System.setOut(new PrintStream(new OutputStream()
/*      */             {
/*      */               public void write(int b) {}
/*      */             }));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void closeOutput() {
/*  283 */     if (!this.debug) {
/*  284 */       System.setErr(this.origStdErr);
/*  285 */       System.setOut(this.origStdOut);
/*      */     } 
/*      */     
/*  288 */     closeAllHandles();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void closeAllHandles() {
/*      */     try {
/*  294 */       if (!CommonUtils.isNullOrEmpty(this.DEBUG_FILE) && 
/*  295 */         this.debugFileOutput != null) {
/*  296 */         this.debugFileOutput.close();
/*      */       
/*      */       }
/*      */     }
/*  300 */     catch (Exception e) {
/*  301 */       printDebug("Exception in closeAllHandles()[ Class:" + String.valueOf(e.getClass()) + "]/ Details: " + e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private BundleInfo getSuccessBundleInfo(String serverUrl, String bundleName, String sddHome, String sddPlatform, BundleInfo.ReleaseInfo releaseInfo, String javaHome) {
/*  307 */     return new BundleInfo(serverUrl, bundleName, sddHome, sddPlatform, javaHome, BundleInfo.Status.SUCCESS, null, releaseInfo, null, 
/*  308 */         Boolean.valueOf(this.serverDialogInfo.isSsl()));
/*      */   }
/*      */   
/*      */   public static BundleInfo getErrorBundleInfo(String serverUrl, String errMsg, String detailedErrMsg) {
/*  312 */     return getErrorBundleInfo(serverUrl, errMsg, detailedErrMsg, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private static BundleInfo getErrorBundleInfo(String serverUrl, String errMsg, String detailedErrMsg, BundleInfo.ReleaseInfo releaseInfo) {
/*  317 */     return getErrorBundleInfo(serverUrl, errMsg, detailedErrMsg, releaseInfo, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private static BundleInfo getErrorBundleInfo(String serverUrl, String errMsg, String detailedErrMsg, BundleInfo.ReleaseInfo releaseInfo, String bundleName) {
/*  322 */     return new BundleInfo(serverUrl, bundleName, null, null, null, BundleInfo.Status.ERROR, errMsg, releaseInfo, detailedErrMsg, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private BundleInfo getCancelledBundleInfo(String serverUrl, String errMsg, String detailedErrMsg) {
/*  327 */     return new BundleInfo(serverUrl, null, null, null, null, BundleInfo.Status.CANCEL, errMsg, null, detailedErrMsg, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getInstallJsonFromWs() throws ServerNotAchievableException, ServerCertificateInvalidException, UnknownHostException, GeneralErrorException, NetworkProblemException, IOException {
/*  425 */     String urlSuffix = "?bundlefilename=" + URLEncoder.encode(this.bundleConfigName, "UTF-8") + "&platform=" + this.installVersionWsPlatform;
/*      */ 
/*      */ 
/*      */     
/*  429 */     String urlPath = "/iS3WebServices/is3API/Install/fullVersion" + urlSuffix;
/*  430 */     NetworkUtils.NetworkUtilsHttpGetResult networkUtilsHttpGetResult = NetworkUtils.httpGetExecuteFullResult(this.serverDialogInfo
/*  431 */         .getHost(), this.serverDialogInfo.getPort(), false, true, urlPath);
/*      */ 
/*      */     
/*  434 */     if (networkUtilsHttpGetResult.getResponseCode() == 200) {
/*  435 */       printDebug("Calling httpExecute to get the Install Version from url " + urlPath);
/*  436 */       return networkUtilsHttpGetResult.getResponseLine();
/*      */     } 
/*      */ 
/*      */     
/*  440 */     urlPath = "/iS3WebServices/is3API/Install/version" + urlSuffix;
/*  441 */     printDebug("Calling httpExecute to get the Install Version from legacy url " + urlPath);
/*  442 */     return NetworkUtils.httpGetExecute(this.serverDialogInfo.getHost(), this.serverDialogInfo.getPort(), false, true, urlPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BundleInfo provideClientBundleInfo() {
/*      */     try {
/*  451 */       initOutput();
/*      */       
/*  453 */       printDebug("Input to provideClientBundleInfo(): bundleConfigName=" + this.bundleConfigName + ", serverUrl=" + this.serverUrl + ", doNotPrompt=" + this.doNotPrompt);
/*      */ 
/*      */       
/*  456 */       if (CommonUtils.isNullOrEmpty(this.bundleConfigName)) {
/*  457 */         return getErrorBundleInfo(this.serverUrl, LoginLibMessages.getString("ECSCBL_ERROR_EMPTY_BUNDLE_NAME"), "Bundle File Name is null or empty");
/*      */       }
/*      */ 
/*      */       
/*  461 */       this.bundleConfigName = getBundleConfigNameWithoutExtension();
/*      */       
/*  463 */       printDebug("Platform=" + this.sddPlatform);
/*  464 */       printDebug("Before calling ServerDialogBox");
/*      */       
/*  466 */       if (this.serverDialogInfo == null) {
/*  467 */         this.serverDialogInfo = launchGui(this.serverUrl, this.doNotPrompt);
/*  468 */         if (!this.serverDialogInfo.isSuccess()) {
/*  469 */           printDebug("ServerDialogBox returned NOT success");
/*  470 */           if (this.serverDialogInfo.isCancelled()) {
/*  471 */             return getCancelledBundleInfo(this.serverUrl, this.serverDialogInfo.getErrorMsg(), "GUI launch was cancelled");
/*      */           }
/*  473 */           return getErrorBundleInfo(this.serverUrl, this.serverDialogInfo.getErrorMsg(), "Error launching GUI");
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  478 */       String installJson = null;
/*      */       try {
/*  480 */         installJson = getInstallJsonFromWs();
/*  481 */       } catch (ServerNotAchievableException|ServerCertificateInvalidException|GeneralErrorException|NetworkProblemException|IOException e) {
/*      */         
/*  483 */         printDebug("Exception in provideClientBundleInfo[ Class:" + String.valueOf(e.getClass()) + "]/ Details: " + e
/*  484 */             .getMessage());
/*      */         
/*  486 */         return getErrorBundleInfo(this.serverDialogInfo.getServerUrl(), 
/*  487 */             LoginLibMessages.getString("ECSCBL_ERROR_UNABLE_TO_CONNECT_SERVER"), "[ Class:" + 
/*  488 */             String.valueOf(e.getClass()) + "]/ Details: " + e.getMessage());
/*      */       } 
/*      */       
/*  491 */       if (CommonUtils.isNullOrEmpty(installJson))
/*      */       {
/*  493 */         return getErrorBundleInfo(this.serverUrl, LoginLibMessages.getString("ECSCBL_ERROR_UNABLE_TO_GET_VERSION"), "Install JSON is null, likely because the web service is not present");
/*      */       }
/*      */ 
/*      */       
/*  497 */       Gson gson = new Gson();
/*  498 */       VersionInfo serverVersionInfo = (VersionInfo)gson.fromJson(installJson, VersionInfo.class);
/*  499 */       String bundleName = serverVersionInfo.getBundleName();
/*  500 */       String serverGuid = serverVersionInfo.getServerGuid();
/*  501 */       String serverFlowId = serverVersionInfo.getFlowId();
/*  502 */       String pathToJarFile = serverVersionInfo.getJarPath();
/*  503 */       String serverChecksum = serverVersionInfo.getChecksum();
/*  504 */       String serverUpdateName = serverVersionInfo.getUpdateName();
/*  505 */       List<String> bundleDependencies = serverVersionInfo.getBundleDependencies();
/*  506 */       BundleInfo.ReleaseInfo serverReleaseInfo = serverVersionInfo.getReleaseInfo();
/*      */       
/*  508 */       printDebug(serverVersionInfo.toString());
/*      */       
/*  510 */       if (!CommonUtils.isNullOrEmpty(serverVersionInfo.getDetailedErrMsg())) {
/*  511 */         return getErrorBundleInfo(this.serverDialogInfo.getServerUrl(), 
/*  512 */             LoginLibMessages.getString("ECSCBL_ERROR_UNABLE_TO_GET_VERSION"), serverVersionInfo
/*  513 */             .getDetailedErrMsg());
/*      */       }
/*      */       
/*  516 */       if (CommonUtils.isNullOrEmpty(serverFlowId)) {
/*  517 */         return getErrorBundleInfo(this.serverDialogInfo.getServerUrl(), 
/*  518 */             LoginLibMessages.getString("ECSCBL_ERROR_UNABLE_TO_GET_VERSION"), "Returnd JSON does not have a FLOW ID");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  523 */       if (serverFlowId.equals("X-ENTP VX.2.4")) {
/*      */         
/*  525 */         serverVersionInfo.setJarPath("SDD_HOME/idm/bin/is3-edm-client.jar");
/*  526 */         return getVX24BundleInfo(this.serverDialogInfo.getServerUrl(), serverVersionInfo);
/*      */       } 
/*      */ 
/*      */       
/*  530 */       if (CommonUtils.isNullOrEmpty(serverChecksum) || CommonUtils.isNullOrEmpty(serverGuid)) {
/*  531 */         return getErrorBundleInfo(this.serverDialogInfo.getServerUrl(), 
/*  532 */             LoginLibMessages.getString("ECSCBL_ERROR_WRONG_BUNDLE_NAME"), "Install JSON was not as expected.  Missing serverChecksum or serverGuid. JSON: " + installJson);
/*      */       }
/*      */ 
/*      */       
/*  536 */       if (CommonUtils.isNullOrEmpty(pathToJarFile) && !isJreBundle(bundleName)) {
/*  537 */         return getErrorBundleInfo(this.serverDialogInfo.getServerUrl(), 
/*  538 */             LoginLibMessages.getString("ECSCBL_ERROR_WRONG_BUNDLE_NAME"), "Install JSON was not as expected.  Missing pathToJarFile. JSON: " + installJson);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  543 */       String jreBundleDependencySddHome = null;
/*      */ 
/*      */       
/*  546 */       if (bundleDependencies != null && !bundleDependencies.isEmpty()) {
/*      */         
/*  548 */         printDebug("--- Starting dependency downloads (if necessary)...");
/*      */         
/*  550 */         for (String dep : bundleDependencies) {
/*      */           
/*  552 */           if (dep == null) {
/*      */             continue;
/*      */           }
/*      */           
/*  556 */           if (!willSkipDependencyBundleDownload(dep)) {
/*  557 */             printDebug("Getting dependency bundle with name: " + dep);
/*      */             
/*  559 */             this.bundleDependenciesToSkip.add(dep);
/*      */             
/*  561 */             ClientBundleLoaderBase depClientBundleLoaderBase = new ClientBundleLoaderBase(dep, this.serverUrl, this.doNotPrompt, this.arch, this.windows, this.debug, this.serverDialogInfo, this.bundleDependenciesToSkip);
/*      */ 
/*      */ 
/*      */             
/*  565 */             BundleInfo depBundleInfo = depClientBundleLoaderBase.provideClientBundleInfo();
/*      */ 
/*      */             
/*  568 */             if (!BundleInfo.Status.SUCCESS.equals(depBundleInfo.getStatus())) {
/*  569 */               return getErrorBundleInfo(this.serverDialogInfo.getServerUrl(), depBundleInfo.getErrorMsg(), depBundleInfo.getDetailedErrMsg());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  583 */             if (isJreBundle(dep)) {
/*      */ 
/*      */ 
/*      */               
/*  587 */               jreBundleDependencySddHome = depBundleInfo.getSddHome();
/*  588 */               printDebug("Setting jreBundleDependencySddHome to: " + jreBundleDependencySddHome);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  593 */         printDebug("--- Done with dependency downloads...");
/*      */       } 
/*      */ 
/*      */       
/*  597 */       String alwaysDownloadEnvVar = System.getenv("EBS_CBL_ALWAYS_DOWNLOAD");
/*  598 */       if (alwaysDownloadEnvVar == null || alwaysDownloadEnvVar.isBlank()) {
/*      */ 
/*      */ 
/*      */         
/*  602 */         String matchingInstalledSddHome = getMatchingInstalledSddHome(serverVersionInfo);
/*  603 */         if (matchingInstalledSddHome != null) {
/*  604 */           String javaHome = getJavaHome(matchingInstalledSddHome);
/*  605 */           if (jreBundleDependencySddHome != null) {
/*  606 */             javaHome = getJavaHome(jreBundleDependencySddHome);
/*      */           }
/*  608 */           printDebug("BundleInfo javaHome: " + javaHome);
/*  609 */           BundleInfo bundleInfo1 = getSuccessBundleInfo(this.serverDialogInfo.getServerUrl(), bundleName, matchingInstalledSddHome, this.sddPlatform, serverReleaseInfo, javaHome);
/*      */           
/*  611 */           printDebug("BundleInfo: " + String.valueOf(bundleInfo1));
/*  612 */           return bundleInfo1;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  618 */       BundleInfo bundleInfo = getMiniTreeBundleInfo(serverVersionInfo);
/*  619 */       if (bundleInfo != null) {
/*  620 */         if (jreBundleDependencySddHome != null) {
/*  621 */           bundleInfo.setJavaHome(getJavaHome(jreBundleDependencySddHome));
/*      */         }
/*  623 */         printDebug("BundleInfo javaHome: " + bundleInfo.getJavaHome());
/*      */       } 
/*  625 */       return bundleInfo;
/*      */     }
/*      */     finally {
/*      */       
/*  629 */       closeOutput();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isJreBundle(String dep) {
/*  635 */     return "JRE".equalsIgnoreCase(dep);
/*      */   }
/*      */   
/*      */   private boolean willSkipDependencyBundleDownload(String dep) {
/*  639 */     if (this.bundleDependenciesToSkip == null) {
/*  640 */       return false;
/*      */     }
/*  642 */     for (String toSkip : this.bundleDependenciesToSkip) {
/*  643 */       if (toSkip.equalsIgnoreCase(dep)) {
/*  644 */         return true;
/*      */       }
/*      */     } 
/*  647 */     return false;
/*      */   }
/*      */   
/*      */   private String getBundleConfigNameWithoutExtension() {
/*  651 */     if (this.bundleConfigName.toLowerCase().endsWith(".cfg")) {
/*  652 */       return this.bundleConfigName.substring(0, this.bundleConfigName.length() - 4);
/*      */     }
/*  654 */     return this.bundleConfigName;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private BundleInfo findExistingMiniTree(VersionInfo serverVersionInfo) {
/*  660 */     String serverFlowId = serverVersionInfo.getFlowId();
/*  661 */     String serverUpdateName = serverVersionInfo.getUpdateName();
/*  662 */     String serverBundleName = serverVersionInfo.getBundleName();
/*  663 */     String serverChecksum = serverVersionInfo.getChecksum();
/*  664 */     String pathToJarFile = serverVersionInfo.getJarPath();
/*  665 */     String serverGuid = serverVersionInfo.getServerGuid();
/*  666 */     BundleInfo.ReleaseInfo releaseInfo = serverVersionInfo.getReleaseInfo();
/*  667 */     String sddVersion = releaseInfo.getSddVersion();
/*      */ 
/*      */ 
/*      */     
/*  671 */     String[] possibleMinitreeDirs = getPossibleMinitreeDirs();
/*  672 */     for (String topLevelMinitreeDir : possibleMinitreeDirs) {
/*  673 */       Path miniTree = Paths.get(topLevelMinitreeDir, new String[] { this.sddPlatform });
/*  674 */       Path sddHome = getSddHomeOfMiniTree(sddVersion, serverGuid, miniTree);
/*  675 */       Path parentOfSddHome = sddHome.getParent();
/*  676 */       printDebug("miniTree=" + miniTree.toString() + " has SDD_HOME=" + String.valueOf(sddHome) + " parent (" + String.valueOf(parentOfSddHome) + ")");
/*      */ 
/*      */       
/*  679 */       BundleInfo existingMiniTree = getExistingMatchingMiniTree(this.serverUrl, serverFlowId, serverUpdateName, serverBundleName, serverChecksum, pathToJarFile, sddHome, miniTree);
/*      */ 
/*      */ 
/*      */       
/*  683 */       if (existingMiniTree != null) {
/*  684 */         return existingMiniTree;
/*      */       }
/*      */     } 
/*      */     
/*  688 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private BundleInfo getMiniTreeBundleInfo(VersionInfo serverVersionInfo) {
/*  693 */     String serverUrl = this.serverDialogInfo.getServerUrl();
/*      */     
/*  695 */     String serverGuid = serverVersionInfo.getServerGuid();
/*      */ 
/*      */     
/*  698 */     String alwaysDownloadEnvVar = System.getenv("EBS_CBL_ALWAYS_DOWNLOAD");
/*  699 */     if (alwaysDownloadEnvVar == null || alwaysDownloadEnvVar.isBlank()) {
/*  700 */       BundleInfo existingMiniTree = findExistingMiniTree(serverVersionInfo);
/*  701 */       if (existingMiniTree != null) {
/*  702 */         return existingMiniTree;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  709 */     String downloadMinitreeDir = getDownloadMinitreeDir();
/*  710 */     File downloadMinitreeDirFile = new File(downloadMinitreeDir);
/*  711 */     if (!downloadMinitreeDirFile.exists()) {
/*  712 */       File iS3Dir = downloadMinitreeDirFile.getParentFile();
/*  713 */       if (!iS3Dir.exists()) {
/*  714 */         iS3Dir.mkdirs();
/*  715 */         PermissionManager.changeDirPermissions(iS3Dir.getAbsolutePath(), this.windows, this.debug, this.debugFileOutput);
/*      */       } 
/*  717 */       downloadMinitreeDirFile.mkdirs();
/*  718 */       PermissionManager.changeDirPermissions(downloadMinitreeDir, this.windows, this.debug, this.debugFileOutput);
/*      */     } 
/*      */ 
/*      */     
/*  722 */     String serverHost = this.serverDialogInfo.getHost();
/*  723 */     int serverPort = this.serverDialogInfo.getPort();
/*  724 */     Path miniTree = Paths.get(downloadMinitreeDir, new String[] { this.sddPlatform });
/*  725 */     BundleInfo downloadedMiniTree = downloadUnpackAndUpdateDb(serverUrl, serverHost, serverPort, serverVersionInfo, serverGuid, miniTree);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  741 */     if (downloadedMiniTree.getStatus() == BundleInfo.Status.ERROR && alwaysDownloadEnvVar != null && 
/*  742 */       !alwaysDownloadEnvVar.isBlank()) {
/*  743 */       BundleInfo existingMiniTree = findExistingMiniTree(serverVersionInfo);
/*  744 */       if (existingMiniTree != null) {
/*  745 */         return existingMiniTree;
/*      */       }
/*      */     } 
/*      */     
/*  749 */     return downloadedMiniTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path getServerMiniTree(String serverGuid, Path miniTree) {
/*  761 */     Path serverMiniTree = Paths.get(miniTree.toString(), new String[] { serverGuid });
/*  762 */     return serverMiniTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path getServerBundleMiniTree(String serverGuid, Path miniTree) {
/*  775 */     Path serverMiniTree = getServerMiniTree(serverGuid, miniTree);
/*  776 */     Path serverBundleMiniTree = Paths.get(serverMiniTree.toString(), new String[] { this.bundleConfigName });
/*  777 */     return serverBundleMiniTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path getSddHomeOfMiniTree(String sddVersion, String serverGuid, Path miniTree) {
/*  790 */     Path serverBundleMiniTree = getServerBundleMiniTree(serverGuid, miniTree);
/*  791 */     Path sddHome = Paths.get(serverBundleMiniTree.toString(), new String[] { sddVersion, "SDD_HOME" });
/*  792 */     return sddHome;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BundleInfo getVX24BundleInfo(String serverUrl, VersionInfo versionInfo) {
/*  804 */     String userInstalledSddHome = getMatchingInstalledSddHome(versionInfo);
/*  805 */     String serverFlowId = versionInfo.getFlowId();
/*  806 */     String bundleName = versionInfo.getBundleName();
/*  807 */     String serverUpdateName = versionInfo.getUpdateName();
/*  808 */     BundleInfo.ReleaseInfo releaseInfo = versionInfo.getReleaseInfo();
/*      */     
/*  810 */     if (userInstalledSddHome == null) {
/*  811 */       String errMsg = String.format(LoginLibMessages.getString("ECSBL_ERROR_SERVER_VX_2_4"), new Object[] {
/*  812 */             CommonUtils.isNullOrEmpty(bundleName) ? this.bundleConfigName : bundleName });
/*  813 */       return getErrorBundleInfo(serverUrl, errMsg, "VX.2.4 flow and user installed SDD_HOME is null", releaseInfo);
/*      */     } 
/*      */ 
/*      */     
/*  817 */     return getSuccessBundleInfo(serverUrl, bundleName, userInstalledSddHome, this.sddPlatform, releaseInfo, 
/*  818 */         getJavaHome(userInstalledSddHome));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BundleInfo getExistingMatchingMiniTree(String serverUrl, String serverFlowId, String serverUpdateName, String serverBundleName, String serverChecksum, String pathToJarFile, Path sddHome, Path miniTree) {
/*  825 */     VersionInfo clientVersionInfo = getMatchingClientVersionInfo(serverFlowId, serverUpdateName, serverBundleName, serverChecksum, miniTree
/*  826 */         .toString());
/*  827 */     if (clientVersionInfo != null) {
/*  828 */       Path parentOfSddHome = sddHome.getParent();
/*  829 */       File jarFile = new File(Paths.get(parentOfSddHome.toString(), new String[] { pathToJarFile }).toString());
/*      */ 
/*      */       
/*  832 */       if (jarFile.exists()) {
/*  833 */         BundleInfo.ReleaseInfo releaseInfo = clientVersionInfo.getReleaseInfo();
/*  834 */         return getSuccessBundleInfo(serverUrl, serverBundleName, sddHome.toString(), clientVersionInfo
/*  835 */             .getSddPlatform(), releaseInfo, getJavaHome(sddHome.toString()));
/*      */       } 
/*  837 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  841 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private BundleInfo downloadUnpackAndUpdateDb(String serverUrl, String serverHost, int serverPort, VersionInfo serverVersionInfo, String serverGuid, Path miniTree) {
/*  847 */     String bundlePath, serverFlowId = serverVersionInfo.getFlowId();
/*  848 */     String serverUpdateName = serverVersionInfo.getUpdateName();
/*  849 */     String serverBundleName = serverVersionInfo.getBundleName();
/*  850 */     Path serverBundleMiniTree = getServerBundleMiniTree(serverGuid, miniTree);
/*  851 */     BundleInfo.ReleaseInfo releaseInfo = serverVersionInfo.getReleaseInfo();
/*  852 */     String sddVersion = releaseInfo.getSddVersion();
/*      */ 
/*      */     
/*  855 */     Path sddHome = getSddHomeOfMiniTree(sddVersion, serverGuid, miniTree);
/*      */ 
/*      */ 
/*      */     
/*  859 */     Path sddHomeParent = sddHome.getParent();
/*      */ 
/*      */     
/*      */     try {
/*  863 */       bundlePath = downloadBundle(serverHost, serverPort, serverFlowId, serverUpdateName, serverBundleName, sddHome, miniTree, serverGuid);
/*      */     }
/*  865 */     catch (ClientBundleDownloadException e) {
/*  866 */       if (this.debug) {
/*  867 */         e.printStackTrace();
/*      */       }
/*  869 */       String errorMessage = LoginLibMessages.getString("ECSCBL_ERROR_FAIL_TO_DOWNLOAD_BUNDLE") + " " + LoginLibMessages.getString("ECSCBL_ERROR_FAIL_TO_DOWNLOAD_BUNDLE");
/*  870 */       return getErrorBundleInfo(serverUrl, errorMessage, e
/*  871 */           .getMessage(), releaseInfo, serverBundleName);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  881 */     boolean willValidate = (releaseInfo != null && (releaseInfo.getMajor() > 2 || (releaseInfo.getMajor() == 2 && ("14.1".equals(releaseInfo.getMinor()) || Integer.parseInt(releaseInfo.getMinor()) >= 10))));
/*      */     
/*  883 */     if (!willValidate) {
/*  884 */       setPercentageComplete(this.PERCENT_AFTER_DOWNLOAD, true, "Downloading of the zip file is done.");
/*      */       
/*  886 */       this.PERCENT_FOR_UNPACK = this.PERCENT_AFTER_UNPACK - this.PERCENT_AFTER_DOWNLOAD;
/*      */     } else {
/*      */       
/*  889 */       setPercentageComplete(this.PERCENT_AFTER_DOWNLOAD, true, "Validating downloaded bundle.");
/*      */       
/*      */       try {
/*  892 */         validateBundle(new File(bundlePath), serverVersionInfo.getChecksum());
/*  893 */       } catch (ClientBundleDownloadException e) {
/*      */         try {
/*  895 */           Files.deleteIfExists(Paths.get(bundlePath, new String[0]));
/*  896 */         } catch (Exception e2) {
/*  897 */           printDebug("Failed to delete the improper bundle: " + e2.getMessage());
/*      */         } 
/*      */         
/*  900 */         return getErrorBundleInfo(serverUrl, LoginLibMessages.getString("ECSCBL_ERROR_FAIL_TO_VALIDATE_BUNDLE"), e
/*  901 */             .getMessage(), releaseInfo, serverBundleName);
/*      */       } 
/*      */       
/*  904 */       setPercentageComplete(this.PERCENT_AFTER_VALIDATE, true, "Done validating bundle.");
/*      */     } 
/*      */     
/*      */     try {
/*  908 */       if (Files.exists(serverBundleMiniTree, new java.nio.file.LinkOption[0])) {
/*  909 */         FileUtils.deleteDirectory(serverBundleMiniTree.toFile());
/*      */       }
/*  911 */     } catch (Exception e) {
/*  912 */       return getErrorBundleInfo(serverUrl, LoginLibMessages.getString("ECSCBL_ERROR_FAIL_TO_UNPACK_BUNDLE"), "Error unpacking the bundle: " + e
/*  913 */           .getMessage(), releaseInfo, serverBundleName);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  920 */       unpackBundle(bundlePath, sddHomeParent);
/*  921 */     } catch (ClientBundleDownloadException e) {
/*  922 */       return getErrorBundleInfo(serverUrl, LoginLibMessages.getString("ECSCBL_ERROR_FAIL_TO_UNPACK_BUNDLE"), "Error unpacking the bundle: " + e
/*  923 */           .getMessage(), releaseInfo, serverBundleName);
/*      */     } 
/*      */     
/*  926 */     setPercentageComplete(this.PERCENT_AFTER_UNPACK, true, "Unpacking of the zip file is done.");
/*      */     
/*  928 */     List<VersionInfo> clientVersionInfoList = readVersionsFromDB(miniTree.toString());
/*  929 */     List<VersionInfo> newVersionsInfo = new LinkedList<>();
/*  930 */     newVersionsInfo.addAll(clientVersionInfoList);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     VersionInfo thisVersionInfo = new VersionInfo(serverVersionInfo.getInstallId(), serverVersionInfo.getFlowId(), serverVersionInfo.getFullFlowName(), serverVersionInfo.getExactAccessDate(), serverVersionInfo.getUpdateName(), this.sddPlatform, serverVersionInfo.isUpdate(), serverVersionInfo.getChecksum(), serverVersionInfo.getServerGuid(), serverVersionInfo.getJarPath(), serverVersionInfo.getBundleName(), serverVersionInfo.getBundleDependencies(), serverVersionInfo.getDetailedErrMsg(), releaseInfo.getScheme(), releaseInfo.getMajor(), releaseInfo.getMinor(), releaseInfo.getUpdate(), releaseInfo.getVariant(), releaseInfo.getName(), releaseInfo.getSddVersion());
/*  943 */     newVersionsInfo.add(thisVersionInfo);
/*      */     
/*  945 */     printDebug("Writing to mgc.file");
/*  946 */     writeVersionsToDB(newVersionsInfo, miniTree.toString());
/*  947 */     PermissionManager.changeDirPermissions(miniTree.toString(), this.windows, this.debug, this.debugFileOutput);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  954 */     if (isJreBundle(serverBundleName) && 
/*  955 */       this.serverDialogInfo.isSsl()) {
/*  956 */       SSLSocket sslSocket = null;
/*  957 */       IS3SSLSocketFactory iS3SSLSocketFactory = IS3SSLSocketFactory.getDefault();
/*  958 */       String host = this.serverDialogInfo.getHost();
/*  959 */       int port = this.serverDialogInfo.getPort();
/*  960 */       printDebug("socketFactory created to: " + host + ":" + port + " created");
/*  961 */       X509Certificate[] certificateChain = null;
/*      */       try {
/*  963 */         sslSocket = (SSLSocket)iS3SSLSocketFactory.createSocket(host, port);
/*  964 */         sslSocket.startHandshake();
/*  965 */         certificateChain = IS3SSLSocketFactory.SavingTrustManager.getChain();
/*  966 */       } catch (IOException e) {
/*  967 */         printDebug("IOException when trying to get the certificate from the server");
/*      */       } finally {
/*      */         try {
/*  970 */           sslSocket.close();
/*  971 */         } catch (IOException e) {
/*  972 */           printDebug("IOException when trying to close socket getting the certificate");
/*      */         } 
/*      */       } 
/*      */       
/*  976 */       if (certificateChain != null) {
/*  977 */         String cacertsPath = getJavaHome(sddHome.toString()) + getJavaHome(sddHome.toString()) + "lib" + File.separator + "security" + File.separator + "cacerts";
/*      */         
/*  979 */         CertificateImporter certImporter = new CertificateImporter();
/*      */         try {
/*  981 */           certImporter.importCertToTruststore(certificateChain[certificateChain.length - 1], cacertsPath, "changeit"
/*      */               
/*  983 */               .toCharArray(), "EDM_Server");
/*  984 */         } catch (KeyCertIOException|com.mentor.infrasec.keycertutils.exceptions.KeyCertException e) {
/*  985 */           printDebug("Failed to save EDM Server certificate to JRE bundle cacerts");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  991 */     return getSuccessBundleInfo(serverUrl, serverBundleName, sddHome.toString(), thisVersionInfo.getSddPlatform(), releaseInfo, 
/*  992 */         getJavaHome(sddHome.toString()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private VersionInfo getMatchingClientVersionInfo(String serverFlowId, String serverUpdateName, String serverBundleName, String serverChecksum, String miniTree) {
/*  998 */     List<VersionInfo> clientVersionInfoList = readVersionsFromDB(miniTree.toString());
/*      */     
/* 1000 */     for (VersionInfo clientVersionInfo : clientVersionInfoList) {
/* 1001 */       if (versionInfoMatches(serverFlowId, serverUpdateName, serverBundleName, serverChecksum, clientVersionInfo)) {
/*      */         
/* 1003 */         printDebug("Found a entry in mgc.file with matching version info");
/* 1004 */         return clientVersionInfo;
/*      */       } 
/*      */     } 
/*      */     
/* 1008 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean versionInfoMatches(String serverFlowId, String serverUpdateName, String serverBundleName, String serverChecksum, VersionInfo clientVersionInfo) {
/* 1014 */     String clientFlowId = clientVersionInfo.getFlowId();
/* 1015 */     String clientUpdateName = clientVersionInfo.getUpdateName();
/* 1016 */     String clientBundleName = clientVersionInfo.getBundleName();
/* 1017 */     String clientChecksum = clientVersionInfo.getChecksum();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1023 */     if (CommonUtils.isNullOrEmpty(clientFlowId) || CommonUtils.isNullOrEmpty(clientBundleName) || 
/* 1024 */       CommonUtils.isNullOrEmpty(clientChecksum) || clientUpdateName == null) {
/* 1025 */       return false;
/*      */     }
/*      */     
/* 1028 */     boolean matches = clientFlowIdMatchesServerFlowId(clientFlowId, serverFlowId);
/* 1029 */     matches &= clientUpdateName.equals(serverUpdateName);
/* 1030 */     matches &= clientBundleName.equals(serverBundleName);
/* 1031 */     matches &= clientChecksum.equals(serverChecksum);
/* 1032 */     return matches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getMatchingInstalledSddHome(VersionInfo versionInfo) {
/* 1047 */     printDebug("Inside checkInUserInstalledTrees().");
/* 1048 */     if (versionInfo == null) {
/* 1049 */       return null;
/*      */     }
/*      */     
/* 1052 */     String serverFlowId = versionInfo.getFlowId();
/* 1053 */     String serverUpdateName = versionInfo.getUpdateName();
/* 1054 */     String pathtoJarFile = versionInfo.getJarPath();
/* 1055 */     printDebug("Checking in user installed SDD_HOME's with the following: serverFlowId=" + serverFlowId + ", serverUpdateName=" + serverUpdateName + ", pathtoJarFile=" + pathtoJarFile);
/*      */ 
/*      */     
/* 1058 */     ReleaseReader reader = new ReleaseReader();
/*      */     
/* 1060 */     for (String releaseId : reader.getReleaseIDs()) {
/* 1061 */       String sddHome = reader.getSddHome(releaseId);
/* 1062 */       File sddHomeFile = new File(sddHome);
/* 1063 */       String sddHomeParent = sddHomeFile.getParent();
/* 1064 */       String clientFlowId = SDDFlowID.getFlowId_fromFile(sddHome);
/* 1065 */       String clientUpdate = SDDFlowID.getUpdateName(sddHome);
/*      */       
/* 1067 */       printDebug("As read from ReleaseReader/SDDFLowID, sddHome=" + sddHome + ", clientFlowId=" + clientFlowId + ", clientUpdate=" + clientUpdate);
/*      */ 
/*      */       
/* 1070 */       if (clientFlowIdMatchesServerFlowId(clientFlowId, serverFlowId) && clientUpdate.equals(serverUpdateName)) {
/* 1071 */         printDebug("FlowID and UpdateName match between server and client.");
/* 1072 */         File clientBundleJar = new File(Paths.get(sddHomeParent, new String[] { pathtoJarFile }).toString());
/* 1073 */         if (clientBundleJar.exists()) {
/* 1074 */           printDebug("The jar file also exists.");
/* 1075 */           return sddHome;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1080 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean clientFlowIdMatchesServerFlowId(String clientFlowId, String serverFlowId) {
/* 1091 */     String clientStringToCompare = (clientFlowId == null) ? "" : clientFlowId.replaceFirst("Innovator3D IC", "Xpedition").replaceFirst("A-ICP", "Xpedition");
/*      */ 
/*      */ 
/*      */     
/* 1095 */     String serverStringToCompare = (serverFlowId == null) ? "" : serverFlowId.replaceFirst("Innovator3D IC", "Xpedition").replaceFirst("A-ICP", "Xpedition");
/*      */     
/* 1097 */     return clientStringToCompare.equals(serverStringToCompare);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String downloadBundle(String serverHost, int serverPort, String serverFlowId, String serverUpdateName, String serverBundleName, Path sddHome, Path miniTree, String serverGuid) throws ClientBundleDownloadException {
/*      */     String bundleUri;
/* 1104 */     Path serverMiniTree = getServerMiniTree(serverGuid, miniTree);
/*      */     
/*      */     try {
/* 1107 */       if (!Files.exists(miniTree, new java.nio.file.LinkOption[0])) {
/* 1108 */         Files.createDirectories(miniTree, (FileAttribute<?>[])new FileAttribute[0]);
/*      */       }
/*      */       
/* 1111 */       if (Files.exists(sddHome, new java.nio.file.LinkOption[0])) {
/* 1112 */         printDebug("Minitree sddHome=" + String.valueOf(sddHome) + " already exists. So, deleting it and will be creating again.");
/*      */         
/* 1114 */         FileUtils.forceDelete(sddHome.toFile());
/*      */       } 
/*      */       
/* 1117 */       Files.createDirectories(sddHome, (FileAttribute<?>[])new FileAttribute[0]);
/*      */     }
/* 1119 */     catch (IOException e) {
/* 1120 */       throw new ClientBundleDownloadException("Error setting up miniTree and SDD_HOME for download", e);
/*      */     } 
/*      */ 
/*      */     
/* 1124 */     initializeProgressDialog();
/*      */ 
/*      */     
/*      */     try {
/* 1128 */       bundleUri = URLEncoder.encode(serverBundleName, "UTF-8") + "/" + URLEncoder.encode(serverBundleName, "UTF-8") + ".zip";
/* 1129 */     } catch (UnsupportedEncodingException e) {
/* 1130 */       printDebug("Exception encoding Bundle URI: " + e.getMessage() + ", " + String.valueOf(e.getCause()));
/* 1131 */       throw new ClientBundleDownloadException("Exception encoding Bundle URI", e);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     String dirPathOfBundle = serverMiniTree.toString();
/* 1137 */     long leftDiskSpace = (new File(dirPathOfBundle)).getFreeSpace();
/* 1138 */     printDebug("Free Disk space is " + leftDiskSpace);
/*      */     
/* 1140 */     String zipName = serverBundleName + ".zip";
/* 1141 */     String bundlePath = copyBundleFromServer(bundleUri, dirPathOfBundle, zipName, serverHost, serverPort);
/* 1142 */     if (CommonUtils.isNullOrEmpty(bundlePath)) {
/* 1143 */       throw new ClientBundleDownloadException("Path to downloaded bundle was null or empty");
/*      */     }
/* 1145 */     return bundlePath;
/*      */   }
/*      */ 
/*      */   
/*      */   private void unpackBundle(String bundlePath, Path destDirPath) throws ClientBundleDownloadException {
/*      */     try {
/* 1151 */       printDebug("Inside unpackBundle(). Input: BundlePath=" + bundlePath + ", destDirPath=" + String.valueOf(destDirPath));
/*      */       
/* 1153 */       Files.createDirectories(destDirPath, (FileAttribute<?>[])new FileAttribute[0]);
/*      */       
/* 1155 */       printDebug("Created directories for destDirPath=" + String.valueOf(destDirPath));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1162 */       String jreZipFileName = "jrelinux" + this.arch + ".jar";
/* 1163 */       String jreExtractedDir = "linux" + this.arch;
/* 1164 */       String jrePlatformDir = (this.arch == 64) ? "amd64_linux" : "linux";
/* 1165 */       if (this.windows) {
/* 1166 */         jreZipFileName = "jrewin" + this.arch + ".jar";
/* 1167 */         jreExtractedDir = (this.arch == 64) ? "win64" : "win32";
/* 1168 */         jrePlatformDir = jreExtractedDir;
/*      */       } 
/*      */       
/* 1171 */       printDebug("jreZipFileName=" + jreZipFileName + ", jreExtractedDir=" + jreExtractedDir + ", jrePlatformDir=" + jrePlatformDir);
/*      */ 
/*      */       
/* 1174 */       try { ZipFile zipFile = new ZipFile(bundlePath); 
/* 1175 */         try { if (this.totalUnpackFiles == 0) {
/* 1176 */             this.totalUnpackFiles = zipFile.size() + 250;
/*      */           }
/* 1178 */           zipFile.close(); } catch (Throwable throwable) { try { zipFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */       
/* 1182 */       byte[] buffer = new byte[1024];
/* 1183 */       ZipInputStream zis = new ZipInputStream(new FileInputStream(bundlePath));
/*      */       
/* 1185 */       try { ZipEntry zipEntry = null;
/* 1186 */         while ((zipEntry = zis.getNextEntry()) != null) {
/* 1187 */           this.currentUnpackFileCount++;
/* 1188 */           int newPercentage = (int)(this.PERCENT_AFTER_DOWNLOAD + this.currentUnpackFileCount / this.totalUnpackFiles * this.PERCENT_FOR_UNPACK);
/*      */           
/* 1190 */           setPercentageComplete(newPercentage, false, "Unpacking the zip file.");
/* 1191 */           String fileName = zipEntry.getName();
/* 1192 */           printDebug("Entry is " + fileName);
/*      */           
/* 1194 */           Path newFilePath = Paths.get(destDirPath.toString(), new String[] { fileName });
/* 1195 */           if (zipEntry.isDirectory()) {
/* 1196 */             printDebug("This is a directory.");
/* 1197 */             if (!Files.exists(newFilePath, new java.nio.file.LinkOption[0])) {
/* 1198 */               printDebug("This doesn't exist and hence creating it.");
/* 1199 */               Files.createDirectories(newFilePath, (FileAttribute<?>[])new FileAttribute[0]);
/*      */               
/* 1201 */               if (!Files.exists(newFilePath, new java.nio.file.LinkOption[0])) {
/* 1202 */                 printDebug("Error: The directory is NOT created.");
/*      */               }
/*      */             } 
/*      */           } else {
/* 1206 */             printDebug("This is a file.");
/* 1207 */             File newFileObj = newFilePath.toFile();
/* 1208 */             newFileObj.getParentFile().mkdirs();
/* 1209 */             printDebug("Writing to the file....");
/* 1210 */             FileOutputStream fos = new FileOutputStream(newFileObj); 
/*      */             try { int len;
/* 1212 */               while ((len = zis.read(buffer)) > 0) {
/* 1213 */                 fos.write(buffer, 0, len);
/*      */               }
/* 1215 */               printDebug("Closing the file.");
/* 1216 */               fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 1217 */              printDebug("File is extracted.");
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1222 */           if (fileName.contains(jreZipFileName)) {
/* 1223 */             String extractDir = "jre" + jreExtractedDir;
/* 1224 */             Path jreDestDirPath = Paths.get(destDirPath.toString(), new String[] { fileName }).getParent();
/* 1225 */             jreDestDirPath = Paths.get(jreDestDirPath.toString(), new String[] { extractDir });
/*      */             
/* 1227 */             printDebug("Inside JRE zip file if condition and calling unpackBundle() again with newFile=" + newFilePath
/* 1228 */                 .toString() + ", jreDestDirPath=" + String.valueOf(jreDestDirPath));
/*      */             
/* 1230 */             unpackBundle(newFilePath.toString(), jreDestDirPath);
/* 1231 */             printDebug("After unzipping JRE jar file");
/*      */             
/* 1233 */             Path dirToCreate = Paths.get(destDirPath.toString(), new String[] { "SDD_HOME", "common", jrePlatformDir, "jre", "default" });
/*      */             
/* 1235 */             printDebug("dirToCreate=" + String.valueOf(dirToCreate));
/* 1236 */             Files.createDirectories(dirToCreate, (FileAttribute<?>[])new FileAttribute[0]);
/*      */             
/* 1238 */             Path fromDir = Paths.get(jreDestDirPath.toString(), new String[] { "jre" });
/* 1239 */             printDebug("Move contents from " + String.valueOf(fromDir) + " to " + String.valueOf(dirToCreate));
/* 1240 */             Files.move(fromDir, dirToCreate, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*      */             
/* 1242 */             printDebug("forceDelete " + String.valueOf(jreDestDirPath));
/* 1243 */             FileUtils.forceDelete(jreDestDirPath.toFile());
/*      */           } 
/*      */           
/* 1246 */           zis.closeEntry();
/*      */         } 
/* 1248 */         printDebug("Closing the zip file.");
/* 1249 */         zis.close(); } catch (Throwable throwable) { try { zis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */          throw throwable; }
/* 1251 */        printDebug("Deleting the zip file if exists - " + bundlePath);
/* 1252 */       Files.deleteIfExists(Paths.get(bundlePath, new String[0]));
/*      */     }
/* 1254 */     catch (Exception e) {
/* 1255 */       printDebug("Exception inside unpackBundle" + e.getMessage());
/* 1256 */       throw new ClientBundleDownloadException("Failed to unpack client Bundle", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void validateBundle(File downloadedZip, String expectedChecksum) throws ClientBundleDownloadException {
/*      */     try {
/* 1263 */       printDebug("Checking if checksum of '" + downloadedZip.getAbsolutePath() + "' is the expected value of " + expectedChecksum);
/*      */       
/* 1265 */       if (CommonUtils.isNullOrEmpty(expectedChecksum))
/*      */       {
/* 1267 */         throw new ClientBundleDownloadException("Checksum reported on server was null.");
/*      */       }
/*      */       
/* 1270 */       String checksum = (new ClientBundleChecksumCalculator()).getChecksumOfFileOrDir(downloadedZip);
/*      */       
/* 1272 */       printDebug("Calculated checksum of zipped bundle: " + checksum);
/*      */       
/* 1274 */       if (CommonUtils.isNullOrEmpty(checksum)) {
/* 1275 */         String error = "Error calculating checksum of zipped bundle.  Returned null.";
/* 1276 */         printDebug(error);
/* 1277 */         throw new ClientBundleDownloadException(error);
/*      */       } 
/*      */       
/* 1280 */       if (!expectedChecksum.trim().equals(checksum.trim())) {
/* 1281 */         String error = "Checksum of bundle does not match the expected value.  Bundle is not valid.";
/* 1282 */         printDebug(error);
/* 1283 */         throw new ClientBundleDownloadException(error);
/*      */       } 
/* 1285 */     } catch (Exception e) {
/* 1286 */       String error = "Failed to validate client bundle";
/* 1287 */       printDebug(error + ": " + error);
/* 1288 */       throw new ClientBundleDownloadException(error, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected ServerDialogInfo launchGui(String serverurl, boolean noPrompt) {
/* 1294 */     printDebug("Inside launchgui(). Input is serverurl=" + serverurl + ", noPrompt=" + noPrompt);
/* 1295 */     ServerDialogInfo dlg = new ServerDialogInfo();
/* 1296 */     dlg.setSuccess(false);
/* 1297 */     dlg.setErrorMsg("Unable to launch GUI from ClientBundleLoaderBase");
/* 1298 */     return dlg;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String copyBundleFromServer(String bundleUri, String dirpath, String zipFileName, final String host, final int httpPort) throws ClientBundleDownloadException {
/* 1304 */     setPercentageComplete(this.PERCENT_BEFORE_DOWNLOAD, true, "Starting download.");
/*      */     
/* 1306 */     printDebug("Inside copyBundleFromServer(). Input: bundleUri=" + bundleUri + ", dirpath=" + dirpath + ", zipFileName=" + zipFileName + ", host=" + host + ", httpPort=" + httpPort + ". Downloading the bundle now.");
/*      */ 
/*      */ 
/*      */     
/* 1310 */     String uri = "/iS3WebServices/is3API/download/" + bundleUri;
/* 1311 */     final Path outputfilename = Paths.get(dirpath, new String[] { zipFileName });
/* 1312 */     final StringBuilder sb = new StringBuilder();
/*      */     try {
/* 1314 */       NetworkUtils.httpGetExecute(host, httpPort, false, true, uri, Optional.empty(), new HttpGetExecutor()
/*      */           {
/*      */             public void execute(CloseableHttpResponse httpResponse) throws ConnectorBaseException, IOException
/*      */             {
/* 1318 */               InputStream is = null;
/* 1319 */               OutputStream outStream = null;
/*      */               try {
/* 1321 */                 if (httpResponse.getCode() != 200) {
/* 1322 */                   String message = "";
/* 1323 */                   if (httpResponse.getCode() == 406)
/*      */                   {
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1329 */                     message = ". The EDM Server is not configured for client auto-download capabilities.";
/*      */                   }
/* 1331 */                   throw new ClientBundleDownloadException(httpResponse.getReasonPhrase() + httpResponse.getReasonPhrase());
/*      */                 } 
/* 1333 */                 is = httpResponse.getEntity().getContent();
/*      */                 
/* 1335 */                 outStream = new FileOutputStream(outputfilename.toString());
/*      */                 
/* 1337 */                 byte[] buffer = new byte[8192];
/*      */                 
/* 1339 */                 int totalBytes = 0; int bytesRead;
/* 1340 */                 while ((bytesRead = is.read(buffer)) != -1) {
/* 1341 */                   totalBytes += bytesRead;
/* 1342 */                   int newPercentage = (int)(ClientBundleLoaderBase.this.PERCENT_BEFORE_DOWNLOAD + totalBytes / ClientBundleLoaderBase.this.BUNDLE_SIZE * ClientBundleLoaderBase.this.PERCENT_FOR_DOWNLOAD);
/*      */                   
/* 1344 */                   ClientBundleLoaderBase.this.setPercentageComplete(newPercentage, false, "Downloading zip file from " + host + ":" + httpPort);
/*      */                   
/* 1346 */                   outStream.write(buffer, 0, bytesRead);
/*      */                 } 
/* 1348 */                 sb.append(outputfilename.toString());
/* 1349 */               } catch (Exception e) {
/* 1350 */                 ClientBundleLoaderBase.this.printDebug("Exception in copyBundleFromServer() inside execute() [Class:" + String.valueOf(e.getClass()) + "] / Details: " + e
/* 1351 */                     .getMessage());
/* 1352 */                 throw new ConnectorBaseException(e.getMessage());
/*      */               } finally {
/*      */                 
/*      */                 try {
/* 1356 */                   if (outStream != null) {
/* 1357 */                     outStream.close();
/*      */                   }
/* 1359 */                 } catch (IOException iOException) {}
/*      */ 
/*      */                 
/*      */                 try {
/* 1363 */                   if (is != null) {
/* 1364 */                     is.close();
/*      */                   }
/* 1366 */                 } catch (IOException iOException) {}
/*      */               }
/*      */             
/*      */             }
/*      */           });
/* 1371 */     } catch (ServerNotAchievableException|ServerCertificateInvalidException|GeneralErrorException|NetworkProblemException|IOException e) {
/*      */ 
/*      */       
/* 1374 */       String errorMessage = e.getMessage();
/*      */ 
/*      */       
/* 1377 */       if (e instanceof GeneralErrorException && 
/* 1378 */         e.getCause() != null && !CommonUtils.isNullOrEmpty(e.getCause().getMessage())) {
/* 1379 */         errorMessage = e.getCause().getMessage();
/*      */       }
/*      */       
/* 1382 */       printDebug("Exception in copyBundleFromServer() [Class:" + String.valueOf(e.getClass()) + "] / Details: " + errorMessage);
/* 1383 */       throw new ClientBundleDownloadException(errorMessage, e);
/*      */     } 
/*      */     
/* 1386 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private List<VersionInfo> readVersionsFromDB(String path) {
/* 1390 */     File file = new File(Paths.get(path, new String[] { "mgc.file" }).toString());
/* 1391 */     VersionInfo[] versionsInfo = null; 
/* 1392 */     try { FileReader fileReader = new FileReader(file); 
/* 1393 */       try { Gson gson = new Gson();
/* 1394 */         versionsInfo = (VersionInfo[])gson.fromJson(fileReader, VersionInfo[].class);
/* 1395 */         fileReader.close(); } catch (Throwable throwable) { try { fileReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/* 1396 */     { printDebug("Exception in readVersionsFromDB()[ Class:" + 
/* 1397 */           String.valueOf(e.getClass()) + "]/ Details: " + e.getMessage());
/* 1398 */       versionsInfo = new VersionInfo[0]; }
/*      */ 
/*      */     
/* 1401 */     return Arrays.asList(versionsInfo);
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeVersionsToDB(List<VersionInfo> versionsInfo, String path) {
/* 1406 */     File file = new File(Paths.get(path, new String[] { "mgc.file" }).toString()); 
/* 1407 */     try { FileWriter fileWriter = new FileWriter(file); 
/* 1408 */       try { Gson gson = new Gson();
/* 1409 */         gson.toJson(versionsInfo.toArray(), fileWriter);
/* 1410 */         fileWriter.close(); } catch (Throwable throwable) { try { fileWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/* 1411 */     { printDebug("Exception in writeVersionsToDB()[ Class:" + 
/* 1412 */           String.valueOf(e.getClass()) + "]/ Details: " + e.getMessage()); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private String getJavaHome(String sddHome) {
/* 1418 */     String jrePlatformDir = (this.arch == 64) ? "amd64_linux" : "linux";
/* 1419 */     if (this.windows) {
/* 1420 */       jrePlatformDir = (this.arch == 64) ? "win64" : "win32";
/*      */     }
/*      */     
/* 1423 */     return (new File(sddHome + sddHome + "common" + File.separator + File.separator + jrePlatformDir + "jre" + File.separator + "default"))
/* 1424 */       .getAbsolutePath();
/*      */   }
/*      */   
/*      */   protected void printDebug(String debugMsg) {
/* 1428 */     DebugPrinter.printDebug(debugMsg, this.debug, this.debugFileOutput);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getPossibleMinitreeDirs() {
/* 1445 */     String envVarDir = System.getenv("EBS_CBL_DIR");
/* 1446 */     String defaultDir = this.windows ? WINDOWS_DEFAULT_DIR : LINUX_DEFAULT_DIR;
/* 1447 */     defaultDir = defaultDir + defaultDir;
/* 1448 */     String userHomeDir = System.getProperty("user.home") + System.getProperty("user.home");
/*      */     
/* 1450 */     if (envVarDir == null || envVarDir.isBlank()) {
/* 1451 */       return new String[] { defaultDir, userHomeDir };
/*      */     }
/* 1453 */     envVarDir = envVarDir + envVarDir;
/* 1454 */     return new String[] { envVarDir, defaultDir, userHomeDir };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getDownloadMinitreeDir() {
/* 1469 */     for (String minitree : getPossibleMinitreeDirs()) {
/* 1470 */       File minitreeDir = new File(minitree);
/* 1471 */       if (minitreeDir.exists()) {
/* 1472 */         if (minitreeDir.canWrite()) {
/* 1473 */           return minitree;
/*      */         }
/*      */       } else {
/* 1476 */         boolean created = minitreeDir.mkdirs();
/* 1477 */         if (created) {
/* 1478 */           return minitree;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1484 */     return System.getProperty("user.home") + System.getProperty("user.home");
/*      */   }
/*      */   
/*      */   protected void initializeProgressDialog() {}
/*      */   
/*      */   protected void setPercentageComplete(int newPercentage, boolean force, String prependText) {}
/*      */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\bundles\ClientBundleLoaderBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */