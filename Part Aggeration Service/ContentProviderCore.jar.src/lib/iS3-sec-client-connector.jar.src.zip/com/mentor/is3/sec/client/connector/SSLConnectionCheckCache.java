/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.common.ReloadableX509TrustManager;
/*     */ import com.mentor.is3.sec.common.SSLInitializationException;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLConnectionCheckCache
/*     */ {
/*  41 */   private static SSLConnectionCheckCache instance = null;
/*     */   
/*     */   private Map<String, SSLServerChecks> cache;
/*     */   
/*     */   private boolean sslCtxInitialized = false;
/*     */   
/*  47 */   private ReloadableX509TrustManager sslTrustMgr = null;
/*     */   
/*     */   private boolean isSslCtxInitialized() {
/*  50 */     return this.sslCtxInitialized;
/*     */   }
/*     */   
/*     */   private SSLConnectionCheckCache() {
/*  54 */     this.cache = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public ReloadableX509TrustManager getSslTrustManager() {
/*  59 */     return this.sslTrustMgr;
/*     */   }
/*     */   
/*     */   public boolean checkCertyficateTrusted(X509Certificate[] chain, String authType) {
/*  63 */     return checkCertificateTrusted(chain, authType);
/*     */   }
/*     */   
/*     */   public boolean checkCertificateTrusted(X509Certificate[] chain, String authType) {
/*     */     try {
/*  68 */       this.sslTrustMgr.checkClientTrusted(chain, authType);
/*  69 */       return true;
/*     */     }
/*  71 */     catch (Exception e) {
/*  72 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void initSslCtxForApplication() throws SSLInitializationException, NoSuchAlgorithmException, KeyManagementException {
/*  78 */     this.sslTrustMgr = new ReloadableX509TrustManager(true);
/*     */ 
/*     */     
/*  81 */     TrustManager[] trustManagers = { (TrustManager)this.sslTrustMgr };
/*  82 */     SSLContext sslContext = SSLContext.getInstance("TLS");
/*  83 */     sslContext.init(null, trustManagers, null);
/*     */     
/*  85 */     SSLContext.setDefault(sslContext);
/*  86 */     this.sslCtxInitialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SSLConnectionCheckCache getInstance() {
/*  92 */     if (instance == null) {
/*  93 */       synchronized (SSLConnectionCheckCache.class) {
/*  94 */         if (instance == null) {
/*  95 */           instance = new SSLConnectionCheckCache();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 100 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLServerChecks getSSLPortCheckObject(String host, int port) throws SSLInitializationException, KeyManagementException, NoSuchAlgorithmException {
/* 106 */     return getSSLPortCheckObject(host, port, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLServerChecks getSSLPortCheckObject(String host, int port, boolean isBatch) throws SSLInitializationException, KeyManagementException, NoSuchAlgorithmException {
/* 113 */     if (!isSslCtxInitialized()) {
/* 114 */       initSslCtxForApplication();
/*     */     }
/* 116 */     String url = host + ":" + host;
/* 117 */     boolean updateCache = true;
/* 118 */     SSLServerChecks serverCheckObject = null;
/* 119 */     if (this.cache.containsKey(url)) {
/* 120 */       serverCheckObject = this.cache.get(url);
/*     */ 
/*     */ 
/*     */       
/* 124 */       if (serverCheckObject.isBatchLogin() == isBatch) {
/* 125 */         updateCache = false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 130 */     if (updateCache) {
/* 131 */       serverCheckObject = new SSLServerChecks(host, port, isBatch);
/* 132 */       this.cache.put(url, serverCheckObject);
/*     */     } 
/*     */     
/* 135 */     return serverCheckObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\SSLConnectionCheckCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */