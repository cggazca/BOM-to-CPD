/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.server.api.transfer.adminsession.SessionTokenTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3SessionIdentity
/*     */ {
/*     */   private SessionTokenTO sessionToken;
/*     */   private final Integer sessionId;
/*     */   private final String tokenId;
/*     */   private final char[] password;
/*     */   
/*     */   public IS3SessionIdentity(String tokenId, char[] password, Integer sessionId) {
/*  44 */     this.tokenId = tokenId;
/*  45 */     this.password = password;
/*  46 */     this.sessionId = sessionId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  51 */     return "IS3SessionIdentity[" + this.tokenId + "," + String.valueOf(this.password) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTokenId() {
/*  60 */     return this.tokenId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getPassword() {
/*  69 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPasswordAsString() {
/*  78 */     return String.valueOf(this.password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getSessionId() {
/*  88 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionTokenTO getSessionToken() {
/*  98 */     return this.sessionToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionToken(SessionTokenTO sessionToken) {
/* 108 */     this.sessionToken = sessionToken;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3SessionIdentity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */