/*    */ package com.mentor.is3.sec.client.connector.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerNotAchievableException
/*    */   extends ConnectorBaseException
/*    */ {
/*    */   private static final long serialVersionUID = -2938305771665484091L;
/*    */   
/*    */   public ServerNotAchievableException(String message) {
/* 20 */     super(message);
/*    */   }
/*    */   
/*    */   public ServerNotAchievableException(String message, Throwable cause) {
/* 24 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\exceptions\ServerNotAchievableException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */