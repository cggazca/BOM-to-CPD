/*    */ package com.mentor.is3.sec.client.connector;
/*    */ 
/*    */ import org.jboss.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IS3Connector
/*    */ {
/* 24 */   private static IS3ConnectorInstance connector = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IS3ConnectorInstance getInstance() {
/* 32 */     if (connector == null) {
/* 33 */       connector = new IS3ConnectorInstance();
/*    */     }
/* 35 */     return connector;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IS3ConnectorInstance getInstance(Logger log) {
/* 45 */     if (connector == null) {
/* 46 */       connector = new IS3ConnectorInstance();
/*    */     }
/* 48 */     IS3ConnectorInstance.log = log;
/* 49 */     return connector;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3Connector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */