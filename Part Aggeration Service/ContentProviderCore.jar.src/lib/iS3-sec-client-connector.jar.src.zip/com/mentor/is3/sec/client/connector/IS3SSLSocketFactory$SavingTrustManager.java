/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SavingTrustManager
/*     */   implements X509TrustManager
/*     */ {
/*     */   private final X509TrustManager tm;
/*     */   protected static X509Certificate[] chain;
/*     */   
/*     */   SavingTrustManager(X509TrustManager tm) {
/* 116 */     this.tm = tm;
/*     */   }
/*     */   
/*     */   public X509Certificate[] getAcceptedIssuers() {
/* 120 */     return this.tm.getAcceptedIssuers();
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 125 */     this.tm.checkClientTrusted(chain, authType);
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 130 */     SavingTrustManager.chain = chain;
/* 131 */     this.tm.checkServerTrusted(chain, authType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static X509Certificate[] getChain() {
/* 139 */     return chain;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3SSLSocketFactory$SavingTrustManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */