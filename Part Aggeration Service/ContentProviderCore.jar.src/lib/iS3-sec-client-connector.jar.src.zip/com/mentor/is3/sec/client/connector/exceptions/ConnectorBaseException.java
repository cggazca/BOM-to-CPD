/*    */ package com.mentor.is3.sec.client.connector.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectorBaseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 5694103515942944278L;
/*    */   
/*    */   public ConnectorBaseException(String message) {
/* 16 */     super(message);
/*    */   }
/*    */   
/*    */   public ConnectorBaseException(String message, Throwable cause) {
/* 20 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public ConnectorBaseException() {}
/*    */ 
/*    */   
/*    */   public ConnectorBaseException(Throwable cause) {
/* 28 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\exceptions\ConnectorBaseException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */