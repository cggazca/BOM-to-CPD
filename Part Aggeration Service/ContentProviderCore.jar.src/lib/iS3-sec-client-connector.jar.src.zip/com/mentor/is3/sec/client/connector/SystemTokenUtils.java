/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.sun.jna.platform.win32.Secur32;
/*     */ import com.sun.jna.platform.win32.Secur32Util;
/*     */ import com.sun.jna.platform.win32.Sspi;
/*     */ import com.sun.jna.platform.win32.SspiUtil;
/*     */ import com.sun.jna.platform.win32.Win32Exception;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import sun.security.krb5.RealmException;
/*     */ import sun.security.krb5.internal.ccache.Credentials;
/*     */ import sun.security.krb5.internal.ccache.CredentialsCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemTokenUtils
/*     */ {
/*     */   private static final String EV_EBS_FORCE_NO_WIN_AUTH = "EBS_FORCE_NO_WIN_AUTH";
/*     */   private static final String scheme = "Kerberos";
/*     */   private static String servicePrincipalName;
/*     */   private static Sspi.CredHandle clientCred;
/*     */   private static Sspi.CtxtHandle sspiContext;
/*     */   
/*     */   public static boolean isWinAuthAvailable() {
/*     */     try {
/*  45 */       if (System.getenv("EBS_FORCE_NO_WIN_AUTH") != null) {
/*  46 */         return false;
/*     */       }
/*  48 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*  52 */     String os = System.getProperty("os.name");
/*  53 */     os = (os != null) ? os.toLowerCase(Locale.ROOT) : null;
/*  54 */     if (os != null && os.contains("windows")) {
/*     */       try {
/*  56 */         return (Sspi.MAX_TOKEN_SIZE > 0);
/*  57 */       } catch (Exception ignore) {
/*  58 */         return false;
/*     */       } 
/*     */     }
/*  61 */     return false;
/*     */   }
/*     */   
/*     */   public static byte[] getWindowsToken(String spn) {
/*  65 */     servicePrincipalName = spn;
/*     */     
/*  67 */     String username = Secur32Util.getUserNameEx(2);
/*     */     
/*  69 */     Sspi.TimeStamp lifetime = new Sspi.TimeStamp();
/*     */     
/*  71 */     clientCred = new Sspi.CredHandle();
/*  72 */     int rc = Secur32.INSTANCE.AcquireCredentialsHandle(username, "Kerberos", 2, null, null, null, null, clientCred, lifetime);
/*     */ 
/*     */     
/*  75 */     if (0 != rc) {
/*  76 */       throw new Win32Exception(rc);
/*     */     }
/*     */     
/*  79 */     return getToken(null, null, servicePrincipalName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getToken(Sspi.CtxtHandle continueCtx, Sspi.SecBufferDesc continueToken, String targetName) {
/*  86 */     IntByReference attr = new IntByReference();
/*  87 */     SspiUtil.ManagedSecBufferDesc token = new SspiUtil.ManagedSecBufferDesc(2, Sspi.MAX_TOKEN_SIZE);
/*     */     
/*  89 */     Sspi.CtxtHandle sspiContext = new Sspi.CtxtHandle();
/*  90 */     int rc = Secur32.INSTANCE.InitializeSecurityContext(clientCred, continueCtx, targetName, 3, 0, 16, continueToken, 0, sspiContext, (Sspi.SecBufferDesc)token, attr, null);
/*     */ 
/*     */     
/*  93 */     switch (rc) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 590610:
/* 104 */         return token.getBuffer(0).getBytes();
/*     */       case 0:
/*     */         dispose();
/*     */     }  dispose();
/* 108 */     throw new Win32Exception(rc); } public static void dispose() { if (clientCred != null && !clientCred.isNull()) {
/* 109 */       int rc = Secur32.INSTANCE.FreeCredentialsHandle(clientCred);
/* 110 */       if (0 != rc) {
/* 111 */         throw new Win32Exception(rc);
/*     */       }
/*     */     } 
/* 114 */     if (sspiContext != null && !sspiContext.isNull()) {
/* 115 */       int rc = Secur32.INSTANCE.DeleteSecurityContext(sspiContext);
/* 116 */       if (0 != rc) {
/* 117 */         throw new Win32Exception(rc);
/*     */       }
/*     */     } 
/* 120 */     clientCred = null;
/* 121 */     sspiContext = null; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasValidTicketInCache(String user) {
/*     */     CredentialsCache cache;
/*     */     Credentials[] creds;
/*     */     try {
/* 129 */       cache = CredentialsCache.getInstance();
/* 130 */       creds = cache.getCredsList();
/* 131 */     } catch (Exception e) {
/* 132 */       return false;
/*     */     } 
/*     */     
/* 135 */     if (creds == null) {
/* 136 */       return false;
/*     */     }
/* 138 */     String defaultPrincipal = cache.getPrimaryPrincipal().toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     for (int i = 0; i < creds.length; i++) {
/* 146 */       if (defaultPrincipal.equalsIgnoreCase(user) || defaultPrincipal.split("@")[0].equalsIgnoreCase(user)) {
/*     */         try {
/* 148 */           String servicePrincipal = creds[i].getServicePrincipal().toString();
/* 149 */           Date start = creds[i].getStartTime().toDate();
/* 150 */           Date expiration = creds[i].getEndTime().toDate();
/* 151 */           Date current = new Date();
/*     */           
/* 153 */           if (expiration.compareTo(current) < 0 || start.compareTo(current) > 0) {
/* 154 */             return false;
/*     */           }
/*     */           
/* 157 */           if (servicePrincipal.contains("krbtgt"))
/* 158 */             return true; 
/* 159 */         } catch (RealmException e) {
/* 160 */           return false;
/*     */         } 
/*     */       }
/*     */     } 
/* 164 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\SystemTokenUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */