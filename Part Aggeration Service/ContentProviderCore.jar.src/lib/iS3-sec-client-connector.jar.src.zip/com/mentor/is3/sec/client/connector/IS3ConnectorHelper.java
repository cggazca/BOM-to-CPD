/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.common.machine.MachineInfo;
/*     */ import com.mentor.is3.server.api.adminsession.ChangePasswordWithoutSessionRequest;
/*     */ import com.mentor.is3.server.api.adminsession.LoginRequest;
/*     */ import com.mentor.is3.server.api.adminsession.LoginResponse;
/*     */ import com.mentor.is3.server.api.adminsession.LogoutRequest;
/*     */ import com.mentor.is3.server.api.adminsession.LogoutResponse;
/*     */ import com.mentor.is3.server.api.adminsession.PreLogoutRequest;
/*     */ import com.mentor.is3.server.api.adminsession.PreLogoutResponse;
/*     */ import com.mentor.is3.server.api.frontcontroller.AbstractRequest;
/*     */ import com.mentor.is3.server.api.frontcontroller.DefaultResponse;
/*     */ import com.mentor.is3.server.api.frontcontroller.FrontController;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.LogoutResultValue;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.SessionNature;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.SessionTokenTO;
/*     */ import com.mentor.is3.server.api.transfer.adminsession.security.AuthOptionKey;
/*     */ import jakarta.ejb.EJBAccessException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3ConnectorHelper
/*     */ {
/*  46 */   private static Logger log = Logger.getLogger(IS3ConnectorHelper.class);
/*     */   
/*  48 */   private static ThreadLocal<Context> threadLocalContext = new ThreadLocal<>();
/*     */ 
/*     */   
/*     */   public static <V> V handleException(Exception e) {
/*  52 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IS3Connection connect(IS3ConnectionProperties props) {
/*  63 */     return connect(props, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static IS3Connection connect(IS3ConnectionProperties props, boolean isBatch) {
/*  68 */     IS3Connection conn = new IS3Connection();
/*     */     try {
/*  70 */       log.debug("Start connection to server " + props.getHost() + ":" + props.getWebPort() + " using new IS3Connection: " + String.valueOf(conn));
/*  71 */       conn.connect(props, isBatch);
/*     */     }
/*  73 */     catch (RuntimeException e) {
/*  74 */       log.debug("Caught RuntimeException of type " + e.getClass().getName() + ": " + e.getMessage());
/*  75 */       conn.close();
/*  76 */       conn = null;
/*  77 */       throw e;
/*     */     } 
/*  79 */     return conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object lookupRemoteEjb(String moduleName, String beanName, String interfaceName, IS3ConnectionProperties is3ConnectionProperties) {
/*     */     try {
/*  95 */       Hashtable<?, ?> props = IS3ConnectionDefaultProperties.getNamingProperties(is3ConnectionProperties);
/*     */       
/*  97 */       Context ctx = threadLocalContext.get();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 105 */       long threadId = -1L;
/* 106 */       if (log.isDebugEnabled()) {
/* 107 */         threadId = Thread.currentThread().getId();
/*     */       }
/*     */       
/* 110 */       boolean needNewContext = false;
/* 111 */       if (ctx == null) {
/* 112 */         log.debug("" + threadId + ": needs a new context because there isn't one cached");
/* 113 */         needNewContext = true;
/*     */       } else {
/* 115 */         Hashtable<?, ?> cachedProps = ctx.getEnvironment();
/* 116 */         if (cachedProps == null) {
/* 117 */           log.debug("" + threadId + ": needs a new context because we couldn't access the cached properties");
/* 118 */           needNewContext = true;
/*     */         }
/* 120 */         else if (hasPropertyChanged(cachedProps, props, "java.naming.security.principal")) {
/* 121 */           log.debug("" + threadId + ": needs a new context because the user changed");
/* 122 */           needNewContext = true;
/*     */         }
/* 124 */         else if (hasPropertyChanged(cachedProps, props, "java.naming.security.credentials")) {
/* 125 */           log.debug("" + threadId + ": needs a new context because the password changed");
/* 126 */           needNewContext = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 131 */       if (needNewContext) {
/* 132 */         ctx = new InitialContext(props);
/* 133 */         threadLocalContext.set(ctx);
/* 134 */       } else if (log.isTraceEnabled()) {
/*     */         
/* 136 */         Context newContext = new InitialContext(props);
/* 137 */         Hashtable<?, ?> cachedEnv = ctx.getEnvironment();
/* 138 */         Hashtable<?, ?> newEnv = newContext.getEnvironment();
/* 139 */         Set<?> cachedKeys = cachedEnv.keySet();
/* 140 */         Set<?> newKeys = newEnv.keySet();
/* 141 */         for (Object key : cachedKeys) {
/* 142 */           if (newKeys.contains(key)) {
/* 143 */             log.trace(String.valueOf(key) + ": cached=" + String.valueOf(key) + ", new=" + String.valueOf(cachedEnv.get(key))); continue;
/*     */           } 
/* 145 */           log.trace(String.valueOf(key) + "=" + String.valueOf(key) + " is in cached env but not new env");
/*     */         } 
/*     */         
/* 148 */         for (Object key : newKeys) {
/* 149 */           if (!cachedKeys.contains(key)) {
/* 150 */             log.trace(String.valueOf(key) + "=" + String.valueOf(key) + " is in new env but not in cached env");
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 155 */       String lookupName = "ejb:is3-server-app/" + moduleName + "/" + beanName + "!" + interfaceName;
/*     */       
/* 157 */       log.debug("looking up remoteEjb at: " + lookupName);
/*     */       
/* 159 */       Object remoteRef = ctx.lookup(lookupName);
/* 160 */       return remoteRef;
/*     */     }
/* 162 */     catch (NamingException e) {
/* 163 */       log.debug("Caught NamingException: " + e.getMessage());
/* 164 */       return handleException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean hasPropertyChanged(Hashtable<?, ?> cachedProps, Hashtable<?, ?> newProps, String propName) {
/* 169 */     String cachedVal = (String)cachedProps.get(propName);
/* 170 */     String newVal = (String)newProps.get(propName);
/* 171 */     log.trace("Comparing property " + propName + ": cached=" + cachedVal + ", new=" + newVal);
/* 172 */     return (cachedVal == null || !cachedVal.equals(newVal));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SessionTokenTO logIn(FrontController fc, String language, String machineId, String userPassword) {
/* 189 */     log.debug("Starting frontController loginRequest to: " + machineId);
/* 190 */     LoginRequest loginRequest = new LoginRequest(machineId, userPassword);
/* 191 */     loginRequest.setSessionNature(SessionNature.DESKTOP);
/* 192 */     loginRequest.setOsUserName(System.getProperty("user.name"));
/* 193 */     loginRequest.setMachineName(MachineInfo.getMachineName());
/* 194 */     LoginResponse response = (LoginResponse)fc.execute((AbstractRequest)loginRequest);
/* 195 */     if (!response.isSuccess()) {
/* 196 */       log.debug("Login failed with error: " + response.getMessage());
/* 197 */       throw new RuntimeException("Login failed: " + response.getMessage());
/*     */     } 
/*     */     
/* 200 */     return response.getSessionToken();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SessionTokenTO logIn(FrontController fc, String machineId, String userPassword, String serverAddress, String serverPort, String machineName) {
/* 222 */     return logIn(fc, machineId, userPassword, serverAddress, serverPort, machineName, false, AuthOptionKey.IS3_AUTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SessionTokenTO logIn(FrontController fc, String machineId, String userPassword, String serverAddress, String serverPort, String machineName, boolean noSessionCheck, AuthOptionKey authMethod) {
/* 248 */     LoginRequest loginRequest = new LoginRequest(machineId, userPassword, serverAddress, serverPort, machineName, getTimeZone().getOffset((new Date()).getTime()), noSessionCheck, authMethod);
/* 249 */     loginRequest.setSessionNature(SessionNature.DESKTOP);
/* 250 */     loginRequest.setOsUserName(System.getProperty("user.name"));
/* 251 */     loginRequest.setMachineName(MachineInfo.getMachineName());
/* 252 */     LoginResponse response = (LoginResponse)fc.execute((AbstractRequest)loginRequest);
/* 253 */     if (!response.isSuccess()) {
/* 254 */       throw new RuntimeException("Login failed: " + response.getMessage());
/*     */     }
/* 256 */     return response.getSessionToken();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logout(FrontController fc) {
/* 264 */     logout(fc, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LogoutResultValue logout(FrontController fc, boolean force) {
/*     */     try {
/* 279 */       LogoutResponse response = (LogoutResponse)fc.execute((AbstractRequest)new LogoutRequest(force));
/* 280 */       if (!response.isSuccess()) {
/* 281 */         String reason = response.getMessage();
/* 282 */         if (reason.contains("IS3WrapperRuntimeException")) {
/* 283 */           for (String causeMsg : response.getErrorMessages()) {
/* 284 */             reason = reason + ", " + reason;
/*     */           }
/*     */         }
/* 287 */         throw new RuntimeException("Logout failed: " + reason);
/*     */       } 
/* 289 */       return response.getLogoutResult();
/*     */     }
/* 291 */     catch (EJBAccessException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       if (e.getMessage().contains("Invalid User")) {
/* 301 */         return LogoutResultValue.OK;
/*     */       }
/* 303 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(SessionTokenTO sessionToken) {
/* 316 */     return String.format("[%s,%s,%s,%s]", new Object[] { Integer.valueOf(sessionToken.getId()), sessionToken.getUserLogin(), sessionToken.getSessionToken(), sessionToken
/* 317 */           .getPassword() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void changePassword(FrontController fc, Integer userId, char[] oldPassword, char[] newPassword) {
/* 333 */     ChangePasswordWithoutSessionRequest request = new ChangePasswordWithoutSessionRequest(userId, new String(oldPassword), new String(newPassword));
/*     */     
/* 335 */     request.setDoLogin(false);
/*     */     
/* 337 */     DefaultResponse response = (DefaultResponse)fc.execute((AbstractRequest)request);
/* 338 */     if (!response.isSuccess()) {
/* 339 */       throw new RuntimeException(response.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public static TimeZone getTimeZone() {
/* 344 */     return Calendar.getInstance().getTimeZone();
/*     */   }
/*     */   
/*     */   public static LogoutResultValue prelogout(FrontController fc) {
/* 348 */     PreLogoutResponse response = (PreLogoutResponse)fc.execute((AbstractRequest)new PreLogoutRequest());
/* 349 */     if (!response.isSuccess()) {
/* 350 */       String reason = response.getMessage();
/* 351 */       if (reason.contains("IS3WrapperRuntimeException"))
/*     */       {
/* 353 */         for (String causeMsg : response.getErrorMessages()) {
/* 354 */           reason = reason + ", " + reason;
/*     */         }
/*     */       }
/* 357 */       throw new RuntimeException("PreLogout failed: " + reason);
/*     */     } 
/*     */     
/* 360 */     return response.getLogoutResult();
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3ConnectorHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */