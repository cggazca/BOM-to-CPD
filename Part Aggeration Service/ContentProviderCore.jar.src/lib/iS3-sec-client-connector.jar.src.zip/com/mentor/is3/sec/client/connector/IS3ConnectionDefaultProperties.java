/*     */ package com.mentor.is3.sec.client.connector;
/*     */ 
/*     */ import com.mentor.is3.sec.common.machine.MachineIDFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.remoting3.RemotingOptions;
/*     */ import org.xnio.OptionMap;
/*     */ import org.xnio.Options;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IS3ConnectionDefaultProperties
/*     */ {
/*  40 */   private static final Logger logger = Logger.getLogger(IS3ConnectionDefaultProperties.class);
/*     */ 
/*     */   
/*     */   public static final String HOST = "localhost";
/*     */ 
/*     */   
/*  46 */   public static final String REMOTING_PORT = Integer.toString(4447);
/*     */   
/*     */   public static final String MESSAGING_PORT = "5445";
/*     */   
/*     */   public static final String WEB_PORT = "31001";
/*     */   
/*  52 */   public static final String LANGUAGE = Locale.ENGLISH.getLanguage();
/*     */ 
/*     */   
/*     */   public static final String WF_INITIAL_CONTEXT_FACTORY = "org.wildfly.naming.client.WildFlyInitialContextFactory";
/*     */ 
/*     */   
/*     */   public static final int CONNECTION_TIMEOUT_SECONDS = 500;
/*     */ 
/*     */   
/*     */   public static final int HEARTBEAT_INTERVAL = 600000;
/*     */ 
/*     */   
/*     */   public static final String APP_NAME = "is3-server-app";
/*     */ 
/*     */   
/*     */   public static final String SERVER_MODULE_NAME = "is3-server-ejb";
/*     */ 
/*     */   
/*     */   public static final String SEC_MODULE_NAME = "iS3-sec-server";
/*     */ 
/*     */   
/*     */   public static final String STATEFUL_SERVER_MODULE_NAME = "iS3-sec-server-stateful";
/*     */ 
/*     */   
/*     */   public static final String FRONT_CONTROLLER_BEAN_NAME = "FrontControllerBean";
/*     */ 
/*     */   
/*     */   public static final String FRONT_CONTROLLER_STATEFUL_BEAN_NAME = "FrontControllerStatefulBean";
/*     */   
/*     */   public static final String INTERNATIONALIZATION_BEAN_NAME = "InternationalizationBean";
/*     */   
/*     */   public static final String REMOTE_SYSCONFIG_BEAN_NAME = "SysConfigRemoteBean";
/*     */   
/*     */   public static final String REMOTE_CONFIG_BEAN_NAME = "RemoteConfigBean";
/*     */   
/*     */   public static final String SESSION_HEARTBEAT_TRACKING_BEAN_NAME = "SessionHeartbeatTrackingBean";
/*     */   
/*  89 */   public static final Boolean PROPERTY_IDENTITY_PER_THREAD = Boolean.FALSE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int JMS_RECONNECT_ATTEMPTS = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int JMS_CONFIRM_WINDOW_SIZE = 1048576;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long JMS_CONNECTION_TTL = 1860000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public static final String MACHINE_ID = (new Initializer<String>()
/*     */     {
/*     */       public String init()
/*     */       {
/*     */         try {
/* 121 */           return MachineIDFactory.getID();
/*     */         }
/* 123 */         catch (Exception e) {
/* 124 */           return IS3ConnectorHelper.<String>handleException(e);
/*     */         } 
/*     */       }
/* 127 */     }).init();
/*     */   
/*     */   public static Hashtable<?, ?> getNamingProperties(IS3ConnectionProperties is3ConnectionProperties) {
/* 130 */     Properties props = new Properties();
/* 131 */     props.put("jboss.naming.client.ejb.context", "true");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     props.put("java.naming.factory.initial", "org.wildfly.naming.client.WildFlyInitialContextFactory");
/*     */ 
/*     */     
/* 141 */     String username = null;
/* 142 */     String password = null;
/*     */     
/*     */     try {
/* 145 */       IS3DelegatingCallbackHandler callbackHandler = new IS3DelegatingCallbackHandler(is3ConnectionProperties, true);
/* 146 */       NameCallback nameCallback = new NameCallback("Username");
/* 147 */       PasswordCallback passwordCallback = new PasswordCallback("Password", false);
/* 148 */       callbackHandler.handle(new Callback[] { nameCallback, passwordCallback });
/* 149 */       username = nameCallback.getName();
/* 150 */       password = new String(passwordCallback.getPassword());
/* 151 */     } catch (IOException|javax.security.auth.callback.UnsupportedCallbackException e) {
/* 152 */       logger.error("Error setting up username and password for connection", e);
/*     */     } 
/*     */     
/* 155 */     props.put("java.naming.security.principal", username);
/* 156 */     props.put("java.naming.security.credentials", password);
/* 157 */     return props;
/*     */   }
/*     */   
/*     */   public static OptionMap getConnectionProviderOptions() {
/* 161 */     OptionMap.Builder bld = OptionMap.builder();
/* 162 */     bld.set(Options.SSL_ENABLED, Boolean.FALSE);
/* 163 */     bld.set(Options.SASL_SERVER_AUTH, Boolean.FALSE);
/* 164 */     bld.set(Options.SSL_STARTTLS, Boolean.FALSE);
/* 165 */     addCommonOptions(bld);
/* 166 */     OptionMap omap = bld.getMap();
/* 167 */     return omap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OptionMap getSSLConnectionProviderOptions() {
/* 177 */     System.setProperty("jboss.ejb.client.properties.skip.classloader.scan", "true");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     OptionMap.Builder bld = OptionMap.builder();
/* 183 */     bld.set(Options.SSL_ENABLED, Boolean.TRUE);
/* 184 */     bld.set(Options.SASL_SERVER_AUTH, Boolean.FALSE);
/* 185 */     bld.set(Options.SSL_STARTTLS, Boolean.TRUE);
/* 186 */     addCommonOptions(bld);
/* 187 */     OptionMap omap = bld.getMap();
/* 188 */     return omap;
/*     */   }
/*     */   
/*     */   public static OptionMap getConnectionOptions() {
/* 192 */     OptionMap.Builder bld = OptionMap.builder();
/* 193 */     bld.set(Options.SASL_POLICY_NOPLAINTEXT, Boolean.FALSE);
/* 194 */     bld.set(Options.SASL_POLICY_NOANONYMOUS, Boolean.FALSE);
/* 195 */     addCommonOptions(bld);
/* 196 */     OptionMap omap = bld.getMap();
/* 197 */     return omap;
/*     */   }
/*     */ 
/*     */   
/*     */   public static OptionMap getSSLConnectionOptions(String cipherToUse) {
/* 202 */     OptionMap.Builder bld = OptionMap.builder();
/* 203 */     bld.set(Options.SASL_POLICY_NOPLAINTEXT, Boolean.FALSE);
/* 204 */     bld.set(Options.SASL_POLICY_NOANONYMOUS, Boolean.FALSE);
/* 205 */     bld.set(Options.SSL_ENABLED, Boolean.TRUE);
/* 206 */     bld.set(Options.SSL_STARTTLS, Boolean.TRUE);
/* 207 */     bld.setSequence(Options.SSL_ENABLED_PROTOCOLS, (Object[])new String[] { "TLSv1.2" });
/* 208 */     if (cipherToUse != null)
/* 209 */       bld.setSequence(Options.SSL_ENABLED_CIPHER_SUITES, (Object[])new String[] { cipherToUse }); 
/* 210 */     addCommonOptions(bld);
/* 211 */     OptionMap omap = bld.getMap();
/* 212 */     return omap;
/*     */   }
/*     */   
/*     */   private static void addCommonOptions(OptionMap.Builder bld) {
/* 216 */     bld.set(RemotingOptions.HEARTBEAT_INTERVAL, 600000);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\iS3-sec-client-connector.jar!\com\mentor\is3\sec\client\connector\IS3ConnectionDefaultProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */