module org.apache.commons.logging {
  requires org.apache.logging.log4j;
  requires org.slf4j;
  requires avalon.framework;
  requires java.logging;
  requires javax.servlet.api;
  requires logkit;
  requires org.apache.log4j;
  requires java.base;
  
  exports org.apache.commons.logging;
  exports org.apache.commons.logging.impl;
  
  uses org.apache.commons.logging.LogFactory;
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */