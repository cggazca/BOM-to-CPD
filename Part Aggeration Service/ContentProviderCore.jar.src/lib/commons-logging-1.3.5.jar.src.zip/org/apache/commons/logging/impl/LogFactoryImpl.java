/*      */ package org.apache.commons.logging.impl;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.util.Hashtable;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogConfigurationException;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LogFactoryImpl
/*      */   extends LogFactory
/*      */ {
/*      */   private static final String LOGGING_IMPL_LOG4J_LOGGER = "org.apache.commons.logging.impl.Log4JLogger";
/*      */   private static final String LOGGING_IMPL_JDK14_LOGGER = "org.apache.commons.logging.impl.Jdk14Logger";
/*      */   private static final String LOGGING_IMPL_LUMBERJACK_LOGGER = "org.apache.commons.logging.impl.Jdk13LumberjackLogger";
/*      */   private static final String LOGGING_IMPL_SIMPLE_LOGGER = "org.apache.commons.logging.impl.SimpleLog";
/*      */   private static final String PKG_IMPL = "org.apache.commons.logging.impl.";
/*   76 */   private static final int PKG_LEN = "org.apache.commons.logging.impl.".length();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String LOG_PROPERTY = "org.apache.commons.logging.Log";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String LOG_PROPERTY_OLD = "org.apache.commons.logging.log";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String ALLOW_FLAWED_CONTEXT_PROPERTY = "org.apache.commons.logging.Log.allowFlawedContext";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String ALLOW_FLAWED_DISCOVERY_PROPERTY = "org.apache.commons.logging.Log.allowFlawedDiscovery";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String ALLOW_FLAWED_HIERARCHY_PROPERTY = "org.apache.commons.logging.Log.allowFlawedHierarchy";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   private static final String[] classesToDiscover = new String[] { "org.apache.commons.logging.impl.Jdk14Logger", "org.apache.commons.logging.impl.SimpleLog" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClassLoader getClassLoader(Class<?> clazz) {
/*  163 */     return LogFactory.getClassLoader(clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClassLoader getContextClassLoader() throws LogConfigurationException {
/*  174 */     return LogFactory.getContextClassLoader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ClassLoader getContextClassLoaderInternal() throws LogConfigurationException {
/*  197 */     return AccessController.<ClassLoader>doPrivileged(() -> LogFactory.directGetContextClassLoader());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getSystemProperty(String key, String def) throws SecurityException {
/*  211 */     return AccessController.<String>doPrivileged(() -> System.getProperty(key, def));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isDiagnosticsEnabled() {
/*  221 */     return LogFactory.isDiagnosticsEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   private static String trim(String src) {
/*  226 */     if (src == null) {
/*  227 */       return null;
/*      */     }
/*  229 */     return src.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useTCCL = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String diagnosticPrefix;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  246 */   protected Hashtable<String, Object> attributes = new Hashtable<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   protected Hashtable<String, Log> instances = new Hashtable<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String logClassName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Constructor<?> logConstructor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  271 */   protected Class<?>[] logConstructorSignature = new Class[] { String.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Method logMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  282 */   protected Class<?>[] logMethodSignature = new Class[] { LogFactory.class };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowFlawedContext;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowFlawedDiscovery;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowFlawedHierarchy;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogFactoryImpl() {
/*  303 */     initDiagnostics();
/*  304 */     if (isDiagnosticsEnabled()) {
/*  305 */       logDiagnostic("Instance created.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Log createLogFromClass(String logAdapterClassName, String logCategory, boolean affectState) throws LogConfigurationException {
/*  328 */     if (isDiagnosticsEnabled()) {
/*  329 */       logDiagnostic("Attempting to instantiate '" + logAdapterClassName + "'");
/*      */     }
/*      */     
/*  332 */     Object[] params = { logCategory };
/*  333 */     Log logAdapter = null;
/*  334 */     Constructor<?> constructor = null;
/*      */     
/*  336 */     Class<?> logAdapterClass = null;
/*  337 */     ClassLoader currentCL = getBaseClassLoader();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  342 */       logDiagnostic("Trying to load '" + logAdapterClassName + "' from class loader " + objectId(currentCL)); try {
/*      */         Class<?> clazz;
/*  344 */         if (isDiagnosticsEnabled()) {
/*      */           URL url;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  350 */           String resourceName = logAdapterClassName.replace('.', '/') + ".class";
/*  351 */           if (currentCL != null) {
/*  352 */             url = currentCL.getResource(resourceName);
/*      */           } else {
/*  354 */             url = ClassLoader.getSystemResource(resourceName + ".class");
/*      */           } 
/*      */           
/*  357 */           if (url == null) {
/*  358 */             logDiagnostic("Class '" + logAdapterClassName + "' [" + resourceName + "] cannot be found.");
/*      */           } else {
/*  360 */             logDiagnostic("Class '" + logAdapterClassName + "' was found at '" + url + "'");
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  366 */           clazz = Class.forName(logAdapterClassName, true, currentCL);
/*  367 */         } catch (ClassNotFoundException originalClassNotFoundException) {
/*      */ 
/*      */ 
/*      */           
/*  371 */           String msg = originalClassNotFoundException.getMessage();
/*  372 */           logDiagnostic("The log adapter '" + logAdapterClassName + "' is not available via class loader " + 
/*  373 */               objectId(currentCL) + ": " + trim(msg));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  382 */             clazz = Class.forName(logAdapterClassName);
/*  383 */           } catch (ClassNotFoundException secondaryClassNotFoundException) {
/*      */             
/*  385 */             msg = secondaryClassNotFoundException.getMessage();
/*  386 */             logDiagnostic("The log adapter '" + logAdapterClassName + "' is not available via the LogFactoryImpl class class loader: " + 
/*  387 */                 trim(msg));
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*  392 */         constructor = clazz.getConstructor(this.logConstructorSignature);
/*  393 */         Object o = constructor.newInstance(params);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  399 */         if (o instanceof Log) {
/*  400 */           logAdapterClass = clazz;
/*  401 */           logAdapter = (Log)o;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  415 */         handleFlawedHierarchy(currentCL, clazz);
/*  416 */       } catch (NoClassDefFoundError e) {
/*      */         Class<?> clazz;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  422 */         String msg = clazz.getMessage();
/*  423 */         logDiagnostic("The log adapter '" + logAdapterClassName + "' is missing dependencies when loaded via class loader " + 
/*  424 */             objectId(currentCL) + ": " + 
/*  425 */             trim(msg));
/*      */         break;
/*  427 */       } catch (ExceptionInInitializerError e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  434 */         String msg = e.getMessage();
/*  435 */         logDiagnostic("The log adapter '" + logAdapterClassName + "' is unable to initialize itself when loaded via class loader " + 
/*  436 */             objectId(currentCL) + ": " + 
/*  437 */             trim(msg));
/*      */         break;
/*  439 */       } catch (LogConfigurationException e) {
/*      */ 
/*      */         
/*  442 */         throw e;
/*  443 */       } catch (Throwable t) {
/*  444 */         handleThrowable(t);
/*      */ 
/*      */ 
/*      */         
/*  448 */         handleFlawedDiscovery(logAdapterClassName, t);
/*      */       } 
/*      */       
/*  451 */       if (currentCL == null) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  457 */       currentCL = getParentClassLoader(currentCL);
/*      */     } 
/*      */     
/*  460 */     if (logAdapterClass != null && affectState) {
/*      */       
/*  462 */       this.logClassName = logAdapterClassName;
/*  463 */       this.logConstructor = constructor;
/*      */ 
/*      */       
/*      */       try {
/*  467 */         this.logMethod = logAdapterClass.getMethod("setLogFactory", this.logMethodSignature);
/*  468 */         logDiagnostic("Found method setLogFactory(LogFactory) in '" + logAdapterClassName + "'");
/*  469 */       } catch (Throwable t) {
/*  470 */         handleThrowable(t);
/*  471 */         this.logMethod = null;
/*  472 */         logDiagnostic("[INFO] '" + logAdapterClassName + "' from class loader " + objectId(currentCL) + " does not declare optional method setLogFactory(LogFactory)");
/*      */       } 
/*      */ 
/*      */       
/*  476 */       logDiagnostic("Log adapter '" + logAdapterClassName + "' from class loader " + 
/*  477 */           objectId(logAdapterClass.getClassLoader()) + " has been selected for use.");
/*      */     } 
/*      */     
/*  480 */     return logAdapter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Log discoverLogImplementation(String logCategory) throws LogConfigurationException {
/*  498 */     if (isDiagnosticsEnabled()) {
/*  499 */       logDiagnostic("Discovering a Log implementation...");
/*      */     }
/*      */     
/*  502 */     initConfiguration();
/*      */     
/*  504 */     Log result = null;
/*      */ 
/*      */     
/*  507 */     String specifiedLogClassName = findUserSpecifiedLogClassName();
/*      */     
/*  509 */     if (specifiedLogClassName != null) {
/*  510 */       if (isDiagnosticsEnabled()) {
/*  511 */         logDiagnostic("Attempting to load user-specified log class '" + specifiedLogClassName + "'...");
/*      */       }
/*      */ 
/*      */       
/*  515 */       result = createLogFromClass(specifiedLogClassName, logCategory, true);
/*      */ 
/*      */       
/*  518 */       if (result == null) {
/*  519 */         StringBuilder messageBuffer = new StringBuilder("User-specified log class '");
/*  520 */         messageBuffer.append(specifiedLogClassName);
/*  521 */         messageBuffer.append("' cannot be found or is not useable.");
/*      */ 
/*      */ 
/*      */         
/*  525 */         informUponSimilarName(messageBuffer, specifiedLogClassName, "org.apache.commons.logging.impl.Log4JLogger");
/*  526 */         informUponSimilarName(messageBuffer, specifiedLogClassName, "org.apache.commons.logging.impl.Jdk14Logger");
/*  527 */         informUponSimilarName(messageBuffer, specifiedLogClassName, "org.apache.commons.logging.impl.Jdk13LumberjackLogger");
/*  528 */         informUponSimilarName(messageBuffer, specifiedLogClassName, "org.apache.commons.logging.impl.SimpleLog");
/*  529 */         throw new LogConfigurationException(messageBuffer.toString());
/*      */       } 
/*      */       
/*  532 */       return result;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  563 */     if (isDiagnosticsEnabled()) {
/*  564 */       logDiagnostic("No user-specified Log implementation; performing discovery using the standard supported logging implementations...");
/*      */     }
/*      */ 
/*      */     
/*  568 */     for (int i = 0; i < classesToDiscover.length && result == null; i++) {
/*  569 */       result = createLogFromClass(classesToDiscover[i], logCategory, true);
/*      */     }
/*      */     
/*  572 */     if (result == null) {
/*  573 */       throw new LogConfigurationException("No suitable Log implementation");
/*      */     }
/*      */ 
/*      */     
/*  577 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String findUserSpecifiedLogClassName() {
/*  588 */     if (isDiagnosticsEnabled()) {
/*  589 */       logDiagnostic("Trying to get log class from attribute 'org.apache.commons.logging.Log'");
/*      */     }
/*  591 */     String specifiedClass = (String)getAttribute("org.apache.commons.logging.Log");
/*      */     
/*  593 */     if (specifiedClass == null) {
/*  594 */       if (isDiagnosticsEnabled()) {
/*  595 */         logDiagnostic("Trying to get log class from attribute 'org.apache.commons.logging.log'");
/*      */       }
/*      */       
/*  598 */       specifiedClass = (String)getAttribute("org.apache.commons.logging.log");
/*      */     } 
/*      */     
/*  601 */     if (specifiedClass == null) {
/*  602 */       if (isDiagnosticsEnabled()) {
/*  603 */         logDiagnostic("Trying to get log class from system property 'org.apache.commons.logging.Log'");
/*      */       }
/*      */       
/*      */       try {
/*  607 */         specifiedClass = getSystemProperty("org.apache.commons.logging.Log", (String)null);
/*  608 */       } catch (SecurityException e) {
/*  609 */         if (isDiagnosticsEnabled()) {
/*  610 */           logDiagnostic("No access allowed to system property 'org.apache.commons.logging.Log' - " + e
/*  611 */               .getMessage());
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  616 */     if (specifiedClass == null) {
/*  617 */       if (isDiagnosticsEnabled()) {
/*  618 */         logDiagnostic("Trying to get log class from system property 'org.apache.commons.logging.log'");
/*      */       }
/*      */       
/*      */       try {
/*  622 */         specifiedClass = getSystemProperty("org.apache.commons.logging.log", (String)null);
/*  623 */       } catch (SecurityException e) {
/*  624 */         if (isDiagnosticsEnabled()) {
/*  625 */           logDiagnostic("No access allowed to system property 'org.apache.commons.logging.log' - " + e
/*  626 */               .getMessage());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  634 */     if (specifiedClass != null) {
/*  635 */       specifiedClass = specifiedClass.trim();
/*      */     }
/*      */     
/*  638 */     return specifiedClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(String name) {
/*  649 */     return this.attributes.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getAttributeNames() {
/*  659 */     return (String[])this.attributes.keySet().toArray((Object[])EMPTY_STRING_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ClassLoader getBaseClassLoader() throws LogConfigurationException {
/*  680 */     ClassLoader thisClassLoader = getClassLoader(LogFactoryImpl.class);
/*      */     
/*  682 */     if (!this.useTCCL) {
/*  683 */       return thisClassLoader;
/*      */     }
/*      */     
/*  686 */     ClassLoader contextClassLoader = getContextClassLoaderInternal();
/*      */     
/*  688 */     ClassLoader baseClassLoader = getLowestClassLoader(contextClassLoader, thisClassLoader);
/*      */ 
/*      */     
/*  691 */     if (baseClassLoader == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  696 */       if (!this.allowFlawedContext) {
/*  697 */         throw new LogConfigurationException("Bad class loader hierarchy; LogFactoryImpl was loaded via a class loader that is not related to the current context class loader.");
/*      */       }
/*      */ 
/*      */       
/*  701 */       if (isDiagnosticsEnabled()) {
/*  702 */         logDiagnostic("[WARNING] the context class loader is not part of a parent-child relationship with the class loader that loaded LogFactoryImpl.");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  709 */       return contextClassLoader;
/*      */     } 
/*      */     
/*  712 */     if (baseClassLoader != contextClassLoader) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  718 */       if (!this.allowFlawedContext) {
/*  719 */         throw new LogConfigurationException("Bad class loader hierarchy; LogFactoryImpl was loaded via a class loader that is not related to the current context class loader.");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  724 */       if (isDiagnosticsEnabled()) {
/*  725 */         logDiagnostic("Warning: the context class loader is an ancestor of the class loader that loaded LogFactoryImpl; it should be the same or a descendant. The application using commons-logging should ensure the context class loader is used correctly.");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  734 */     return baseClassLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean getBooleanConfiguration(String key, boolean dflt) {
/*  742 */     String val = getConfigurationValue(key);
/*  743 */     if (val == null) {
/*  744 */       return dflt;
/*      */     }
/*  746 */     return Boolean.parseBoolean(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getConfigurationValue(String property) {
/*  761 */     if (isDiagnosticsEnabled()) {
/*  762 */       logDiagnostic("[ENV] Trying to get configuration for item " + property);
/*      */     }
/*      */     
/*  765 */     Object valueObj = getAttribute(property);
/*  766 */     if (valueObj != null) {
/*  767 */       if (isDiagnosticsEnabled()) {
/*  768 */         logDiagnostic("[ENV] Found LogFactory attribute [" + valueObj + "] for " + property);
/*      */       }
/*  770 */       return valueObj.toString();
/*      */     } 
/*      */     
/*  773 */     if (isDiagnosticsEnabled()) {
/*  774 */       logDiagnostic("[ENV] No LogFactory attribute found for " + property);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  782 */       String value = getSystemProperty(property, (String)null);
/*  783 */       if (value != null) {
/*  784 */         if (isDiagnosticsEnabled()) {
/*  785 */           logDiagnostic("[ENV] Found system property [" + value + "] for " + property);
/*      */         }
/*  787 */         return value;
/*      */       } 
/*      */       
/*  790 */       if (isDiagnosticsEnabled()) {
/*  791 */         logDiagnostic("[ENV] No system property found for property " + property);
/*      */       }
/*  793 */     } catch (SecurityException e) {
/*  794 */       if (isDiagnosticsEnabled()) {
/*  795 */         logDiagnostic("[ENV] Security prevented reading system property " + property);
/*      */       }
/*      */     } 
/*      */     
/*  799 */     if (isDiagnosticsEnabled()) {
/*  800 */       logDiagnostic("[ENV] No configuration defined for item " + property);
/*      */     }
/*      */     
/*  803 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Log getInstance(Class<?> clazz) throws LogConfigurationException {
/*  816 */     return getInstance(clazz.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Log getInstance(String name) throws LogConfigurationException {
/*  838 */     return this.instances.computeIfAbsent(name, this::newInstance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected String getLogClassName() {
/*  849 */     if (this.logClassName == null) {
/*  850 */       discoverLogImplementation(getClass().getName());
/*      */     }
/*      */     
/*  853 */     return this.logClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Constructor<?> getLogConstructor() throws LogConfigurationException {
/*  875 */     if (this.logConstructor == null) {
/*  876 */       discoverLogImplementation(getClass().getName());
/*      */     }
/*      */     
/*  879 */     return this.logConstructor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ClassLoader getLowestClassLoader(ClassLoader c1, ClassLoader c2) {
/*  896 */     if (c1 == null) {
/*  897 */       return c2;
/*      */     }
/*      */     
/*  900 */     if (c2 == null) {
/*  901 */       return c1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  907 */     ClassLoader current = c1;
/*  908 */     while (current != null) {
/*  909 */       if (current == c2) {
/*  910 */         return c1;
/*      */       }
/*      */       
/*  913 */       current = getParentClassLoader(current);
/*      */     } 
/*      */ 
/*      */     
/*  917 */     current = c2;
/*  918 */     while (current != null) {
/*  919 */       if (current == c1) {
/*  920 */         return c2;
/*      */       }
/*      */       
/*  923 */       current = getParentClassLoader(current);
/*      */     } 
/*      */     
/*  926 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ClassLoader getParentClassLoader(ClassLoader cl) {
/*      */     try {
/*  938 */       return AccessController.<ClassLoader>doPrivileged(() -> cl.getParent());
/*  939 */     } catch (SecurityException ex) {
/*  940 */       logDiagnostic("[SECURITY] Unable to obtain parent class loader");
/*  941 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleFlawedDiscovery(String logAdapterClassName, Throwable discoveryFlaw) {
/*  959 */     if (isDiagnosticsEnabled()) {
/*  960 */       logDiagnostic("Could not instantiate Log '" + logAdapterClassName + "' -- " + discoveryFlaw
/*      */           
/*  962 */           .getClass().getName() + ": " + discoveryFlaw
/*  963 */           .getLocalizedMessage());
/*      */       
/*  965 */       if (discoveryFlaw instanceof InvocationTargetException) {
/*      */ 
/*      */ 
/*      */         
/*  969 */         InvocationTargetException ite = (InvocationTargetException)discoveryFlaw;
/*  970 */         Throwable cause = ite.getTargetException();
/*  971 */         if (cause != null) {
/*  972 */           logDiagnostic("... InvocationTargetException: " + cause
/*  973 */               .getClass().getName() + ": " + cause
/*  974 */               .getLocalizedMessage());
/*      */           
/*  976 */           if (cause instanceof ExceptionInInitializerError) {
/*  977 */             ExceptionInInitializerError eiie = (ExceptionInInitializerError)cause;
/*  978 */             Throwable cause2 = eiie.getCause();
/*  979 */             if (cause2 != null) {
/*  980 */               StringWriter sw = new StringWriter();
/*  981 */               cause2.printStackTrace(new PrintWriter(sw, true));
/*  982 */               logDiagnostic("... ExceptionInInitializerError: " + sw.toString());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  989 */     if (!this.allowFlawedDiscovery) {
/*  990 */       throw new LogConfigurationException(discoveryFlaw);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleFlawedHierarchy(ClassLoader badClassLoader, Class<?> badClass) throws LogConfigurationException {
/* 1023 */     boolean implementsLog = false;
/* 1024 */     String logInterfaceName = Log.class.getName();
/* 1025 */     Class<?>[] interfaces = badClass.getInterfaces();
/* 1026 */     for (Class<?> element : interfaces) {
/* 1027 */       if (logInterfaceName.equals(element.getName())) {
/* 1028 */         implementsLog = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1033 */     if (implementsLog) {
/*      */ 
/*      */       
/* 1036 */       if (isDiagnosticsEnabled()) {
/*      */         try {
/* 1038 */           ClassLoader logInterfaceClassLoader = getClassLoader(Log.class);
/* 1039 */           logDiagnostic("Class '" + badClass.getName() + "' was found in class loader " + 
/* 1040 */               objectId(badClassLoader) + ". It is bound to a Log interface which is not the one loaded from class loader " + 
/* 1041 */               objectId(logInterfaceClassLoader));
/* 1042 */         } catch (Throwable t) {
/* 1043 */           handleThrowable(t);
/* 1044 */           logDiagnostic("Error while trying to output diagnostics about bad class '" + badClass + "'");
/*      */         } 
/*      */       }
/*      */       
/* 1048 */       if (!this.allowFlawedHierarchy) {
/* 1049 */         StringBuilder msg = new StringBuilder();
/* 1050 */         msg.append("Terminating logging for this context ");
/* 1051 */         msg.append("due to bad log hierarchy. ");
/* 1052 */         msg.append("You have more than one version of '");
/* 1053 */         msg.append(Log.class.getName());
/* 1054 */         msg.append("' visible.");
/* 1055 */         if (isDiagnosticsEnabled()) {
/* 1056 */           logDiagnostic(msg.toString());
/*      */         }
/* 1058 */         throw new LogConfigurationException(msg.toString());
/*      */       } 
/*      */       
/* 1061 */       if (isDiagnosticsEnabled()) {
/* 1062 */         StringBuilder msg = new StringBuilder();
/* 1063 */         msg.append("Warning: bad log hierarchy. ");
/* 1064 */         msg.append("You have more than one version of '");
/* 1065 */         msg.append(Log.class.getName());
/* 1066 */         msg.append("' visible.");
/* 1067 */         logDiagnostic(msg.toString());
/*      */       } 
/*      */     } else {
/*      */       
/* 1071 */       if (!this.allowFlawedDiscovery) {
/* 1072 */         StringBuilder msg = new StringBuilder();
/* 1073 */         msg.append("Terminating logging for this context. ");
/* 1074 */         msg.append("Log class '");
/* 1075 */         msg.append(badClass.getName());
/* 1076 */         msg.append("' does not implement the Log interface.");
/* 1077 */         if (isDiagnosticsEnabled()) {
/* 1078 */           logDiagnostic(msg.toString());
/*      */         }
/*      */         
/* 1081 */         throw new LogConfigurationException(msg.toString());
/*      */       } 
/*      */       
/* 1084 */       if (isDiagnosticsEnabled()) {
/* 1085 */         StringBuilder msg = new StringBuilder();
/* 1086 */         msg.append("[WARNING] Log class '");
/* 1087 */         msg.append(badClass.getName());
/* 1088 */         msg.append("' does not implement the Log interface.");
/* 1089 */         logDiagnostic(msg.toString());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void informUponSimilarName(StringBuilder messageBuffer, String name, String candidate) {
/* 1103 */     if (name.equals(candidate)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1112 */     if (name.regionMatches(true, 0, candidate, 0, PKG_LEN + 5)) {
/* 1113 */       messageBuffer.append(" Did you mean '");
/* 1114 */       messageBuffer.append(candidate);
/* 1115 */       messageBuffer.append("'?");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initConfiguration() {
/* 1127 */     this.allowFlawedContext = getBooleanConfiguration("org.apache.commons.logging.Log.allowFlawedContext", true);
/* 1128 */     this.allowFlawedDiscovery = getBooleanConfiguration("org.apache.commons.logging.Log.allowFlawedDiscovery", true);
/* 1129 */     this.allowFlawedHierarchy = getBooleanConfiguration("org.apache.commons.logging.Log.allowFlawedHierarchy", true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initDiagnostics() {
/*      */     String classLoaderName;
/* 1155 */     Class<LogFactoryImpl> clazz = (Class)getClass();
/* 1156 */     ClassLoader classLoader = getClassLoader(clazz);
/*      */     
/*      */     try {
/* 1159 */       if (classLoader == null) {
/* 1160 */         classLoaderName = "BOOTLOADER";
/*      */       } else {
/* 1162 */         classLoaderName = objectId(classLoader);
/*      */       } 
/* 1164 */     } catch (SecurityException e) {
/* 1165 */       classLoaderName = "UNKNOWN";
/*      */     } 
/* 1167 */     this.diagnosticPrefix = "[LogFactoryImpl@" + System.identityHashCode(this) + " from " + classLoaderName + "] ";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean isJdk13LumberjackAvailable() {
/* 1178 */     return isLogLibraryAvailable("Jdk13Lumberjack", "org.apache.commons.logging.impl.Jdk13LumberjackLogger");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean isJdk14Available() {
/* 1192 */     return isLogLibraryAvailable("Jdk14", "org.apache.commons.logging.impl.Jdk14Logger");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean isLog4JAvailable() {
/* 1203 */     return isLogLibraryAvailable("Log4J", "org.apache.commons.logging.impl.Log4JLogger");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isLogLibraryAvailable(String name, String className) {
/* 1212 */     if (isDiagnosticsEnabled()) {
/* 1213 */       logDiagnostic("Checking for '" + name + "'.");
/*      */     }
/*      */     try {
/* 1216 */       Log log = createLogFromClass(className, 
/*      */           
/* 1218 */           getClass().getName(), false);
/*      */ 
/*      */       
/* 1221 */       if (log == null) {
/* 1222 */         if (isDiagnosticsEnabled()) {
/* 1223 */           logDiagnostic("Did not find '" + name + "'.");
/*      */         }
/* 1225 */         return false;
/*      */       } 
/* 1227 */       if (isDiagnosticsEnabled()) {
/* 1228 */         logDiagnostic("Found '" + name + "'.");
/*      */       }
/* 1230 */       return true;
/* 1231 */     } catch (LogConfigurationException e) {
/* 1232 */       if (isDiagnosticsEnabled()) {
/* 1233 */         logDiagnostic("Logging system '" + name + "' is available but not useable.");
/*      */       }
/* 1235 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logDiagnostic(String msg) {
/* 1247 */     if (isDiagnosticsEnabled()) {
/* 1248 */       logRawDiagnostic(this.diagnosticPrefix + msg);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Log newInstance(String name) throws LogConfigurationException {
/*      */     try {
/*      */       Log instance;
/* 1262 */       if (this.logConstructor == null) {
/* 1263 */         instance = discoverLogImplementation(name);
/*      */       } else {
/*      */         
/* 1266 */         Object[] params = { name };
/* 1267 */         instance = (Log)this.logConstructor.newInstance(params);
/*      */       } 
/*      */       
/* 1270 */       if (this.logMethod != null) {
/* 1271 */         Object[] params = { this };
/* 1272 */         this.logMethod.invoke(instance, params);
/*      */       } 
/*      */       
/* 1275 */       return instance;
/*      */     }
/* 1277 */     catch (LogConfigurationException lce) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1282 */       throw lce;
/*      */     }
/* 1284 */     catch (InvocationTargetException e) {
/*      */ 
/*      */       
/* 1287 */       Throwable c = e.getTargetException();
/* 1288 */       throw new LogConfigurationException((c == null) ? e : c);
/* 1289 */     } catch (Throwable t) {
/* 1290 */       handleThrowable(t);
/*      */ 
/*      */       
/* 1293 */       throw new LogConfigurationException(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void release() {
/* 1308 */     logDiagnostic("Releasing all known loggers");
/* 1309 */     this.instances.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(String name) {
/* 1320 */     this.attributes.remove(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, Object value) {
/* 1349 */     if (this.logConstructor != null) {
/* 1350 */       logDiagnostic("setAttribute: call too late; configuration already performed.");
/*      */     }
/*      */     
/* 1353 */     if (value == null) {
/* 1354 */       this.attributes.remove(name);
/*      */     } else {
/* 1356 */       this.attributes.put(name, value);
/*      */     } 
/*      */     
/* 1359 */     if (name.equals("use_tccl"))
/* 1360 */       this.useTCCL = (value != null && Boolean.parseBoolean(value.toString())); 
/*      */   }
/*      */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\impl\LogFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */