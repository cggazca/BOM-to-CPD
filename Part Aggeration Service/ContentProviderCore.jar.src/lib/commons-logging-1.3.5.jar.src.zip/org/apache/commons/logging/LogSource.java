/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.commons.logging.impl.NoOpLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class LogSource
/*     */ {
/*  59 */   protected static Hashtable<String, Log> logs = new Hashtable<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean log4jIsAvailable;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static boolean jdk14IsAvailable = true;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Constructor<?> logImplctor;
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  83 */     log4jIsAvailable = isClassForName("org.apache.log4j.Logger");
/*     */ 
/*     */     
/*  86 */     String name = null;
/*     */     try {
/*  88 */       name = System.getProperty("org.apache.commons.logging.log");
/*  89 */       if (name == null) {
/*  90 */         name = System.getProperty("org.apache.commons.logging.Log");
/*     */       }
/*  92 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/*  95 */     if (name != null) {
/*     */       try {
/*  97 */         setLogImplementation(name);
/*  98 */       } catch (Throwable t) {
/*     */         try {
/* 100 */           setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
/* 101 */         } catch (Throwable throwable) {}
/*     */       } 
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 107 */         if (log4jIsAvailable) {
/* 108 */           setLogImplementation("org.apache.commons.logging.impl.Log4JLogger");
/*     */         } else {
/* 110 */           setLogImplementation("org.apache.commons.logging.impl.Jdk14Logger");
/*     */         } 
/* 112 */       } catch (Throwable t) {
/*     */         try {
/* 114 */           setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
/* 115 */         } catch (Throwable throwable) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log getInstance(Class<?> clazz) {
/* 130 */     return getInstance(clazz.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log getInstance(String name) {
/* 140 */     return logs.computeIfAbsent(name, k -> makeNewLogInstance(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getLogNames() {
/* 151 */     return (String[])logs.keySet().toArray((Object[])EMPTY_STRING_ARRAY);
/*     */   }
/*     */   
/*     */   private static boolean isClassForName(String className) {
/*     */     try {
/* 156 */       Class.forName(className);
/* 157 */       return true;
/* 158 */     } catch (Throwable e) {
/* 159 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log makeNewLogInstance(String name) {
/*     */     Log log;
/*     */     NoOpLog noOpLog;
/*     */     try {
/* 184 */       Object[] args = { name };
/* 185 */       log = (Log)logImplctor.newInstance(args);
/* 186 */     } catch (Throwable t) {
/* 187 */       log = null;
/*     */     } 
/* 189 */     if (null == log) {
/* 190 */       noOpLog = new NoOpLog(name);
/*     */     }
/* 192 */     return (Log)noOpLog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLogImplementation(Class<?> logClass) throws LinkageError, ExceptionInInitializerError, NoSuchMethodException, SecurityException {
/* 209 */     logImplctor = logClass.getConstructor(new Class[] { String.class });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLogImplementation(String className) throws LinkageError, SecurityException {
/*     */     try {
/* 224 */       Class<?> logClass = Class.forName(className);
/* 225 */       logImplctor = logClass.getConstructor(new Class[] { String.class });
/* 226 */     } catch (Throwable t) {
/* 227 */       logImplctor = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\LogSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */