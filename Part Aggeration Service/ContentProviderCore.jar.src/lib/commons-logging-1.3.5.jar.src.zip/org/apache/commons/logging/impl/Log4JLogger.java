/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Log4JLogger
/*     */   implements Log, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5160705895411730424L;
/*  53 */   private static final String FQCN = Log4JLogger.class.getName();
/*     */   
/*     */   private static final Priority traceLevel;
/*     */   
/*     */   private volatile transient Logger logger;
/*     */   
/*     */   private final String name;
/*     */ 
/*     */   
/*     */   static {
/*     */     Level level;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/*  68 */     if (!Priority.class.isAssignableFrom(Level.class))
/*     */     {
/*  70 */       throw new InstantiationError("Log4J 1.2 not available");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  79 */       Priority _traceLevel = (Priority)Level.class.getDeclaredField("TRACE").get(null);
/*  80 */     } catch (Exception ex) {
/*     */       
/*  82 */       level = Level.DEBUG;
/*     */     } 
/*  84 */     traceLevel = (Priority)level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Log4JLogger() {
/*  97 */     this.name = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Log4JLogger(Logger logger) {
/* 106 */     if (logger == null) {
/* 107 */       throw new IllegalArgumentException("Warning - null logger in constructor; possible Log4j misconfiguration.");
/*     */     }
/*     */     
/* 110 */     this.name = logger.getName();
/* 111 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Log4JLogger(String name) {
/* 120 */     this.name = name;
/* 121 */     this.logger = getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(Object message) {
/* 132 */     getLogger().log(FQCN, (Priority)Level.DEBUG, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable t) {
/* 144 */     getLogger().log(FQCN, (Priority)Level.DEBUG, message, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/* 155 */     getLogger().log(FQCN, (Priority)Level.ERROR, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable t) {
/* 167 */     getLogger().log(FQCN, (Priority)Level.ERROR, message, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/* 178 */     getLogger().log(FQCN, (Priority)Level.FATAL, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable t) {
/* 190 */     getLogger().log(FQCN, (Priority)Level.FATAL, message, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 199 */     Logger result = this.logger;
/* 200 */     if (result == null) {
/* 201 */       synchronized (this) {
/* 202 */         result = this.logger;
/* 203 */         if (result == null) {
/* 204 */           this.logger = result = Logger.getLogger(this.name);
/*     */         }
/*     */       } 
/*     */     }
/* 208 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 219 */     getLogger().log(FQCN, (Priority)Level.INFO, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable t) {
/* 231 */     getLogger().log(FQCN, (Priority)Level.INFO, message, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 239 */     return getLogger().isDebugEnabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 247 */     return getLogger().isEnabledFor((Priority)Level.ERROR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/* 255 */     return getLogger().isEnabledFor((Priority)Level.FATAL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 263 */     return getLogger().isInfoEnabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 273 */     return getLogger().isEnabledFor(traceLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 281 */     return getLogger().isEnabledFor((Priority)Level.WARN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(Object message) {
/* 294 */     getLogger().log(FQCN, traceLevel, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(Object message, Throwable t) {
/* 308 */     getLogger().log(FQCN, traceLevel, message, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 319 */     getLogger().log(FQCN, (Priority)Level.WARN, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable t) {
/* 331 */     getLogger().log(FQCN, (Priority)Level.WARN, message, t);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\impl\Log4JLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */