/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletContextListener;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletContextCleaner
/*     */   implements ServletContextListener
/*     */ {
/*  51 */   private static final Class<?>[] RELEASE_SIGNATURE = new Class[] { ClassLoader.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void contextDestroyed(ServletContextEvent sce) {
/*  67 */     ClassLoader tccl = Thread.currentThread().getContextClassLoader();
/*     */     
/*  69 */     Object[] params = new Object[1];
/*  70 */     params[0] = tccl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     ClassLoader loader = tccl;
/* 103 */     while (loader != null) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 109 */         Class<LogFactory> logFactoryClass = (Class)loader.loadClass("org.apache.commons.logging.LogFactory");
/* 110 */         Method releaseMethod = logFactoryClass.getMethod("release", RELEASE_SIGNATURE);
/* 111 */         releaseMethod.invoke(null, params);
/* 112 */         loader = logFactoryClass.getClassLoader().getParent();
/* 113 */       } catch (ClassNotFoundException ex) {
/*     */ 
/*     */         
/* 116 */         loader = null;
/* 117 */       } catch (NoSuchMethodException ex) {
/*     */         
/* 119 */         System.err.println("LogFactory instance found which does not support release method!");
/* 120 */         loader = null;
/* 121 */       } catch (IllegalAccessException ex) {
/*     */         
/* 123 */         System.err.println("LogFactory instance found which is not accessible!");
/* 124 */         loader = null;
/* 125 */       } catch (InvocationTargetException ex) {
/*     */         
/* 127 */         System.err.println("LogFactory instance release method failed!");
/* 128 */         loader = null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     LogFactory.release(tccl);
/*     */   }
/*     */   
/*     */   public void contextInitialized(ServletContextEvent sce) {}
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\impl\ServletContextCleaner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */