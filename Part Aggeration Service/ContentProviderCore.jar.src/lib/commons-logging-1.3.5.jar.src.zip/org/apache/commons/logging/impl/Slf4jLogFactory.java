/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogConfigurationException;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.slf4j.ILoggerFactory;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.MarkerFactory;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Slf4jLogFactory
/*     */   extends LogFactory
/*     */ {
/*     */   private static final class Slf4jLocationAwareLog
/*     */     implements Log
/*     */   {
/*  47 */     private static final String FQCN = Slf4jLocationAwareLog.class.getName();
/*     */     
/*     */     private final LocationAwareLogger logger;
/*     */     
/*     */     public Slf4jLocationAwareLog(LocationAwareLogger logger) {
/*  52 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message) {
/*  57 */       log(10, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message, Throwable t) {
/*  62 */       log(10, message, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message) {
/*  67 */       log(40, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message, Throwable t) {
/*  72 */       log(40, message, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message) {
/*  77 */       error(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message, Throwable t) {
/*  82 */       error(message, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message) {
/*  87 */       log(20, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message, Throwable t) {
/*  92 */       log(20, message, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/*  97 */       return this.logger.isDebugEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 102 */       return this.logger.isErrorEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFatalEnabled() {
/* 107 */       return isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 112 */       return this.logger.isInfoEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 117 */       return this.logger.isTraceEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 122 */       return this.logger.isWarnEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */     
/*     */     private void log(int level, Object message, Throwable t) {
/* 126 */       this.logger.log(Slf4jLogFactory.MARKER, FQCN, level, String.valueOf(message), Slf4jLogFactory.EMPTY_OBJECT_ARRAY, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message) {
/* 131 */       log(0, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message, Throwable t) {
/* 136 */       log(0, message, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message) {
/* 141 */       log(30, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message, Throwable t) {
/* 146 */       log(30, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Slf4jLog implements Log {
/*     */     private final Logger logger;
/*     */     
/*     */     public Slf4jLog(Logger logger) {
/* 154 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message) {
/* 159 */       this.logger.debug(Slf4jLogFactory.MARKER, String.valueOf(message));
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message, Throwable t) {
/* 164 */       this.logger.debug(Slf4jLogFactory.MARKER, String.valueOf(message), t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message) {
/* 169 */       this.logger.error(Slf4jLogFactory.MARKER, String.valueOf(message));
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message, Throwable t) {
/* 174 */       this.logger.debug(Slf4jLogFactory.MARKER, String.valueOf(message), t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message) {
/* 179 */       error(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message, Throwable t) {
/* 184 */       error(message, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message) {
/* 189 */       this.logger.info(Slf4jLogFactory.MARKER, String.valueOf(message));
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message, Throwable t) {
/* 194 */       this.logger.info(Slf4jLogFactory.MARKER, String.valueOf(message), t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 199 */       return this.logger.isDebugEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 204 */       return this.logger.isErrorEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFatalEnabled() {
/* 209 */       return isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 214 */       return this.logger.isInfoEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 219 */       return this.logger.isTraceEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 224 */       return this.logger.isWarnEnabled(Slf4jLogFactory.MARKER);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message) {
/* 229 */       this.logger.trace(Slf4jLogFactory.MARKER, String.valueOf(message));
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message, Throwable t) {
/* 234 */       this.logger.trace(Slf4jLogFactory.MARKER, String.valueOf(message), t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message) {
/* 239 */       this.logger.warn(Slf4jLogFactory.MARKER, String.valueOf(message));
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message, Throwable t) {
/* 244 */       this.logger.warn(Slf4jLogFactory.MARKER, String.valueOf(message), t);
/*     */     }
/*     */   }
/*     */   
/* 248 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */   
/* 250 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   private static final Marker MARKER = MarkerFactory.getMarker("COMMONS-LOGGING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   private final ConcurrentMap<String, Log> loggers = new ConcurrentHashMap<>();
/*     */   
/* 267 */   private final ConcurrentMap<String, Object> attributes = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) {
/* 278 */     return this.attributes.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAttributeNames() {
/* 283 */     return (String[])this.attributes.keySet().toArray((Object[])EMPTY_STRING_ARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Log getInstance(Class<?> clazz) throws LogConfigurationException {
/* 288 */     return getInstance(clazz.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public Log getInstance(String name) {
/* 293 */     return this.loggers.computeIfAbsent(name, n -> {
/*     */           Logger logger = LoggerFactory.getLogger(n);
/*     */           return (logger instanceof LocationAwareLogger) ? new Slf4jLocationAwareLog((LocationAwareLogger)logger) : new Slf4jLog(logger);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 309 */     ILoggerFactory factory = LoggerFactory.getILoggerFactory();
/*     */     try {
/* 311 */       factory.getClass().getMethod("stop", new Class[0]).invoke(factory, new Object[0]);
/* 312 */     } catch (ReflectiveOperationException reflectiveOperationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 319 */     this.attributes.remove(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object value) {
/* 324 */     if (value != null) {
/* 325 */       this.attributes.put(name, value);
/*     */     } else {
/* 327 */       removeAttribute(name);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\impl\Slf4jLogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */