/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.security.AccessController;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogConfigurationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleLog
/*     */   implements Log, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 136942970684951178L;
/*     */   protected static final String systemPrefix = "org.apache.commons.logging.simplelog.";
/*  82 */   protected static final Properties simpleLogProps = new Properties();
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String DEFAULT_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/*     */ 
/*     */ 
/*     */   
/*     */   protected static volatile boolean showLogName;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static volatile boolean showShortName = true;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static volatile boolean showDateTime;
/*     */ 
/*     */   
/* 101 */   protected static volatile String dateTimeFormat = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/*     */ 
/*     */   
/*     */   protected static DateFormat dateFormatter;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_TRACE = 1;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_DEBUG = 2;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_INFO = 3;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_WARN = 4;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_ERROR = 5;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_FATAL = 6;
/*     */ 
/*     */   
/*     */   public static final int LOG_LEVEL_ALL = 0;
/*     */   
/*     */   public static final int LOG_LEVEL_OFF = 7;
/*     */   
/*     */   protected volatile String logName;
/*     */   
/*     */   protected volatile int currentLogLevel;
/*     */   
/*     */   private volatile String shortLogName;
/*     */ 
/*     */   
/*     */   static {
/*     */     
/* 138 */     try { InputStream in = getResourceAsStream("simplelog.properties"); 
/* 139 */       try { if (null != in) {
/* 140 */           simpleLogProps.load(in);
/*     */         }
/* 142 */         if (in != null) in.close();  } catch (Throwable throwable) { if (in != null) try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */     
/* 146 */     showLogName = getBooleanProperty("org.apache.commons.logging.simplelog.showlogname", showLogName);
/* 147 */     showShortName = getBooleanProperty("org.apache.commons.logging.simplelog.showShortLogname", showShortName);
/* 148 */     showDateTime = getBooleanProperty("org.apache.commons.logging.simplelog.showdatetime", showDateTime);
/*     */     
/* 150 */     if (showDateTime) {
/* 151 */       dateTimeFormat = getStringProperty("org.apache.commons.logging.simplelog.dateTimeFormat", dateTimeFormat);
/*     */       try {
/* 153 */         dateFormatter = new SimpleDateFormat(dateTimeFormat);
/* 154 */       } catch (IllegalArgumentException e) {
/*     */         
/* 156 */         dateTimeFormat = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/* 157 */         dateFormatter = new SimpleDateFormat(dateTimeFormat);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean getBooleanProperty(String name, boolean defaultValue) {
/* 163 */     String prop = getStringProperty(name);
/* 164 */     return (prop == null) ? defaultValue : Boolean.parseBoolean(prop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ClassLoader getContextClassLoader() {
/* 175 */     ClassLoader classLoader = null;
/*     */ 
/*     */     
/*     */     try {
/* 179 */       classLoader = Thread.currentThread().getContextClassLoader();
/* 180 */     } catch (RuntimeException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       if (!(e instanceof SecurityException)) {
/* 191 */         throw new LogConfigurationException("Unexpected SecurityException", e);
/*     */       }
/*     */     } 
/*     */     
/* 195 */     if (classLoader == null) {
/* 196 */       classLoader = SimpleLog.class.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/* 200 */     return classLoader;
/*     */   }
/*     */   
/*     */   private static InputStream getResourceAsStream(String name) {
/* 204 */     return AccessController.<InputStream>doPrivileged(() -> {
/*     */           ClassLoader threadCL = getContextClassLoader();
/*     */           return (threadCL != null) ? threadCL.getResourceAsStream(name) : ClassLoader.getSystemResourceAsStream(name);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getStringProperty(String name) {
/* 214 */     String prop = null;
/*     */     try {
/* 216 */       prop = System.getProperty(name);
/* 217 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */     
/* 220 */     return (prop == null) ? simpleLogProps.getProperty(name) : prop;
/*     */   }
/*     */   private static String getStringProperty(String name, String defaultValue) {
/* 223 */     String prop = getStringProperty(name);
/* 224 */     return (prop == null) ? defaultValue : prop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleLog(String name) {
/* 241 */     this.logName = name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     setLevel(3);
/*     */ 
/*     */     
/* 249 */     String level = getStringProperty("org.apache.commons.logging.simplelog.log." + this.logName);
/* 250 */     int i = String.valueOf(name).lastIndexOf(".");
/* 251 */     while (level == null && i > -1) {
/* 252 */       name = name.substring(0, i);
/* 253 */       level = getStringProperty("org.apache.commons.logging.simplelog.log." + name);
/* 254 */       i = String.valueOf(name).lastIndexOf(".");
/*     */     } 
/*     */     
/* 257 */     if (level == null) {
/* 258 */       level = getStringProperty("org.apache.commons.logging.simplelog.defaultlog");
/*     */     }
/* 260 */     if (level != null) {
/* 261 */       level = level.toLowerCase(Locale.ROOT);
/*     */     }
/* 263 */     if (level != null) {
/* 264 */       switch (level) {
/*     */         case "all":
/* 266 */           setLevel(0);
/*     */           break;
/*     */         case "trace":
/* 269 */           setLevel(1);
/*     */           break;
/*     */         case "debug":
/* 272 */           setLevel(2);
/*     */           break;
/*     */         case "info":
/* 275 */           setLevel(3);
/*     */           break;
/*     */         case "warn":
/* 278 */           setLevel(4);
/*     */           break;
/*     */         case "error":
/* 281 */           setLevel(5);
/*     */           break;
/*     */         case "fatal":
/* 284 */           setLevel(6);
/*     */           break;
/*     */         case "off":
/* 287 */           setLevel(7);
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void debug(Object message) {
/* 304 */     if (isLevelEnabled(2)) {
/* 305 */       log(2, message, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void debug(Object message, Throwable t) {
/* 319 */     if (isLevelEnabled(2)) {
/* 320 */       log(2, message, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void error(Object message) {
/* 332 */     if (isLevelEnabled(5)) {
/* 333 */       log(5, message, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void error(Object message, Throwable t) {
/* 346 */     if (isLevelEnabled(5)) {
/* 347 */       log(5, message, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void fatal(Object message) {
/* 359 */     if (isLevelEnabled(6)) {
/* 360 */       log(6, message, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void fatal(Object message, Throwable t) {
/* 373 */     if (isLevelEnabled(6)) {
/* 374 */       log(6, message, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLevel() {
/* 384 */     return this.currentLogLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void info(Object message) {
/* 395 */     if (isLevelEnabled(3)) {
/* 396 */       log(3, message, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void info(Object message, Throwable t) {
/* 409 */     if (isLevelEnabled(3)) {
/* 410 */       log(3, message, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDebugEnabled() {
/* 424 */     return isLevelEnabled(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isErrorEnabled() {
/* 437 */     return isLevelEnabled(5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isFatalEnabled() {
/* 450 */     return isLevelEnabled(6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInfoEnabled() {
/* 463 */     return isLevelEnabled(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isLevelEnabled(int logLevel) {
/* 475 */     return (logLevel >= this.currentLogLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTraceEnabled() {
/* 488 */     return isLevelEnabled(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWarnEnabled() {
/* 501 */     return isLevelEnabled(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void log(int type, Object message, Throwable t) {
/* 517 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*     */     
/* 520 */     if (showDateTime) {
/* 521 */       String dateText; Date now = new Date();
/*     */       
/* 523 */       synchronized (dateFormatter) {
/* 524 */         dateText = dateFormatter.format(now);
/*     */       } 
/* 526 */       buf.append(dateText);
/* 527 */       buf.append(" ");
/*     */     } 
/*     */ 
/*     */     
/* 531 */     switch (type) {
/*     */       case 1:
/* 533 */         buf.append("[TRACE] ");
/*     */         break;
/*     */       case 2:
/* 536 */         buf.append("[DEBUG] ");
/*     */         break;
/*     */       case 3:
/* 539 */         buf.append("[INFO] ");
/*     */         break;
/*     */       case 4:
/* 542 */         buf.append("[WARN] ");
/*     */         break;
/*     */       case 5:
/* 545 */         buf.append("[ERROR] ");
/*     */         break;
/*     */       case 6:
/* 548 */         buf.append("[FATAL] ");
/*     */         break;
/*     */       
/*     */       default:
/* 552 */         buf.append("[UNDEFINED] ");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 557 */     if (showShortName) {
/* 558 */       if (this.shortLogName == null) {
/*     */         
/* 560 */         String slName = this.logName.substring(this.logName.lastIndexOf(".") + 1);
/* 561 */         this.shortLogName = slName.substring(slName.lastIndexOf("/") + 1);
/*     */       } 
/* 563 */       buf.append(String.valueOf(this.shortLogName)).append(" - ");
/* 564 */     } else if (showLogName) {
/* 565 */       buf.append(String.valueOf(this.logName)).append(" - ");
/*     */     } 
/*     */ 
/*     */     
/* 569 */     buf.append(String.valueOf(message));
/*     */ 
/*     */     
/* 572 */     if (t != null) {
/* 573 */       buf.append(" <");
/* 574 */       buf.append(t.toString());
/* 575 */       buf.append(">");
/*     */       
/* 577 */       StringWriter sw = new StringWriter(1024);
/* 578 */       PrintWriter pw = new PrintWriter(sw); 
/* 579 */       try { t.printStackTrace(pw);
/* 580 */         pw.close(); } catch (Throwable throwable) { try { pw.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 581 */        buf.append(sw.toString());
/*     */     } 
/*     */ 
/*     */     
/* 585 */     write(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevel(int currentLogLevel) {
/* 594 */     this.currentLogLevel = currentLogLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void trace(Object message) {
/* 605 */     if (isLevelEnabled(1)) {
/* 606 */       log(1, message, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void trace(Object message, Throwable t) {
/* 619 */     if (isLevelEnabled(1)) {
/* 620 */       log(1, message, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void warn(Object message) {
/* 632 */     if (isLevelEnabled(4)) {
/* 633 */       log(4, message, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void warn(Object message, Throwable t) {
/* 646 */     if (isLevelEnabled(4)) {
/* 647 */       log(4, message, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void write(Object buffer) {
/* 660 */     System.err.println(Objects.toString(buffer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void write(StringBuffer buffer) {
/* 672 */     System.err.println(Objects.toString(buffer));
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\impl\SimpleLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */