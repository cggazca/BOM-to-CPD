/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Jdk13LumberjackLogger
/*     */   implements Log, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8649807923527610591L;
/*     */   @Deprecated
/*  53 */   protected static final Level dummyLevel = Level.FINE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient Logger logger;
/*     */ 
/*     */ 
/*     */   
/*     */   protected String name;
/*     */ 
/*     */ 
/*     */   
/*  66 */   private String sourceClassName = "unknown";
/*     */ 
/*     */   
/*  69 */   private String sourceMethodName = "unknown";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean classAndMethodFound;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jdk13LumberjackLogger(String name) {
/*  80 */     this.name = name;
/*  81 */     this.logger = getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(Object message) {
/*  92 */     log(Level.FINE, String.valueOf(message), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable exception) {
/* 104 */     log(Level.FINE, String.valueOf(message), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/* 115 */     log(Level.SEVERE, String.valueOf(message), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable exception) {
/* 127 */     log(Level.SEVERE, String.valueOf(message), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/* 138 */     log(Level.SEVERE, String.valueOf(message), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable exception) {
/* 150 */     log(Level.SEVERE, String.valueOf(message), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getClassAndMethod() {
/*     */     try {
/* 159 */       Throwable throwable = new Throwable();
/* 160 */       throwable.fillInStackTrace();
/* 161 */       StringWriter stringWriter = new StringWriter();
/* 162 */       PrintWriter printWriter = new PrintWriter(stringWriter);
/* 163 */       throwable.printStackTrace(printWriter);
/* 164 */       String traceString = stringWriter.toString();
/* 165 */       StringTokenizer tokenizer = new StringTokenizer(traceString, "\n");
/* 166 */       tokenizer.nextToken();
/* 167 */       String line = tokenizer.nextToken();
/* 168 */       while (!line.contains(getClass().getName())) {
/* 169 */         line = tokenizer.nextToken();
/*     */       }
/* 171 */       while (line.contains(getClass().getName())) {
/* 172 */         line = tokenizer.nextToken();
/*     */       }
/* 174 */       int start = line.indexOf("at ") + 3;
/* 175 */       int end = line.indexOf('(');
/* 176 */       String temp = line.substring(start, end);
/* 177 */       int lastPeriod = temp.lastIndexOf('.');
/* 178 */       this.sourceClassName = temp.substring(0, lastPeriod);
/* 179 */       this.sourceMethodName = temp.substring(lastPeriod + 1);
/* 180 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 183 */     this.classAndMethodFound = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 192 */     if (this.logger == null) {
/* 193 */       this.logger = Logger.getLogger(this.name);
/*     */     }
/* 195 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 206 */     log(Level.INFO, String.valueOf(message), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable exception) {
/* 218 */     log(Level.INFO, String.valueOf(message), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 226 */     return getLogger().isLoggable(Level.FINE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 234 */     return getLogger().isLoggable(Level.SEVERE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/* 242 */     return getLogger().isLoggable(Level.SEVERE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 250 */     return getLogger().isLoggable(Level.INFO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 258 */     return getLogger().isLoggable(Level.FINEST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 266 */     return getLogger().isLoggable(Level.WARNING);
/*     */   }
/*     */   
/*     */   private void log(Level level, String msg, Throwable ex) {
/* 270 */     if (getLogger().isLoggable(level)) {
/* 271 */       LogRecord record = new LogRecord(level, msg);
/* 272 */       if (!this.classAndMethodFound) {
/* 273 */         getClassAndMethod();
/*     */       }
/* 275 */       record.setSourceClassName(this.sourceClassName);
/* 276 */       record.setSourceMethodName(this.sourceMethodName);
/* 277 */       if (ex != null) {
/* 278 */         record.setThrown(ex);
/*     */       }
/* 280 */       getLogger().log(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(Object message) {
/* 292 */     log(Level.FINEST, String.valueOf(message), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(Object message, Throwable exception) {
/* 304 */     log(Level.FINEST, String.valueOf(message), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 315 */     log(Level.WARNING, String.valueOf(message), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable exception) {
/* 327 */     log(Level.WARNING, String.valueOf(message), exception);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\impl\Jdk13LumberjackLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */