/*      */ package org.apache.commons.logging;
/*      */ 
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.AccessController;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Objects;
/*      */ import java.util.Properties;
/*      */ import java.util.ServiceConfigurationError;
/*      */ import java.util.ServiceLoader;
/*      */ import java.util.function.Supplier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class LogFactory
/*      */ {
/*      */   public static final String PRIORITY_KEY = "priority";
/*      */   public static final String TCCL_KEY = "use_tccl";
/*      */   public static final String FACTORY_PROPERTY = "org.apache.commons.logging.LogFactory";
/*      */   private static final String FACTORY_LOG4J_API = "org.apache.commons.logging.impl.Log4jApiLogFactory";
/*      */   private static final String LOG4J_TO_SLF4J_BRIDGE = "org.apache.logging.slf4j.SLF4JProvider";
/*      */   private static final String FACTORY_SLF4J = "org.apache.commons.logging.impl.Slf4jLogFactory";
/*      */   public static final String FACTORY_DEFAULT = "org.apache.commons.logging.impl.LogFactoryImpl";
/*      */   public static final String FACTORY_PROPERTIES = "commons-logging.properties";
/*      */   protected static final String SERVICE_ID = "META-INF/services/org.apache.commons.logging.LogFactory";
/*      */   public static final String DIAGNOSTICS_DEST_PROPERTY = "org.apache.commons.logging.diagnostics.dest";
/*      */   private static final PrintStream DIAGNOSTICS_STREAM;
/*      */   private static final String DIAGNOSTICS_PREFIX;
/*      */   public static final String HASHTABLE_IMPLEMENTATION_PROPERTY = "org.apache.commons.logging.LogFactory.HashtableImpl";
/*      */   private static final String WEAK_HASHTABLE_CLASSNAME = "org.apache.commons.logging.impl.WeakHashtable";
/*      */   private static final WeakReference<ClassLoader> thisClassLoaderRef;
/*      */   private static final int MAX_BROKEN_SERVICES = 3;
/*      */   protected static Hashtable<ClassLoader, LogFactory> factories;
/*      */   @Deprecated
/*      */   protected static volatile LogFactory nullClassLoaderFactory;
/*      */   
/*      */   static {
/*      */     String classLoaderName;
/*  237 */     ClassLoader thisClassLoader = getClassLoader(LogFactory.class);
/*  238 */     thisClassLoaderRef = new WeakReference<>(thisClassLoader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  250 */       classLoaderName = (thisClassLoader != null) ? objectId(thisClassLoader) : "BOOTLOADER";
/*  251 */     } catch (SecurityException e) {
/*  252 */       classLoaderName = "UNKNOWN";
/*      */     } 
/*  254 */     DIAGNOSTICS_PREFIX = "[LogFactory from " + classLoaderName + "] ";
/*  255 */     DIAGNOSTICS_STREAM = initDiagnostics();
/*  256 */     logClassLoaderEnvironment(LogFactory.class);
/*  257 */     factories = createFactoryStore();
/*  258 */     logDiagnostic("BOOTSTRAP COMPLETED");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void cacheFactory(ClassLoader classLoader, LogFactory factory) {
/*  273 */     if (factory != null) {
/*  274 */       if (classLoader == null) {
/*  275 */         nullClassLoaderFactory = factory;
/*      */       } else {
/*  277 */         factories.put(classLoader, factory);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Object createFactory(String factoryClassName, ClassLoader classLoader) {
/*  294 */     Class<?> logFactoryClass = null;
/*      */     try {
/*  296 */       if (classLoader != null) {
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */           
/*  302 */           logFactoryClass = classLoader.loadClass(factoryClassName);
/*  303 */           if (LogFactory.class.isAssignableFrom(logFactoryClass)) {
/*  304 */             if (isDiagnosticsEnabled()) {
/*  305 */               logDiagnostic("Loaded class " + logFactoryClass.getName() + " from class loader " + objectId(classLoader));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  318 */           else if (isDiagnosticsEnabled()) {
/*  319 */             logDiagnostic("Factory class " + logFactoryClass.getName() + " loaded from class loader " + objectId(logFactoryClass.getClassLoader()) + " does not extend '" + LogFactory.class
/*  320 */                 .getName() + "' as loaded by this class loader.");
/*  321 */             logHierarchy("[BAD CL TREE] ", classLoader);
/*      */           } 
/*      */           
/*  324 */           return LogFactory.class.cast(logFactoryClass.getConstructor(new Class[0]).newInstance(new Object[0]));
/*      */         }
/*  326 */         catch (ClassNotFoundException ex) {
/*  327 */           if (classLoader == thisClassLoaderRef.get())
/*      */           {
/*  329 */             if (isDiagnosticsEnabled()) {
/*  330 */               logDiagnostic("Unable to locate any class called '" + factoryClassName + "' via class loader " + objectId(classLoader));
/*      */             }
/*  332 */             throw ex;
/*      */           }
/*      */         
/*  335 */         } catch (NoClassDefFoundError e) {
/*  336 */           if (classLoader == thisClassLoaderRef.get())
/*      */           {
/*  338 */             if (isDiagnosticsEnabled()) {
/*  339 */               logDiagnostic("Class '" + factoryClassName + "' cannot be loaded via class loader " + objectId(classLoader) + " - it depends on some other class that cannot be found.");
/*      */             }
/*      */             
/*  342 */             throw e;
/*      */           }
/*      */         
/*  345 */         } catch (ClassCastException e) {
/*  346 */           if (classLoader == thisClassLoaderRef.get()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  351 */             boolean implementsLogFactory = implementsLogFactory(logFactoryClass);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  357 */             StringBuilder msg = new StringBuilder();
/*  358 */             msg.append("The application has specified that a custom LogFactory implementation should be used but Class '");
/*  359 */             msg.append(factoryClassName);
/*  360 */             msg.append("' cannot be converted to '");
/*  361 */             msg.append(LogFactory.class.getName());
/*  362 */             msg.append("'. ");
/*  363 */             if (implementsLogFactory) {
/*  364 */               msg.append("The conflict is caused by the presence of multiple LogFactory classes in incompatible class loaders. Background can");
/*  365 */               msg.append(" be found in https://commons.apache.org/logging/tech.html. If you have not explicitly specified a custom LogFactory");
/*  366 */               msg.append(" then it is likely that the container has set one without your knowledge. In this case, consider using the ");
/*  367 */               msg.append("commons-logging-adapters.jar file or specifying the standard LogFactory from the command line. ");
/*      */             } else {
/*  369 */               msg.append("Please check the custom implementation. ");
/*      */             } 
/*  371 */             msg.append("Help can be found at https://commons.apache.org/logging/troubleshooting.html.");
/*  372 */             logDiagnostic(msg.toString());
/*  373 */             throw new ClassCastException(msg.toString());
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  401 */       if (isDiagnosticsEnabled()) {
/*  402 */         logDiagnostic("Unable to load factory class via class loader " + 
/*  403 */             objectId(classLoader) + " - trying the class loader associated with this LogFactory.");
/*      */       }
/*  405 */       logFactoryClass = Class.forName(factoryClassName);
/*      */       
/*  407 */       return LogFactory.class.cast(logFactoryClass.getConstructor(new Class[0]).newInstance(new Object[0]));
/*  408 */     } catch (Exception e) {
/*      */       
/*  410 */       if (isDiagnosticsEnabled()) {
/*  411 */         logDiagnostic("Unable to create LogFactory instance.");
/*      */       }
/*  413 */       if (logFactoryClass != null && !LogFactory.class.isAssignableFrom(logFactoryClass)) {
/*  414 */         return new LogConfigurationException("The chosen LogFactory implementation does not extend LogFactory. Please check your configuration.", e);
/*      */       }
/*  416 */       return new LogConfigurationException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Hashtable<ClassLoader, LogFactory> createFactoryStore() {
/*      */     String storeImplementationClass;
/*  437 */     Hashtable<ClassLoader, LogFactory> result = null;
/*      */     
/*      */     try {
/*  440 */       storeImplementationClass = getSystemProperty("org.apache.commons.logging.LogFactory.HashtableImpl", null);
/*  441 */     } catch (SecurityException ex) {
/*      */ 
/*      */       
/*  444 */       storeImplementationClass = null;
/*      */     } 
/*  446 */     if (storeImplementationClass == null) {
/*  447 */       storeImplementationClass = "org.apache.commons.logging.impl.WeakHashtable";
/*      */     }
/*      */     
/*      */     try {
/*  451 */       Class<Hashtable<ClassLoader, LogFactory>> implementationClass = (Class)Class.forName(storeImplementationClass);
/*  452 */       result = implementationClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  453 */     } catch (Throwable t) {
/*  454 */       handleThrowable(t);
/*      */       
/*  456 */       if (!"org.apache.commons.logging.impl.WeakHashtable".equals(storeImplementationClass))
/*      */       {
/*  458 */         if (isDiagnosticsEnabled()) {
/*      */           
/*  460 */           logDiagnostic("[ERROR] LogFactory: Load of custom Hashtable failed");
/*      */         }
/*      */         else {
/*      */           
/*  464 */           System.err.println("[ERROR] LogFactory: Load of custom Hashtable failed");
/*      */         } 
/*      */       }
/*      */     } 
/*  468 */     if (result == null) {
/*  469 */       result = new Hashtable<>();
/*      */     }
/*  471 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClassLoader directGetContextClassLoader() throws LogConfigurationException {
/*  498 */     ClassLoader classLoader = null;
/*      */     try {
/*  500 */       classLoader = Thread.currentThread().getContextClassLoader();
/*  501 */     } catch (SecurityException securityException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  511 */     return classLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static LogFactory getCachedFactory(ClassLoader contextClassLoader) {
/*  529 */     if (contextClassLoader == null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  534 */       return nullClassLoaderFactory;
/*      */     }
/*  536 */     return factories.get(contextClassLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClassLoader getClassLoader(Class<?> clazz) {
/*      */     try {
/*  573 */       return clazz.getClassLoader();
/*  574 */     } catch (SecurityException ex) {
/*  575 */       logDiagnostic(() -> "Unable to get class loader for class '" + clazz + "' due to security restrictions - " + ex.getMessage());
/*  576 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Properties getConfigurationFile(ClassLoader classLoader, String fileName) {
/*  603 */     Properties props = null;
/*  604 */     double priority = 0.0D;
/*  605 */     URL propsUrl = null;
/*      */     try {
/*  607 */       Enumeration<URL> urls = getResources(classLoader, fileName);
/*  608 */       if (urls == null) {
/*  609 */         return null;
/*      */       }
/*  611 */       while (urls.hasMoreElements()) {
/*  612 */         URL url = urls.nextElement();
/*  613 */         Properties newProps = getProperties(url);
/*  614 */         if (newProps != null) {
/*  615 */           if (props == null) {
/*  616 */             propsUrl = url;
/*  617 */             props = newProps;
/*  618 */             String priorityStr = props.getProperty("priority");
/*  619 */             priority = 0.0D;
/*  620 */             if (priorityStr != null) {
/*  621 */               priority = Double.parseDouble(priorityStr);
/*      */             }
/*  623 */             if (isDiagnosticsEnabled())
/*  624 */               logDiagnostic("[LOOKUP] Properties file found at '" + url + "' with priority " + priority); 
/*      */             continue;
/*      */           } 
/*  627 */           String newPriorityStr = newProps.getProperty("priority");
/*  628 */           double newPriority = 0.0D;
/*  629 */           if (newPriorityStr != null) {
/*  630 */             newPriority = Double.parseDouble(newPriorityStr);
/*      */           }
/*  632 */           if (newPriority > priority) {
/*  633 */             if (isDiagnosticsEnabled()) {
/*  634 */               logDiagnostic("[LOOKUP] Properties file at '" + url + "' with priority " + newPriority + " overrides file at '" + propsUrl + "' with priority " + priority);
/*      */             }
/*      */             
/*  637 */             propsUrl = url;
/*  638 */             props = newProps;
/*  639 */             priority = newPriority; continue;
/*  640 */           }  if (isDiagnosticsEnabled()) {
/*  641 */             logDiagnostic("[LOOKUP] Properties file at '" + url + "' with priority " + newPriority + " does not override file at '" + propsUrl + "' with priority " + priority);
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  648 */     catch (SecurityException e) {
/*  649 */       logDiagnostic("SecurityException thrown while trying to find/read config files.");
/*      */     } 
/*  651 */     if (isDiagnosticsEnabled()) {
/*  652 */       if (props == null) {
/*  653 */         logDiagnostic("[LOOKUP] No properties file of name '" + fileName + "' found.");
/*      */       } else {
/*  655 */         logDiagnostic("[LOOKUP] Properties file of name '" + fileName + "' found at '" + propsUrl + '"');
/*      */       } 
/*      */     }
/*  658 */     return props;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClassLoader getContextClassLoader() throws LogConfigurationException {
/*  681 */     return directGetContextClassLoader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ClassLoader getContextClassLoaderInternal() throws LogConfigurationException {
/*  699 */     return AccessController.<ClassLoader>doPrivileged(LogFactory::directGetContextClassLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LogFactory getFactory() throws LogConfigurationException {
/*      */     int i;
/*  726 */     ClassLoader contextClassLoader = getContextClassLoaderInternal();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  731 */     if (contextClassLoader == null) {
/*  732 */       logDiagnostic("Context class loader is null.");
/*      */     }
/*      */ 
/*      */     
/*  736 */     LogFactory factory = getCachedFactory(contextClassLoader);
/*  737 */     if (factory != null) {
/*  738 */       return factory;
/*      */     }
/*      */     
/*  741 */     if (isDiagnosticsEnabled()) {
/*  742 */       logDiagnostic("[LOOKUP] LogFactory implementation requested for the first time for context class loader " + 
/*      */           
/*  744 */           objectId(contextClassLoader));
/*  745 */       logHierarchy("[LOOKUP] ", contextClassLoader);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  758 */     Properties props = getConfigurationFile(contextClassLoader, "commons-logging.properties");
/*      */ 
/*      */ 
/*      */     
/*  762 */     boolean useTccl = (contextClassLoader != null);
/*  763 */     if (props != null) {
/*  764 */       String useTCCLStr = props.getProperty("use_tccl");
/*  765 */       i = useTccl & ((useTCCLStr == null || Boolean.parseBoolean(useTCCLStr)) ? 1 : 0);
/*      */     } 
/*      */     
/*  768 */     if (i != 0) {
/*      */       try {
/*  770 */         if (!LogFactory.class.equals(Class.forName(LogFactory.class.getName(), false, contextClassLoader))) {
/*  771 */           logDiagnostic(() -> "The class " + LogFactory.class.getName() + " loaded by the context class loader " + objectId(contextClassLoader) + " and this class differ. Disabling the usage of the context class loader.Background can be found in https://commons.apache.org/logging/tech.html. ");
/*      */ 
/*      */           
/*  774 */           logHierarchy("[BAD CL TREE] ", contextClassLoader);
/*  775 */           i = 0;
/*      */         } 
/*  777 */       } catch (ClassNotFoundException ignored) {
/*  778 */         logDiagnostic(() -> "The class " + LogFactory.class.getName() + " is not present in the the context class loader " + objectId(contextClassLoader) + ". Disabling the usage of the context class loader.Background can be found in https://commons.apache.org/logging/tech.html. ");
/*      */ 
/*      */         
/*  781 */         logHierarchy("[BAD CL TREE] ", contextClassLoader);
/*  782 */         i = 0;
/*      */       } 
/*      */     }
/*  785 */     ClassLoader baseClassLoader = (i != 0) ? contextClassLoader : thisClassLoaderRef.get();
/*      */ 
/*      */ 
/*      */     
/*  789 */     logDiagnostic(() -> "[LOOKUP] Looking for system property [org.apache.commons.logging.LogFactory] to define the LogFactory subclass to use...");
/*      */ 
/*      */     
/*      */     try {
/*  793 */       String factoryClass = getSystemProperty("org.apache.commons.logging.LogFactory", null);
/*  794 */       if (factoryClass != null) {
/*  795 */         logDiagnostic(() -> "[LOOKUP] Creating an instance of LogFactory class '" + factoryClass + "' as specified by system property " + "org.apache.commons.logging.LogFactory");
/*      */         
/*  797 */         factory = newFactory(factoryClass, baseClassLoader, contextClassLoader);
/*      */       } else {
/*  799 */         logDiagnostic(() -> "[LOOKUP] No system property [org.apache.commons.logging.LogFactory] defined.");
/*      */       } 
/*  801 */     } catch (SecurityException e) {
/*  802 */       logDiagnostic(() -> "[LOOKUP] A security exception occurred while trying to create an instance of the custom factory class: [" + trim(e.getMessage()) + "]. Trying alternative implementations...");
/*      */     
/*      */     }
/*  805 */     catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  811 */       logDiagnostic(() -> "[LOOKUP] An exception occurred while trying to create an instance of the custom factory class: [" + trim(e.getMessage()) + "] as specified by a system property.");
/*      */       
/*  813 */       throw e;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  821 */     if (factory == null) {
/*  822 */       logDiagnostic("[LOOKUP] Using ServiceLoader  to define the LogFactory subclass to use...");
/*      */       try {
/*  824 */         ServiceLoader<LogFactory> serviceLoader = ServiceLoader.load(LogFactory.class, baseClassLoader);
/*  825 */         Iterator<LogFactory> iterator = serviceLoader.iterator();
/*      */         
/*  827 */         int j = 3;
/*  828 */         while (factory == null && j-- > 0) {
/*      */           try {
/*  830 */             if (iterator.hasNext()) {
/*  831 */               factory = iterator.next();
/*      */             }
/*  833 */           } catch (ServiceConfigurationError|LinkageError ex) {
/*  834 */             logDiagnostic(() -> "[LOOKUP] An exception occurred while trying to find an instance of LogFactory: [" + trim(ex.getMessage()) + "]. Trying alternative implementations...");
/*      */           }
/*      */         
/*      */         } 
/*  838 */       } catch (Exception ex) {
/*      */ 
/*      */ 
/*      */         
/*  842 */         logDiagnostic(() -> "[LOOKUP] A security exception occurred while trying to create an instance of the custom factory class: [" + trim(ex.getMessage()) + "]. Trying alternative implementations...");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  849 */     if (factory == null) {
/*  850 */       if (props != null) {
/*  851 */         logDiagnostic(() -> "[LOOKUP] Looking in properties file for entry with key 'org.apache.commons.logging.LogFactory' to define the LogFactory subclass to use...");
/*      */ 
/*      */         
/*  854 */         String factoryClass = props.getProperty("org.apache.commons.logging.LogFactory");
/*  855 */         if (factoryClass != null) {
/*  856 */           logDiagnostic(() -> "[LOOKUP] Properties file specifies LogFactory subclass '" + factoryClass + "'");
/*      */           
/*  858 */           factory = newFactory(factoryClass, baseClassLoader, contextClassLoader);
/*      */         } else {
/*      */           
/*  861 */           logDiagnostic("[LOOKUP] Properties file has no entry specifying LogFactory subclass.");
/*      */         } 
/*      */       } else {
/*  864 */         logDiagnostic("[LOOKUP] No properties file available to determine LogFactory subclass from..");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  870 */     if (factory == null) {
/*  871 */       factory = newStandardFactory(baseClassLoader);
/*      */     }
/*  873 */     if (factory == null && baseClassLoader != thisClassLoaderRef.get()) {
/*  874 */       factory = newStandardFactory(thisClassLoaderRef.get());
/*      */     }
/*  876 */     if (factory != null) {
/*  877 */       if (isDiagnosticsEnabled()) {
/*  878 */         logDiagnostic("Created object " + objectId(factory) + " to manage class loader " + objectId(contextClassLoader));
/*      */       }
/*      */     } else {
/*  881 */       logDiagnostic(() -> "[LOOKUP] Loading the default LogFactory implementation 'org.apache.commons.logging.impl.LogFactoryImpl' via the same class loader that loaded this LogFactory class (ie not looking in the context class loader).");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  893 */       factory = newFactory("org.apache.commons.logging.impl.LogFactoryImpl", thisClassLoaderRef.get(), contextClassLoader);
/*      */     } 
/*  895 */     if (factory != null) {
/*      */ 
/*      */ 
/*      */       
/*  899 */       cacheFactory(contextClassLoader, factory);
/*  900 */       if (props != null) {
/*  901 */         Enumeration<?> names = props.propertyNames();
/*  902 */         while (names.hasMoreElements()) {
/*  903 */           String name = Objects.toString(names.nextElement(), null);
/*  904 */           String value = props.getProperty(name);
/*  905 */           factory.setAttribute(name, value);
/*      */         } 
/*      */       } 
/*      */     } 
/*  909 */     return factory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Log getLog(Class<?> clazz) throws LogConfigurationException {
/*  920 */     return getFactory().getInstance(clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Log getLog(String name) throws LogConfigurationException {
/*  932 */     return getFactory().getInstance(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Properties getProperties(URL url) {
/*  945 */     return AccessController.<Properties>doPrivileged(() -> { try { URLConnection connection = url.openConnection(); connection.setUseCaches(false); try {
/*      */               InputStream stream = connection.getInputStream(); 
/*      */               try { if (stream != null) {
/*      */                   Properties props = new Properties(); props.load(stream); Properties properties1 = props; if (stream != null)
/*      */                     stream.close();  return properties1;
/*      */                 }  if (stream != null)
/*      */                   stream.close();  }
/*  952 */               catch (Throwable throwable) { if (stream != null) try { stream.close(); } catch (Throwable throwable1)
/*      */                   { throwable.addSuppressed(throwable1); }
/*      */                 
/*      */                 
/*      */                 throw throwable; }
/*      */             
/*  958 */             } catch (IOException e) {
/*      */               logDiagnostic(());
/*      */             }  }
/*  961 */           catch (IOException e)
/*      */           { logDiagnostic(()); }
/*      */           
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Enumeration<URL> getResources(ClassLoader loader, String name) {
/*  985 */     return AccessController.<Enumeration<URL>>doPrivileged(() -> {
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*      */             return (loader != null) ? loader.getResources(name) : ClassLoader.getSystemResources(name);
/*  991 */           } catch (IOException e) {
/*      */             logDiagnostic(());
/*      */             return null;
/*  994 */           } catch (NoSuchMethodError e) {
/*      */             return null;
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getSystemProperty(String key, String def) throws SecurityException {
/* 1015 */     return AccessController.<String>doPrivileged(() -> System.getProperty(key, def));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void handleThrowable(Throwable t) {
/* 1031 */     if (t instanceof ThreadDeath) {
/* 1032 */       throw (ThreadDeath)t;
/*      */     }
/* 1034 */     if (t instanceof VirtualMachineError) {
/* 1035 */       throw (VirtualMachineError)t;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean implementsLogFactory(Class<?> logFactoryClass) {
/* 1054 */     boolean implementsLogFactory = false;
/* 1055 */     if (logFactoryClass != null) {
/*      */       try {
/* 1057 */         ClassLoader logFactoryClassLoader = logFactoryClass.getClassLoader();
/* 1058 */         if (logFactoryClassLoader == null) {
/* 1059 */           logDiagnostic("[CUSTOM LOG FACTORY] was loaded by the boot class loader");
/*      */         } else {
/* 1061 */           logHierarchy("[CUSTOM LOG FACTORY] ", logFactoryClassLoader);
/* 1062 */           Class<?> factoryFromCustomLoader = Class.forName("org.apache.commons.logging.LogFactory", false, logFactoryClassLoader);
/* 1063 */           implementsLogFactory = factoryFromCustomLoader.isAssignableFrom(logFactoryClass);
/* 1064 */           String logFactoryClassName = logFactoryClass.getName();
/* 1065 */           if (implementsLogFactory) {
/* 1066 */             logDiagnostic(() -> "[CUSTOM LOG FACTORY] " + logFactoryClassName + " implements LogFactory but was loaded by an incompatible class loader.");
/*      */           } else {
/* 1068 */             logDiagnostic(() -> "[CUSTOM LOG FACTORY] " + logFactoryClassName + " does not implement LogFactory.");
/*      */           } 
/*      */         } 
/* 1071 */       } catch (SecurityException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1077 */         logDiagnostic(() -> "[CUSTOM LOG FACTORY] SecurityException caught trying to determine whether the compatibility was caused by a class loader conflict: " + e.getMessage());
/*      */       
/*      */       }
/* 1080 */       catch (LinkageError e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1087 */         logDiagnostic(() -> "[CUSTOM LOG FACTORY] LinkageError caught trying to determine whether the compatibility was caused by a class loader conflict: " + e.getMessage());
/*      */       
/*      */       }
/* 1090 */       catch (ClassNotFoundException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1098 */         logDiagnostic(() -> "[CUSTOM LOG FACTORY] LogFactory class cannot be loaded by the class loader which loaded the custom LogFactory implementation. Is the custom factory in the right class loader?");
/*      */       } 
/*      */     }
/*      */     
/* 1102 */     return implementsLogFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static PrintStream initDiagnostics() {
/*      */     String dest;
/*      */     try {
/* 1114 */       dest = getSystemProperty("org.apache.commons.logging.diagnostics.dest", null);
/* 1115 */       if (dest == null) {
/* 1116 */         return null;
/*      */       }
/* 1118 */     } catch (SecurityException ex) {
/*      */ 
/*      */       
/* 1121 */       return null;
/*      */     } 
/*      */     
/* 1124 */     if (dest.equals("STDOUT")) {
/* 1125 */       return System.out;
/*      */     }
/* 1127 */     if (dest.equals("STDERR")) {
/* 1128 */       return System.err;
/*      */     }
/*      */     
/*      */     try {
/* 1132 */       FileOutputStream fos = new FileOutputStream(dest, true);
/* 1133 */       return new PrintStream(fos, false, StandardCharsets.UTF_8.name());
/* 1134 */     } catch (IOException ex) {
/*      */       
/* 1136 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean isClassAvailable(String className, ClassLoader classLoader) {
/* 1141 */     logDiagnostic(() -> "Checking if class '" + className + "' is available in class loader " + objectId(classLoader));
/*      */     try {
/* 1143 */       Class.forName(className, true, classLoader);
/* 1144 */       return true;
/* 1145 */     } catch (ClassNotFoundException|LinkageError e) {
/* 1146 */       logDiagnostic(() -> "Failed to load class '" + className + "' from class loader " + objectId(classLoader) + ": " + e.getMessage());
/*      */       
/* 1148 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isDiagnosticsEnabled() {
/* 1162 */     return (DIAGNOSTICS_STREAM != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void logClassLoaderEnvironment(Class<?> clazz) {
/*      */     ClassLoader classLoader;
/* 1185 */     if (!isDiagnosticsEnabled()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1192 */       logDiagnostic("[ENV] Extension directories (java.ext.dir): " + System.getProperty("java.ext.dir"));
/* 1193 */       logDiagnostic("[ENV] Application classpath (java.class.path): " + System.getProperty("java.class.path"));
/* 1194 */     } catch (SecurityException ex) {
/* 1195 */       logDiagnostic("[ENV] Security setting prevent interrogation of system classpaths.");
/*      */     } 
/* 1197 */     String className = clazz.getName();
/*      */     
/*      */     try {
/* 1200 */       classLoader = getClassLoader(clazz);
/* 1201 */     } catch (SecurityException ex) {
/*      */       
/* 1203 */       logDiagnostic("[ENV] Security forbids determining the class loader for " + className);
/*      */       return;
/*      */     } 
/* 1206 */     logDiagnostic("[ENV] Class " + className + " was loaded via class loader " + objectId(classLoader));
/* 1207 */     logHierarchy("[ENV] Ancestry of class loader which loaded " + className + " is ", classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void logDiagnostic(String msg) {
/* 1232 */     if (DIAGNOSTICS_STREAM != null) {
/* 1233 */       logDiagnosticDirect(msg);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void logDiagnostic(Supplier<String> msg) {
/* 1259 */     if (DIAGNOSTICS_STREAM != null) {
/* 1260 */       logDiagnosticDirect(msg.get());
/*      */     }
/*      */   }
/*      */   
/*      */   private static void logDiagnosticDirect(String msg) {
/* 1265 */     DIAGNOSTICS_STREAM.print(DIAGNOSTICS_PREFIX);
/* 1266 */     DIAGNOSTICS_STREAM.println(msg);
/* 1267 */     DIAGNOSTICS_STREAM.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void logHierarchy(String prefix, ClassLoader classLoader) {
/*      */     ClassLoader systemClassLoader;
/* 1278 */     if (!isDiagnosticsEnabled()) {
/*      */       return;
/*      */     }
/*      */     
/* 1282 */     if (classLoader != null) {
/* 1283 */       logDiagnostic(prefix + objectId(classLoader) + " == '" + classLoader.toString() + "'");
/*      */     }
/*      */     try {
/* 1286 */       systemClassLoader = ClassLoader.getSystemClassLoader();
/* 1287 */     } catch (SecurityException ex) {
/* 1288 */       logDiagnostic(prefix + "Security forbids determining the system class loader.");
/*      */       return;
/*      */     } 
/* 1291 */     if (classLoader != null) {
/* 1292 */       StringBuilder buf = new StringBuilder(prefix + "ClassLoader tree:");
/*      */       while (true) {
/* 1294 */         buf.append(objectId(classLoader));
/* 1295 */         if (classLoader == systemClassLoader) {
/* 1296 */           buf.append(" (SYSTEM) ");
/*      */         }
/*      */         try {
/* 1299 */           classLoader = classLoader.getParent();
/* 1300 */         } catch (SecurityException ex) {
/* 1301 */           buf.append(" --> SECRET");
/*      */           break;
/*      */         } 
/* 1304 */         buf.append(" --> ");
/* 1305 */         if (classLoader == null) {
/* 1306 */           buf.append("BOOT");
/*      */           break;
/*      */         } 
/*      */       } 
/* 1310 */       logDiagnostic(buf.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void logRawDiagnostic(String msg) {
/* 1321 */     if (DIAGNOSTICS_STREAM != null) {
/* 1322 */       DIAGNOSTICS_STREAM.println(msg);
/* 1323 */       DIAGNOSTICS_STREAM.flush();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static LogFactory newFactory(String factoryClass, ClassLoader classLoader) {
/* 1349 */     return newFactory(factoryClass, classLoader, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static LogFactory newFactory(String factoryClass, ClassLoader classLoader, ClassLoader contextClassLoader) throws LogConfigurationException {
/* 1393 */     Object result = AccessController.doPrivileged(() -> createFactory(factoryClass, classLoader));
/* 1394 */     if (result instanceof LogConfigurationException) {
/* 1395 */       LogConfigurationException ex = (LogConfigurationException)result;
/* 1396 */       logDiagnostic(() -> "An error occurred while loading the factory class:" + ex.getMessage());
/* 1397 */       throw ex;
/*      */     } 
/* 1399 */     logDiagnostic(() -> "Created object " + objectId(result) + " to manage class loader " + objectId(contextClassLoader));
/* 1400 */     return (LogFactory)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static LogFactory newStandardFactory(ClassLoader classLoader) {
/* 1412 */     if (isClassAvailable("org.apache.logging.slf4j.SLF4JProvider", classLoader)) {
/*      */       
/* 1414 */       try { return Class.forName("org.apache.commons.logging.impl.Slf4jLogFactory", true, classLoader).getConstructor(new Class[0]).newInstance(new Object[0]); }
/* 1415 */       catch (LinkageError|ReflectiveOperationException linkageError) {  }
/*      */       finally
/* 1417 */       { logDiagnostic(() -> "[LOOKUP] Log4j API to SLF4J redirection detected. Loading the SLF4J LogFactory implementation 'org.apache.commons.logging.impl.Slf4jLogFactory'."); }
/*      */     
/*      */     }
/*      */ 
/*      */     
/* 1422 */     try { return Class.forName("org.apache.commons.logging.impl.Log4jApiLogFactory", true, classLoader).getConstructor(new Class[0]).newInstance(new Object[0]); }
/* 1423 */     catch (LinkageError|ReflectiveOperationException linkageError) {  }
/*      */     finally
/* 1425 */     { logDiagnostic(() -> "[LOOKUP] Loading the Log4j API LogFactory implementation 'org.apache.commons.logging.impl.Log4jApiLogFactory'."); }
/*      */ 
/*      */     
/* 1428 */     try { return Class.forName("org.apache.commons.logging.impl.Slf4jLogFactory", true, classLoader).getConstructor(new Class[0]).newInstance(new Object[0]); }
/* 1429 */     catch (LinkageError|ReflectiveOperationException linkageError) {  }
/*      */     finally
/* 1431 */     { logDiagnostic(() -> "[LOOKUP] Loading the SLF4J LogFactory implementation 'org.apache.commons.logging.impl.Slf4jLogFactory'."); }
/*      */ 
/*      */     
/* 1434 */     try { return Class.forName("org.apache.commons.logging.impl.LogFactoryImpl", true, classLoader).getConstructor(new Class[0]).newInstance(new Object[0]); }
/* 1435 */     catch (LinkageError|ReflectiveOperationException linkageError) {  }
/*      */     finally
/* 1437 */     { logDiagnostic(() -> "[LOOKUP] Loading the legacy LogFactory implementation 'org.apache.commons.logging.impl.LogFactoryImpl'."); }
/*      */     
/* 1439 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String objectId(Object obj) {
/* 1456 */     if (obj == null) {
/* 1457 */       return "null";
/*      */     }
/* 1459 */     return obj.getClass().getName() + "@" + System.identityHashCode(obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void release(ClassLoader classLoader) {
/* 1471 */     logDiagnostic(() -> "Releasing factory for class loader " + objectId(classLoader));
/*      */     
/* 1473 */     Hashtable<ClassLoader, LogFactory> factories = LogFactory.factories;
/* 1474 */     synchronized (factories) {
/* 1475 */       if (classLoader == null) {
/* 1476 */         if (nullClassLoaderFactory != null) {
/* 1477 */           nullClassLoaderFactory.release();
/* 1478 */           nullClassLoaderFactory = null;
/*      */         } 
/*      */       } else {
/* 1481 */         LogFactory factory = factories.get(classLoader);
/* 1482 */         if (factory != null) {
/* 1483 */           factory.release();
/* 1484 */           factories.remove(classLoader);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void releaseAll() {
/* 1499 */     logDiagnostic("Releasing factory for all class loaders.");
/*      */     
/* 1501 */     Hashtable<ClassLoader, LogFactory> factories = LogFactory.factories;
/* 1502 */     synchronized (factories) {
/* 1503 */       factories.values().forEach(LogFactory::release);
/* 1504 */       factories.clear();
/* 1505 */       if (nullClassLoaderFactory != null) {
/* 1506 */         nullClassLoaderFactory.release();
/* 1507 */         nullClassLoaderFactory = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static String trim(String src) {
/* 1514 */     return (src != null) ? src.trim() : null;
/*      */   }
/*      */   
/*      */   public abstract Object getAttribute(String paramString);
/*      */   
/*      */   public abstract String[] getAttributeNames();
/*      */   
/*      */   public abstract Log getInstance(Class<?> paramClass) throws LogConfigurationException;
/*      */   
/*      */   public abstract Log getInstance(String paramString) throws LogConfigurationException;
/*      */   
/*      */   public abstract void release();
/*      */   
/*      */   public abstract void removeAttribute(String paramString);
/*      */   
/*      */   public abstract void setAttribute(String paramString, Object paramObject);
/*      */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-logging-1.3.5.jar!\org\apache\commons\logging\LogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */