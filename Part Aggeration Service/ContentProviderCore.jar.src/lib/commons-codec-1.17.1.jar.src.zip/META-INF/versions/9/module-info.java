module org.apache.commons.codec {
  requires java.base;
  
  exports org.apache.commons.codec;
  exports org.apache.commons.codec.binary;
  exports org.apache.commons.codec.cli;
  exports org.apache.commons.codec.digest;
  exports org.apache.commons.codec.language;
  exports org.apache.commons.codec.language.bm;
  exports org.apache.commons.codec.net;
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */