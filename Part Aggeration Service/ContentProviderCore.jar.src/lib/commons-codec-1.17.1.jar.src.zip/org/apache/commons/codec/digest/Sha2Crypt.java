/*     */ package org.apache.commons.codec.digest;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Arrays;
/*     */ import java.util.Random;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sha2Crypt
/*     */ {
/*     */   private static final int ROUNDS_DEFAULT = 5000;
/*     */   private static final int ROUNDS_MAX = 999999999;
/*     */   private static final int ROUNDS_MIN = 1000;
/*     */   private static final String ROUNDS_PREFIX = "rounds=";
/*     */   private static final int SHA256_BLOCKSIZE = 32;
/*     */   static final String SHA256_PREFIX = "$5$";
/*     */   private static final int SHA512_BLOCKSIZE = 64;
/*     */   static final String SHA512_PREFIX = "$6$";
/*  72 */   private static final Pattern SALT_PATTERN = Pattern.compile("^\\$([56])\\$(rounds=(\\d+)\\$)?([\\.\\/a-zA-Z0-9]{1,16}).*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sha256Crypt(byte[] keyBytes) {
/*  90 */     return sha256Crypt(keyBytes, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sha256Crypt(byte[] keyBytes, String salt) {
/* 111 */     if (salt == null) {
/* 112 */       salt = "$5$" + B64.getRandomSalt(8);
/*     */     }
/* 114 */     return sha2Crypt(keyBytes, salt, "$5$", 32, "SHA-256");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sha256Crypt(byte[] keyBytes, String salt, Random random) {
/* 137 */     if (salt == null) {
/* 138 */       salt = "$5$" + B64.getRandomSalt(8, random);
/*     */     }
/* 140 */     return sha2Crypt(keyBytes, salt, "$5$", 32, "SHA-256");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String sha2Crypt(byte[] keyBytes, String salt, String saltPrefix, int blocksize, String algorithm) {
/* 173 */     int keyLen = keyBytes.length;
/*     */ 
/*     */     
/* 176 */     int rounds = 5000;
/* 177 */     boolean roundsCustom = false;
/* 178 */     if (salt == null) {
/* 179 */       throw new IllegalArgumentException("Salt must not be null");
/*     */     }
/*     */     
/* 182 */     Matcher m = SALT_PATTERN.matcher(salt);
/* 183 */     if (!m.find()) {
/* 184 */       throw new IllegalArgumentException("Invalid salt value: " + salt);
/*     */     }
/* 186 */     if (m.group(3) != null) {
/* 187 */       rounds = Integer.parseInt(m.group(3));
/* 188 */       rounds = Math.max(1000, Math.min(999999999, rounds));
/* 189 */       roundsCustom = true;
/*     */     } 
/* 191 */     String saltString = m.group(4);
/* 192 */     byte[] saltBytes = saltString.getBytes(StandardCharsets.UTF_8);
/* 193 */     int saltLen = saltBytes.length;
/*     */ 
/*     */ 
/*     */     
/* 197 */     MessageDigest ctx = DigestUtils.getDigest(algorithm);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     ctx.update(keyBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     ctx.update(saltBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     MessageDigest altCtx = DigestUtils.getDigest(algorithm);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     altCtx.update(keyBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     altCtx.update(saltBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     altCtx.update(keyBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     byte[] altResult = altCtx.digest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     int cnt = keyBytes.length;
/* 260 */     while (cnt > blocksize) {
/* 261 */       ctx.update(altResult, 0, blocksize);
/* 262 */       cnt -= blocksize;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 267 */     ctx.update(altResult, 0, cnt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     cnt = keyBytes.length;
/* 284 */     while (cnt > 0) {
/* 285 */       if ((cnt & 0x1) != 0) {
/* 286 */         ctx.update(altResult, 0, blocksize);
/*     */       } else {
/* 288 */         ctx.update(keyBytes);
/*     */       } 
/* 290 */       cnt >>= 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     altResult = ctx.digest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     altCtx = DigestUtils.getDigest(algorithm);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     for (int i = 1; i <= keyLen; i++) {
/* 313 */       altCtx.update(keyBytes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     byte[] tempResult = altCtx.digest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 332 */     byte[] pBytes = new byte[keyLen];
/* 333 */     int cp = 0;
/* 334 */     while (cp < keyLen - blocksize) {
/* 335 */       System.arraycopy(tempResult, 0, pBytes, cp, blocksize);
/* 336 */       cp += blocksize;
/*     */     } 
/* 338 */     System.arraycopy(tempResult, 0, pBytes, cp, keyLen - cp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     altCtx = DigestUtils.getDigest(algorithm);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     for (int j = 1; j <= 16 + (altResult[0] & 0xFF); j++) {
/* 354 */       altCtx.update(saltBytes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     tempResult = altCtx.digest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     byte[] sBytes = new byte[saltLen];
/* 375 */     cp = 0;
/* 376 */     while (cp < saltLen - blocksize) {
/* 377 */       System.arraycopy(tempResult, 0, sBytes, cp, blocksize);
/* 378 */       cp += blocksize;
/*     */     } 
/* 380 */     System.arraycopy(tempResult, 0, sBytes, cp, saltLen - cp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     for (int k = 0; k <= rounds - 1; k++) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 398 */       ctx = DigestUtils.getDigest(algorithm);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 405 */       if ((k & 0x1) != 0) {
/* 406 */         ctx.update(pBytes, 0, keyLen);
/*     */       } else {
/* 408 */         ctx.update(altResult, 0, blocksize);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 415 */       if (k % 3 != 0) {
/* 416 */         ctx.update(sBytes, 0, saltLen);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 423 */       if (k % 7 != 0) {
/* 424 */         ctx.update(pBytes, 0, keyLen);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 432 */       if ((k & 0x1) != 0) {
/* 433 */         ctx.update(altResult, 0, blocksize);
/*     */       } else {
/* 435 */         ctx.update(pBytes, 0, keyLen);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 442 */       altResult = ctx.digest();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 460 */     StringBuilder buffer = new StringBuilder(saltPrefix);
/* 461 */     if (roundsCustom) {
/* 462 */       buffer.append("rounds=");
/* 463 */       buffer.append(rounds);
/* 464 */       buffer.append("$");
/*     */     } 
/* 466 */     buffer.append(saltString);
/* 467 */     buffer.append("$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 493 */     if (blocksize == 32) {
/* 494 */       B64.b64from24bit(altResult[0], altResult[10], altResult[20], 4, buffer);
/* 495 */       B64.b64from24bit(altResult[21], altResult[1], altResult[11], 4, buffer);
/* 496 */       B64.b64from24bit(altResult[12], altResult[22], altResult[2], 4, buffer);
/* 497 */       B64.b64from24bit(altResult[3], altResult[13], altResult[23], 4, buffer);
/* 498 */       B64.b64from24bit(altResult[24], altResult[4], altResult[14], 4, buffer);
/* 499 */       B64.b64from24bit(altResult[15], altResult[25], altResult[5], 4, buffer);
/* 500 */       B64.b64from24bit(altResult[6], altResult[16], altResult[26], 4, buffer);
/* 501 */       B64.b64from24bit(altResult[27], altResult[7], altResult[17], 4, buffer);
/* 502 */       B64.b64from24bit(altResult[18], altResult[28], altResult[8], 4, buffer);
/* 503 */       B64.b64from24bit(altResult[9], altResult[19], altResult[29], 4, buffer);
/* 504 */       B64.b64from24bit((byte)0, altResult[31], altResult[30], 3, buffer);
/*     */     } else {
/* 506 */       B64.b64from24bit(altResult[0], altResult[21], altResult[42], 4, buffer);
/* 507 */       B64.b64from24bit(altResult[22], altResult[43], altResult[1], 4, buffer);
/* 508 */       B64.b64from24bit(altResult[44], altResult[2], altResult[23], 4, buffer);
/* 509 */       B64.b64from24bit(altResult[3], altResult[24], altResult[45], 4, buffer);
/* 510 */       B64.b64from24bit(altResult[25], altResult[46], altResult[4], 4, buffer);
/* 511 */       B64.b64from24bit(altResult[47], altResult[5], altResult[26], 4, buffer);
/* 512 */       B64.b64from24bit(altResult[6], altResult[27], altResult[48], 4, buffer);
/* 513 */       B64.b64from24bit(altResult[28], altResult[49], altResult[7], 4, buffer);
/* 514 */       B64.b64from24bit(altResult[50], altResult[8], altResult[29], 4, buffer);
/* 515 */       B64.b64from24bit(altResult[9], altResult[30], altResult[51], 4, buffer);
/* 516 */       B64.b64from24bit(altResult[31], altResult[52], altResult[10], 4, buffer);
/* 517 */       B64.b64from24bit(altResult[53], altResult[11], altResult[32], 4, buffer);
/* 518 */       B64.b64from24bit(altResult[12], altResult[33], altResult[54], 4, buffer);
/* 519 */       B64.b64from24bit(altResult[34], altResult[55], altResult[13], 4, buffer);
/* 520 */       B64.b64from24bit(altResult[56], altResult[14], altResult[35], 4, buffer);
/* 521 */       B64.b64from24bit(altResult[15], altResult[36], altResult[57], 4, buffer);
/* 522 */       B64.b64from24bit(altResult[37], altResult[58], altResult[16], 4, buffer);
/* 523 */       B64.b64from24bit(altResult[59], altResult[17], altResult[38], 4, buffer);
/* 524 */       B64.b64from24bit(altResult[18], altResult[39], altResult[60], 4, buffer);
/* 525 */       B64.b64from24bit(altResult[40], altResult[61], altResult[19], 4, buffer);
/* 526 */       B64.b64from24bit(altResult[62], altResult[20], altResult[41], 4, buffer);
/* 527 */       B64.b64from24bit((byte)0, (byte)0, altResult[63], 2, buffer);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 535 */     Arrays.fill(tempResult, (byte)0);
/* 536 */     Arrays.fill(pBytes, (byte)0);
/* 537 */     Arrays.fill(sBytes, (byte)0);
/* 538 */     ctx.reset();
/* 539 */     altCtx.reset();
/* 540 */     Arrays.fill(keyBytes, (byte)0);
/* 541 */     Arrays.fill(saltBytes, (byte)0);
/*     */     
/* 543 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sha512Crypt(byte[] keyBytes) {
/* 562 */     return sha512Crypt(keyBytes, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sha512Crypt(byte[] keyBytes, String salt) {
/* 584 */     if (salt == null) {
/* 585 */       salt = "$6$" + B64.getRandomSalt(8);
/*     */     }
/* 587 */     return sha2Crypt(keyBytes, salt, "$6$", 64, "SHA-512");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sha512Crypt(byte[] keyBytes, String salt, Random random) {
/* 611 */     if (salt == null) {
/* 612 */       salt = "$6$" + B64.getRandomSalt(8, random);
/*     */     }
/* 614 */     return sha2Crypt(keyBytes, salt, "$6$", 64, "SHA-512");
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\Sha2Crypt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */