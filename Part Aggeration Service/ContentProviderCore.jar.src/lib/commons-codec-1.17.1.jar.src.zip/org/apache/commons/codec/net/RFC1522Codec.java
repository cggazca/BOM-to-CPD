/*     */ package org.apache.commons.codec.net;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.binary.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RFC1522Codec
/*     */ {
/*     */   protected static final char SEP = '?';
/*     */   protected static final String POSTFIX = "?=";
/*     */   protected static final String PREFIX = "=?";
/*     */   protected final Charset charset;
/*     */   
/*     */   RFC1522Codec(Charset charset) {
/*  61 */     this.charset = Objects.<Charset>requireNonNull(charset, "charset");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String decodeText(String text) throws DecoderException, UnsupportedEncodingException {
/*  80 */     if (text == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     if (!text.startsWith("=?") || !text.endsWith("?=")) {
/*  84 */       throw new DecoderException("RFC 1522 violation: malformed encoded content");
/*     */     }
/*  86 */     int terminator = text.length() - 2;
/*  87 */     int from = 2;
/*  88 */     int to = text.indexOf('?', from);
/*  89 */     if (to == terminator) {
/*  90 */       throw new DecoderException("RFC 1522 violation: charset token not found");
/*     */     }
/*  92 */     String charset = text.substring(from, to);
/*  93 */     if (charset.isEmpty()) {
/*  94 */       throw new DecoderException("RFC 1522 violation: charset not specified");
/*     */     }
/*  96 */     from = to + 1;
/*  97 */     to = text.indexOf('?', from);
/*  98 */     if (to == terminator) {
/*  99 */       throw new DecoderException("RFC 1522 violation: encoding token not found");
/*     */     }
/* 101 */     String encoding = text.substring(from, to);
/* 102 */     if (!getEncoding().equalsIgnoreCase(encoding)) {
/* 103 */       throw new DecoderException("This codec cannot decode " + encoding + " encoded content");
/*     */     }
/* 105 */     from = to + 1;
/* 106 */     to = text.indexOf('?', from);
/* 107 */     byte[] data = StringUtils.getBytesUsAscii(text.substring(from, to));
/* 108 */     data = doDecoding(data);
/* 109 */     return new String(data, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract byte[] doDecoding(byte[] paramArrayOfbyte) throws DecoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract byte[] doEncoding(byte[] paramArrayOfbyte) throws EncoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String encodeText(String text, Charset charset) throws EncoderException {
/* 151 */     if (text == null) {
/* 152 */       return null;
/*     */     }
/* 154 */     StringBuilder buffer = new StringBuilder();
/* 155 */     buffer.append("=?");
/* 156 */     buffer.append(charset);
/* 157 */     buffer.append('?');
/* 158 */     buffer.append(getEncoding());
/* 159 */     buffer.append('?');
/* 160 */     buffer.append(StringUtils.newStringUsAscii(doEncoding(text.getBytes(charset))));
/* 161 */     buffer.append("?=");
/* 162 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String encodeText(String text, String charsetName) throws EncoderException {
/* 184 */     if (text == null)
/*     */     {
/* 186 */       return null;
/*     */     }
/* 188 */     return encodeText(text, Charset.forName(charsetName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/* 198 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/* 207 */     return this.charset.name();
/*     */   }
/*     */   
/*     */   protected abstract String getEncoding();
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\net\RFC1522Codec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */