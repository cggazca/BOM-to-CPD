/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.CodecPolicy;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseNCodec
/*     */   implements BinaryEncoder, BinaryDecoder
/*     */ {
/*     */   static final int EOF = -1;
/*     */   public static final int MIME_CHUNK_SIZE = 76;
/*     */   public static final int PEM_CHUNK_SIZE = 64;
/*     */   private static final int DEFAULT_BUFFER_RESIZE_FACTOR = 2;
/*     */   private static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   private static final int MAX_BUFFER_SIZE = 2147483639;
/*     */   protected static final int MASK_8BITS = 255;
/*     */   protected static final byte PAD_DEFAULT = 61;
/*     */   
/*     */   public static abstract class AbstractBuilder<T, B extends AbstractBuilder<T, B>>
/*     */     implements Supplier<T>
/*     */   {
/*  64 */     private CodecPolicy decodingPolicy = BaseNCodec.DECODING_POLICY_DEFAULT;
/*     */     private int lineLength;
/*  66 */     private byte[] lineSeparator = BaseNCodec.CHUNK_SEPARATOR;
/*     */     
/*     */     private final byte[] defaultEncodeTable;
/*     */     private byte[] encodeTable;
/*  70 */     private byte padding = 61;
/*     */     
/*     */     AbstractBuilder(byte[] defaultEncodeTable) {
/*  73 */       this.defaultEncodeTable = defaultEncodeTable;
/*  74 */       this.encodeTable = defaultEncodeTable;
/*     */     }
/*     */ 
/*     */     
/*     */     B asThis() {
/*  79 */       return (B)this;
/*     */     }
/*     */     
/*     */     CodecPolicy getDecodingPolicy() {
/*  83 */       return this.decodingPolicy;
/*     */     }
/*     */     
/*     */     byte[] getEncodeTable() {
/*  87 */       return this.encodeTable;
/*     */     }
/*     */     
/*     */     int getLineLength() {
/*  91 */       return this.lineLength;
/*     */     }
/*     */     
/*     */     byte[] getLineSeparator() {
/*  95 */       return this.lineSeparator;
/*     */     }
/*     */     
/*     */     byte getPadding() {
/*  99 */       return this.padding;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public B setDecodingPolicy(CodecPolicy decodingPolicy) {
/* 109 */       this.decodingPolicy = (decodingPolicy != null) ? decodingPolicy : BaseNCodec.DECODING_POLICY_DEFAULT;
/* 110 */       return asThis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public B setEncodeTable(byte... encodeTable) {
/* 120 */       this.encodeTable = (encodeTable != null) ? encodeTable : this.defaultEncodeTable;
/* 121 */       return asThis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public B setLineLength(int lineLength) {
/* 131 */       this.lineLength = Math.max(0, lineLength);
/* 132 */       return asThis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public B setLineSeparator(byte... lineSeparator) {
/* 142 */       this.lineSeparator = (lineSeparator != null) ? lineSeparator : BaseNCodec.CHUNK_SEPARATOR;
/* 143 */       return asThis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public B setPadding(byte padding) {
/* 153 */       this.padding = padding;
/* 154 */       return asThis();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Context
/*     */   {
/*     */     int ibitWorkArea;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long lbitWorkArea;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     byte[] buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int readPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean eof;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int currentLinePos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int modulus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 218 */       return String.format("%s[buffer=%s, currentLinePos=%s, eof=%s, ibitWorkArea=%s, lbitWorkArea=%s, modulus=%s, pos=%s, readPos=%s]", new Object[] {
/* 219 */             getClass().getSimpleName(), Arrays.toString(this.buffer), 
/* 220 */             Integer.valueOf(this.currentLinePos), Boolean.valueOf(this.eof), Integer.valueOf(this.ibitWorkArea), Long.valueOf(this.lbitWorkArea), Integer.valueOf(this.modulus), Integer.valueOf(this.pos), Integer.valueOf(this.readPos)
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   protected static final CodecPolicy DECODING_POLICY_DEFAULT = CodecPolicy.LENIENT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 294 */   static final byte[] CHUNK_SEPARATOR = new byte[] { 13, 10 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int createPositiveCapacity(int minCapacity) {
/* 306 */     if (minCapacity < 0)
/*     */     {
/* 308 */       throw new OutOfMemoryError("Unable to allocate array size: " + (minCapacity & 0xFFFFFFFFL));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     return Math.max(minCapacity, 2147483639);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getChunkSeparator() {
/* 329 */     return (byte[])CHUNK_SEPARATOR.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static boolean isWhiteSpace(byte byteToCheck) {
/* 342 */     return Character.isWhitespace(byteToCheck);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] resizeBuffer(Context context, int minCapacity) {
/* 354 */     int oldCapacity = context.buffer.length;
/* 355 */     int newCapacity = oldCapacity * 2;
/* 356 */     if (Integer.compareUnsigned(newCapacity, minCapacity) < 0) {
/* 357 */       newCapacity = minCapacity;
/*     */     }
/* 359 */     if (Integer.compareUnsigned(newCapacity, 2147483639) > 0) {
/* 360 */       newCapacity = createPositiveCapacity(minCapacity);
/*     */     }
/* 362 */     byte[] b = Arrays.copyOf(context.buffer, newCapacity);
/* 363 */     context.buffer = b;
/* 364 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int toLength(byte[] array) {
/* 374 */     return (array == null) ? 0 : array.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 380 */   protected final byte PAD = 61;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte pad;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int unencodedBlockSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int encodedBlockSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int lineLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int chunkSeparatorLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final CodecPolicy decodingPolicy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength) {
/* 438 */     this(unencodedBlockSize, encodedBlockSize, lineLength, chunkSeparatorLength, (byte)61);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength, byte pad) {
/* 455 */     this(unencodedBlockSize, encodedBlockSize, lineLength, chunkSeparatorLength, pad, DECODING_POLICY_DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength, byte pad, CodecPolicy decodingPolicy) {
/* 475 */     this.unencodedBlockSize = unencodedBlockSize;
/* 476 */     this.encodedBlockSize = encodedBlockSize;
/* 477 */     boolean useChunking = (lineLength > 0 && chunkSeparatorLength > 0);
/* 478 */     this.lineLength = useChunking ? (lineLength / encodedBlockSize * encodedBlockSize) : 0;
/* 479 */     this.chunkSeparatorLength = chunkSeparatorLength;
/* 480 */     this.pad = pad;
/* 481 */     this.decodingPolicy = Objects.<CodecPolicy>requireNonNull(decodingPolicy, "codecPolicy");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int available(Context context) {
/* 491 */     return hasData(context) ? (context.pos - context.readPos) : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean containsAlphabetOrPad(byte[] arrayOctet) {
/* 504 */     if (arrayOctet != null) {
/* 505 */       for (byte element : arrayOctet) {
/* 506 */         if (this.pad == element || isInAlphabet(element)) {
/* 507 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 511 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] pArray) {
/* 523 */     if (BinaryCodec.isEmpty(pArray)) {
/* 524 */       return pArray;
/*     */     }
/* 526 */     Context context = new Context();
/* 527 */     decode(pArray, 0, pArray.length, context);
/* 528 */     decode(pArray, 0, -1, context);
/* 529 */     byte[] result = new byte[context.pos];
/* 530 */     readResults(result, 0, result.length, context);
/* 531 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void decode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, Context paramContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(Object obj) throws DecoderException {
/* 550 */     if (obj instanceof byte[]) {
/* 551 */       return decode((byte[])obj);
/*     */     }
/* 553 */     if (obj instanceof String) {
/* 554 */       return decode((String)obj);
/*     */     }
/* 556 */     throw new DecoderException("Parameter supplied to Base-N decode is not a byte[] or a String");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(String pArray) {
/* 567 */     return decode(StringUtils.getBytesUtf8(pArray));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encode(byte[] pArray) {
/* 579 */     if (BinaryCodec.isEmpty(pArray)) {
/* 580 */       return pArray;
/*     */     }
/* 582 */     return encode(pArray, 0, pArray.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encode(byte[] pArray, int offset, int length) {
/* 599 */     if (BinaryCodec.isEmpty(pArray)) {
/* 600 */       return pArray;
/*     */     }
/* 602 */     Context context = new Context();
/* 603 */     encode(pArray, offset, length, context);
/* 604 */     encode(pArray, offset, -1, context);
/* 605 */     byte[] buf = new byte[context.pos - context.readPos];
/* 606 */     readResults(buf, 0, buf.length, context);
/* 607 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, Context paramContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 625 */     if (!(obj instanceof byte[])) {
/* 626 */       throw new EncoderException("Parameter supplied to Base-N encode is not a byte[]");
/*     */     }
/* 628 */     return encode((byte[])obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodeAsString(byte[] pArray) {
/* 643 */     return StringUtils.newStringUtf8(encode(pArray));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodeToString(byte[] pArray) {
/* 655 */     return StringUtils.newStringUtf8(encode(pArray));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] ensureBufferSize(int size, Context context) {
/* 666 */     if (context.buffer == null) {
/* 667 */       context.buffer = new byte[Math.max(size, getDefaultBufferSize())];
/* 668 */       context.pos = 0;
/* 669 */       context.readPos = 0;
/*     */     
/*     */     }
/* 672 */     else if (context.pos + size - context.buffer.length > 0) {
/* 673 */       return resizeBuffer(context, context.pos + size);
/*     */     } 
/* 675 */     return context.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodecPolicy getCodecPolicy() {
/* 691 */     return this.decodingPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultBufferSize() {
/* 700 */     return 8192;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getEncodedLength(byte[] pArray) {
/* 714 */     long len = ((pArray.length + this.unencodedBlockSize - 1) / this.unencodedBlockSize) * this.encodedBlockSize;
/* 715 */     if (this.lineLength > 0)
/*     */     {
/* 717 */       len += (len + this.lineLength - 1L) / this.lineLength * this.chunkSeparatorLength;
/*     */     }
/* 719 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasData(Context context) {
/* 729 */     return (context.pos > context.readPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isInAlphabet(byte paramByte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInAlphabet(byte[] arrayOctet, boolean allowWSPad) {
/* 753 */     for (byte octet : arrayOctet) {
/* 754 */       if (!isInAlphabet(octet) && (!allowWSPad || (octet != this.pad && !Character.isWhitespace(octet)))) {
/* 755 */         return false;
/*     */       }
/*     */     } 
/* 758 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInAlphabet(String basen) {
/* 771 */     return isInAlphabet(StringUtils.getBytesUtf8(basen), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStrictDecoding() {
/* 787 */     return (this.decodingPolicy == CodecPolicy.STRICT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readResults(byte[] b, int bPos, int bAvail, Context context) {
/* 808 */     if (hasData(context)) {
/* 809 */       int len = Math.min(available(context), bAvail);
/* 810 */       System.arraycopy(context.buffer, context.readPos, b, bPos, len);
/* 811 */       context.readPos += len;
/* 812 */       if (!hasData(context))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 817 */         context.pos = context.readPos = 0;
/*     */       }
/* 819 */       return len;
/*     */     } 
/* 821 */     return context.eof ? -1 : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\binary\BaseNCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */