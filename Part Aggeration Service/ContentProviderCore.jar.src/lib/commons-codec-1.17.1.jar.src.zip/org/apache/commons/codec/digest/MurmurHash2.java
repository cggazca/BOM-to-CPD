/*     */ package org.apache.commons.codec.digest;
/*     */ 
/*     */ import org.apache.commons.codec.binary.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MurmurHash2
/*     */ {
/*     */   private static final int M32 = 1540483477;
/*     */   private static final int R32 = 24;
/*     */   private static final long M64 = -4132994306676758123L;
/*     */   private static final int R64 = 47;
/*     */   
/*     */   private static int getLittleEndianInt(byte[] data, int index) {
/*  69 */     return data[index] & 0xFF | (data[index + 1] & 0xFF) << 8 | (data[index + 2] & 0xFF) << 16 | (data[index + 3] & 0xFF) << 24;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long getLittleEndianLong(byte[] data, int index) {
/*  83 */     return data[index] & 0xFFL | (data[index + 1] & 0xFFL) << 8L | (data[index + 2] & 0xFFL) << 16L | (data[index + 3] & 0xFFL) << 24L | (data[index + 4] & 0xFFL) << 32L | (data[index + 5] & 0xFFL) << 40L | (data[index + 6] & 0xFFL) << 48L | (data[index + 7] & 0xFFL) << 56L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hash32(byte[] data, int length) {
/* 108 */     return hash32(data, length, -1756908916);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hash32(byte[] data, int length, int seed) {
/* 121 */     int h = seed ^ length;
/*     */ 
/*     */     
/* 124 */     int nblocks = length >> 2;
/*     */ 
/*     */     
/* 127 */     for (int i = 0; i < nblocks; i++) {
/* 128 */       int j = i << 2;
/* 129 */       int k = getLittleEndianInt(data, j);
/* 130 */       k *= 1540483477;
/* 131 */       k ^= k >>> 24;
/* 132 */       k *= 1540483477;
/* 133 */       h *= 1540483477;
/* 134 */       h ^= k;
/*     */     } 
/*     */ 
/*     */     
/* 138 */     int index = nblocks << 2;
/* 139 */     switch (length - index) {
/*     */       case 3:
/* 141 */         h ^= (data[index + 2] & 0xFF) << 16;
/*     */       case 2:
/* 143 */         h ^= (data[index + 1] & 0xFF) << 8;
/*     */       case 1:
/* 145 */         h ^= data[index] & 0xFF;
/* 146 */         h *= 1540483477;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 151 */     h ^= h >>> 13;
/* 152 */     h *= 1540483477;
/* 153 */     h ^= h >>> 15;
/*     */     
/* 155 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hash32(String text) {
/* 177 */     byte[] bytes = StringUtils.getBytesUtf8(text);
/* 178 */     return hash32(bytes, bytes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hash32(String text, int from, int length) {
/* 199 */     return hash32(text.substring(from, from + length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long hash64(byte[] data, int length) {
/* 217 */     return hash64(data, length, -512093083);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long hash64(byte[] data, int length, int seed) {
/* 229 */     long h = seed & 0xFFFFFFFFL ^ length * -4132994306676758123L;
/*     */     
/* 231 */     int nblocks = length >> 3;
/*     */ 
/*     */     
/* 234 */     for (int i = 0; i < nblocks; i++) {
/* 235 */       int j = i << 3;
/* 236 */       long k = getLittleEndianLong(data, j);
/*     */       
/* 238 */       k *= -4132994306676758123L;
/* 239 */       k ^= k >>> 47L;
/* 240 */       k *= -4132994306676758123L;
/*     */       
/* 242 */       h ^= k;
/* 243 */       h *= -4132994306676758123L;
/*     */     } 
/*     */     
/* 246 */     int index = nblocks << 3;
/* 247 */     switch (length - index) {
/*     */       case 7:
/* 249 */         h ^= (data[index + 6] & 0xFFL) << 48L;
/*     */       case 6:
/* 251 */         h ^= (data[index + 5] & 0xFFL) << 40L;
/*     */       case 5:
/* 253 */         h ^= (data[index + 4] & 0xFFL) << 32L;
/*     */       case 4:
/* 255 */         h ^= (data[index + 3] & 0xFFL) << 24L;
/*     */       case 3:
/* 257 */         h ^= (data[index + 2] & 0xFFL) << 16L;
/*     */       case 2:
/* 259 */         h ^= (data[index + 1] & 0xFFL) << 8L;
/*     */       case 1:
/* 261 */         h ^= data[index] & 0xFFL;
/* 262 */         h *= -4132994306676758123L;
/*     */         break;
/*     */     } 
/* 265 */     h ^= h >>> 47L;
/* 266 */     h *= -4132994306676758123L;
/* 267 */     h ^= h >>> 47L;
/*     */     
/* 269 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long hash64(String text) {
/* 293 */     byte[] bytes = StringUtils.getBytesUtf8(text);
/* 294 */     return hash64(bytes, bytes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long hash64(String text, int from, int length) {
/* 315 */     return hash64(text.substring(from, from + length));
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\MurmurHash2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */