/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ import org.apache.commons.codec.binary.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleMetaphone
/*     */   implements StringEncoder
/*     */ {
/*     */   private static final String VOWELS = "AEIOUY";
/*     */   
/*     */   public class DoubleMetaphoneResult
/*     */   {
/*  44 */     private final StringBuilder primary = new StringBuilder(DoubleMetaphone.this.getMaxCodeLen());
/*  45 */     private final StringBuilder alternate = new StringBuilder(DoubleMetaphone.this.getMaxCodeLen());
/*     */     private final int maxLength;
/*     */     
/*     */     public DoubleMetaphoneResult(int maxLength) {
/*  49 */       this.maxLength = maxLength;
/*     */     }
/*     */     
/*     */     public void append(char value) {
/*  53 */       appendPrimary(value);
/*  54 */       appendAlternate(value);
/*     */     }
/*     */     
/*     */     public void append(char primary, char alternate) {
/*  58 */       appendPrimary(primary);
/*  59 */       appendAlternate(alternate);
/*     */     }
/*     */     
/*     */     public void append(String value) {
/*  63 */       appendPrimary(value);
/*  64 */       appendAlternate(value);
/*     */     }
/*     */     
/*     */     public void append(String primary, String alternate) {
/*  68 */       appendPrimary(primary);
/*  69 */       appendAlternate(alternate);
/*     */     }
/*     */     
/*     */     public void appendAlternate(char value) {
/*  73 */       if (this.alternate.length() < this.maxLength) {
/*  74 */         this.alternate.append(value);
/*     */       }
/*     */     }
/*     */     
/*     */     public void appendAlternate(String value) {
/*  79 */       int addChars = this.maxLength - this.alternate.length();
/*  80 */       if (value.length() <= addChars) {
/*  81 */         this.alternate.append(value);
/*     */       } else {
/*  83 */         this.alternate.append(value, 0, addChars);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void appendPrimary(char value) {
/*  88 */       if (this.primary.length() < this.maxLength) {
/*  89 */         this.primary.append(value);
/*     */       }
/*     */     }
/*     */     
/*     */     public void appendPrimary(String value) {
/*  94 */       int addChars = this.maxLength - this.primary.length();
/*  95 */       if (value.length() <= addChars) {
/*  96 */         this.primary.append(value);
/*     */       } else {
/*  98 */         this.primary.append(value, 0, addChars);
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getAlternate() {
/* 103 */       return this.alternate.toString();
/*     */     }
/*     */     
/*     */     public String getPrimary() {
/* 107 */       return this.primary.toString();
/*     */     }
/*     */     
/*     */     public boolean isComplete() {
/* 111 */       return (this.primary.length() >= this.maxLength && this.alternate
/* 112 */         .length() >= this.maxLength);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   private static final String[] SILENT_START = new String[] { "GN", "KN", "PN", "WR", "PS" };
/*     */   
/* 125 */   private static final String[] L_R_N_M_B_H_F_V_W_SPACE = new String[] { "L", "R", "N", "M", "B", "H", "F", "V", "W", " " };
/*     */   
/* 127 */   private static final String[] ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER = new String[] { "ES", "EP", "EB", "EL", "EY", "IB", "IL", "IN", "IE", "EI", "ER" };
/*     */ 
/*     */   
/* 130 */   private static final String[] L_T_K_S_N_M_B_Z = new String[] { "L", "T", "K", "S", "N", "M", "B", "Z" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean contains(String value, int start, int length, String... criteria) {
/* 139 */     boolean result = false;
/* 140 */     if (start >= 0 && start + length <= value.length()) {
/* 141 */       String target = value.substring(start, start + length);
/*     */       
/* 143 */       for (String element : criteria) {
/* 144 */         if (target.equals(element)) {
/* 145 */           result = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 150 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   private int maxCodeLen = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected char charAt(String value, int index) {
/* 164 */     if (index < 0 || index >= value.length()) {
/* 165 */       return Character.MIN_VALUE;
/*     */     }
/* 167 */     return value.charAt(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String cleanInput(String input) {
/* 174 */     if (input == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     input = input.trim();
/* 178 */     if (input.isEmpty()) {
/* 179 */       return null;
/*     */     }
/* 181 */     return input.toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean conditionC0(String value, int index) {
/* 188 */     if (contains(value, index, 4, new String[] { "CHIA" })) {
/* 189 */       return true;
/*     */     }
/* 191 */     if (index <= 1) {
/* 192 */       return false;
/*     */     }
/* 194 */     if (isVowel(charAt(value, index - 2))) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (!contains(value, index - 1, 3, new String[] { "ACH" })) {
/* 198 */       return false;
/*     */     }
/* 200 */     char c = charAt(value, index + 2);
/* 201 */     return ((c != 'I' && c != 'E') || 
/* 202 */       contains(value, index - 2, 6, new String[] { "BACHER", "MACHER" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean conditionCH0(String value, int index) {
/* 209 */     if (index != 0) {
/* 210 */       return false;
/*     */     }
/* 212 */     if (!contains(value, index + 1, 5, new String[] { "HARAC", "HARIS"
/* 213 */         }) && !contains(value, index + 1, 3, new String[] { "HOR", "HYM", "HIA", "HEM" })) {
/* 214 */       return false;
/*     */     }
/* 216 */     return !contains(value, 0, 5, new String[] { "CHORE" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean conditionCH1(String value, int index) {
/* 223 */     return (contains(value, 0, 4, new String[] { "VAN ", "VON " }) || contains(value, 0, 3, new String[] { "SCH"
/* 224 */         }) || contains(value, index - 2, 6, new String[] { "ORCHES", "ARCHIT", "ORCHID"
/* 225 */         }) || contains(value, index + 2, 1, new String[] { "T", "S"
/* 226 */         }) || ((contains(value, index - 1, 1, new String[] { "A", "O", "U", "E" }) || index == 0) && (
/* 227 */       contains(value, index + 2, 1, L_R_N_M_B_H_F_V_W_SPACE) || index + 1 == value.length() - 1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean conditionL0(String value, int index) {
/* 234 */     if (index == value.length() - 3 && 
/* 235 */       contains(value, index - 1, 4, new String[] { "ILLO", "ILLA", "ALLE" })) {
/* 236 */       return true;
/*     */     }
/* 238 */     return ((contains(value, value.length() - 2, 2, new String[] { "AS", "OS"
/* 239 */         }) || contains(value, value.length() - 1, 1, new String[] { "A", "O"
/* 240 */         })) && contains(value, index - 1, 4, new String[] { "ALLE" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean conditionM0(String value, int index) {
/* 249 */     if (charAt(value, index + 1) == 'M') {
/* 250 */       return true;
/*     */     }
/* 252 */     return (contains(value, index - 1, 3, new String[] { "UMB" }) && (index + 1 == value
/* 253 */       .length() - 1 || contains(value, index + 2, 2, new String[] { "ER" })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String doubleMetaphone(String value) {
/* 263 */     return doubleMetaphone(value, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String doubleMetaphone(String value, boolean alternate) {
/* 274 */     value = cleanInput(value);
/* 275 */     if (value == null) {
/* 276 */       return null;
/*     */     }
/*     */     
/* 279 */     boolean slavoGermanic = isSlavoGermanic(value);
/* 280 */     int index = isSilentStart(value) ? 1 : 0;
/*     */     
/* 282 */     DoubleMetaphoneResult result = new DoubleMetaphoneResult(getMaxCodeLen());
/*     */     
/* 284 */     while (!result.isComplete() && index <= value.length() - 1) {
/* 285 */       switch (value.charAt(index)) {
/*     */         case 'A':
/*     */         case 'E':
/*     */         case 'I':
/*     */         case 'O':
/*     */         case 'U':
/*     */         case 'Y':
/* 292 */           index = handleAEIOUY(result, index);
/*     */           continue;
/*     */         case 'B':
/* 295 */           result.append('P');
/* 296 */           index = (charAt(value, index + 1) == 'B') ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         
/*     */         case 'Ç':
/* 300 */           result.append('S');
/* 301 */           index++;
/*     */           continue;
/*     */         case 'C':
/* 304 */           index = handleC(value, result, index);
/*     */           continue;
/*     */         case 'D':
/* 307 */           index = handleD(value, result, index);
/*     */           continue;
/*     */         case 'F':
/* 310 */           result.append('F');
/* 311 */           index = (charAt(value, index + 1) == 'F') ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         case 'G':
/* 314 */           index = handleG(value, result, index, slavoGermanic);
/*     */           continue;
/*     */         case 'H':
/* 317 */           index = handleH(value, result, index);
/*     */           continue;
/*     */         case 'J':
/* 320 */           index = handleJ(value, result, index, slavoGermanic);
/*     */           continue;
/*     */         case 'K':
/* 323 */           result.append('K');
/* 324 */           index = (charAt(value, index + 1) == 'K') ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         case 'L':
/* 327 */           index = handleL(value, result, index);
/*     */           continue;
/*     */         case 'M':
/* 330 */           result.append('M');
/* 331 */           index = conditionM0(value, index) ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         case 'N':
/* 334 */           result.append('N');
/* 335 */           index = (charAt(value, index + 1) == 'N') ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         
/*     */         case 'Ñ':
/* 339 */           result.append('N');
/* 340 */           index++;
/*     */           continue;
/*     */         case 'P':
/* 343 */           index = handleP(value, result, index);
/*     */           continue;
/*     */         case 'Q':
/* 346 */           result.append('K');
/* 347 */           index = (charAt(value, index + 1) == 'Q') ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         case 'R':
/* 350 */           index = handleR(value, result, index, slavoGermanic);
/*     */           continue;
/*     */         case 'S':
/* 353 */           index = handleS(value, result, index, slavoGermanic);
/*     */           continue;
/*     */         case 'T':
/* 356 */           index = handleT(value, result, index);
/*     */           continue;
/*     */         case 'V':
/* 359 */           result.append('F');
/* 360 */           index = (charAt(value, index + 1) == 'V') ? (index + 2) : (index + 1);
/*     */           continue;
/*     */         case 'W':
/* 363 */           index = handleW(value, result, index);
/*     */           continue;
/*     */         case 'X':
/* 366 */           index = handleX(value, result, index);
/*     */           continue;
/*     */         case 'Z':
/* 369 */           index = handleZ(value, result, index, slavoGermanic);
/*     */           continue;
/*     */       } 
/* 372 */       index++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 377 */     return alternate ? result.getAlternate() : result.getPrimary();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 390 */     if (!(obj instanceof String)) {
/* 391 */       throw new EncoderException("DoubleMetaphone encode parameter is not of type String");
/*     */     }
/* 393 */     return doubleMetaphone((String)obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String value) {
/* 404 */     return doubleMetaphone(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxCodeLen() {
/* 412 */     return this.maxCodeLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleAEIOUY(DoubleMetaphoneResult result, int index) {
/* 419 */     if (index == 0) {
/* 420 */       result.append('A');
/*     */     }
/* 422 */     return index + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleC(String value, DoubleMetaphoneResult result, int index) {
/* 429 */     if (conditionC0(value, index))
/* 430 */     { result.append('K');
/* 431 */       index += 2; }
/* 432 */     else if (index == 0 && contains(value, index, 6, new String[] { "CAESAR" }))
/* 433 */     { result.append('S');
/* 434 */       index += 2; }
/* 435 */     else if (contains(value, index, 2, new String[] { "CH" }))
/* 436 */     { index = handleCH(value, result, index); }
/* 437 */     else if (contains(value, index, 2, new String[] { "CZ"
/* 438 */         }) && !contains(value, index - 2, 4, new String[] { "WICZ" }))
/*     */     
/* 440 */     { result.append('S', 'X');
/* 441 */       index += 2; }
/* 442 */     else if (contains(value, index + 1, 3, new String[] { "CIA" }))
/*     */     
/* 444 */     { result.append('X');
/* 445 */       index += 3; }
/* 446 */     else { if (contains(value, index, 2, new String[] { "CC" }) && (index != 1 || 
/* 447 */         charAt(value, 0) != 'M'))
/*     */       {
/* 449 */         return handleCC(value, result, index); } 
/* 450 */       if (contains(value, index, 2, new String[] { "CK", "CG", "CQ" })) {
/* 451 */         result.append('K');
/* 452 */         index += 2;
/* 453 */       } else if (contains(value, index, 2, new String[] { "CI", "CE", "CY" })) {
/*     */         
/* 455 */         if (contains(value, index, 3, new String[] { "CIO", "CIE", "CIA" })) {
/* 456 */           result.append('S', 'X');
/*     */         } else {
/* 458 */           result.append('S');
/*     */         } 
/* 460 */         index += 2;
/*     */       } else {
/* 462 */         result.append('K');
/* 463 */         if (contains(value, index + 1, 2, new String[] { " C", " Q", " G" })) {
/*     */           
/* 465 */           index += 3;
/* 466 */         } else if (contains(value, index + 1, 1, new String[] { "C", "K", "Q"
/* 467 */             }) && !contains(value, index + 1, 2, new String[] { "CE", "CI" })) {
/* 468 */           index += 2;
/*     */         } else {
/* 470 */           index++;
/*     */         } 
/*     */       }  }
/*     */     
/* 474 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleCC(String value, DoubleMetaphoneResult result, int index) {
/* 481 */     if (contains(value, index + 2, 1, new String[] { "I", "E", "H"
/* 482 */         }) && !contains(value, index + 2, 2, new String[] { "HU" })) {
/*     */       
/* 484 */       if ((index == 1 && charAt(value, index - 1) == 'A') || 
/* 485 */         contains(value, index - 1, 5, new String[] { "UCCEE", "UCCES" })) {
/*     */         
/* 487 */         result.append("KS");
/*     */       } else {
/*     */         
/* 490 */         result.append('X');
/*     */       } 
/* 492 */       index += 3;
/*     */     } else {
/* 494 */       result.append('K');
/* 495 */       index += 2;
/*     */     } 
/*     */     
/* 498 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleCH(String value, DoubleMetaphoneResult result, int index) {
/* 505 */     if (index > 0 && contains(value, index, 4, new String[] { "CHAE" })) {
/* 506 */       result.append('K', 'X');
/* 507 */       return index + 2;
/*     */     } 
/* 509 */     if (conditionCH0(value, index)) {
/*     */       
/* 511 */       result.append('K');
/* 512 */       return index + 2;
/*     */     } 
/* 514 */     if (conditionCH1(value, index)) {
/*     */       
/* 516 */       result.append('K');
/* 517 */       return index + 2;
/*     */     } 
/* 519 */     if (index > 0) {
/* 520 */       if (contains(value, 0, 2, new String[] { "MC" })) {
/* 521 */         result.append('K');
/*     */       } else {
/* 523 */         result.append('X', 'K');
/*     */       } 
/*     */     } else {
/* 526 */       result.append('X');
/*     */     } 
/* 528 */     return index + 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleD(String value, DoubleMetaphoneResult result, int index) {
/* 535 */     if (contains(value, index, 2, new String[] { "DG" })) {
/*     */       
/* 537 */       if (contains(value, index + 2, 1, new String[] { "I", "E", "Y" })) {
/* 538 */         result.append('J');
/* 539 */         index += 3;
/*     */       } else {
/*     */         
/* 542 */         result.append("TK");
/* 543 */         index += 2;
/*     */       } 
/* 545 */     } else if (contains(value, index, 2, new String[] { "DT", "DD" })) {
/* 546 */       result.append('T');
/* 547 */       index += 2;
/*     */     } else {
/* 549 */       result.append('T');
/* 550 */       index++;
/*     */     } 
/* 552 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleG(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic) {
/* 560 */     if (charAt(value, index + 1) == 'H') {
/* 561 */       index = handleGH(value, result, index);
/* 562 */     } else if (charAt(value, index + 1) == 'N') {
/* 563 */       if (index == 1 && isVowel(charAt(value, 0)) && !slavoGermanic) {
/* 564 */         result.append("KN", "N");
/* 565 */       } else if (!contains(value, index + 2, 2, new String[] { "EY"
/* 566 */           }) && charAt(value, index + 1) != 'Y' && !slavoGermanic) {
/* 567 */         result.append("N", "KN");
/*     */       } else {
/* 569 */         result.append("KN");
/*     */       } 
/* 571 */       index += 2;
/* 572 */     } else if (contains(value, index + 1, 2, new String[] { "LI" }) && !slavoGermanic) {
/* 573 */       result.append("KL", "L");
/* 574 */       index += 2;
/* 575 */     } else if (index == 0 && (
/* 576 */       charAt(value, index + 1) == 'Y' || 
/* 577 */       contains(value, index + 1, 2, ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER))) {
/*     */       
/* 579 */       result.append('K', 'J');
/* 580 */       index += 2;
/* 581 */     } else if ((contains(value, index + 1, 2, new String[] { "ER"
/* 582 */         }) || charAt(value, index + 1) == 'Y') && 
/* 583 */       !contains(value, 0, 6, new String[] { "DANGER", "RANGER", "MANGER"
/* 584 */         }) && !contains(value, index - 1, 1, new String[] { "E", "I"
/* 585 */         }) && !contains(value, index - 1, 3, new String[] { "RGY", "OGY" })) {
/*     */       
/* 587 */       result.append('K', 'J');
/* 588 */       index += 2;
/* 589 */     } else if (contains(value, index + 1, 1, new String[] { "E", "I", "Y"
/* 590 */         }) || contains(value, index - 1, 4, new String[] { "AGGI", "OGGI" })) {
/*     */       
/* 592 */       if (contains(value, 0, 4, new String[] { "VAN ", "VON "
/* 593 */           }) || contains(value, 0, 3, new String[] { "SCH"
/* 594 */           }) || contains(value, index + 1, 2, new String[] { "ET" })) {
/*     */         
/* 596 */         result.append('K');
/* 597 */       } else if (contains(value, index + 1, 3, new String[] { "IER" })) {
/* 598 */         result.append('J');
/*     */       } else {
/* 600 */         result.append('J', 'K');
/*     */       } 
/* 602 */       index += 2;
/*     */     } else {
/* 604 */       if (charAt(value, index + 1) == 'G') {
/* 605 */         index += 2;
/*     */       } else {
/* 607 */         index++;
/*     */       } 
/* 609 */       result.append('K');
/*     */     } 
/* 611 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleGH(String value, DoubleMetaphoneResult result, int index) {
/* 618 */     if (index > 0 && !isVowel(charAt(value, index - 1))) {
/* 619 */       result.append('K');
/* 620 */       index += 2;
/* 621 */     } else if (index == 0) {
/* 622 */       if (charAt(value, index + 2) == 'I') {
/* 623 */         result.append('J');
/*     */       } else {
/* 625 */         result.append('K');
/*     */       } 
/* 627 */       index += 2;
/* 628 */     } else if ((index > 1 && contains(value, index - 2, 1, new String[] { "B", "H", "D" })) || (index > 2 && 
/* 629 */       contains(value, index - 3, 1, new String[] { "B", "H", "D" })) || (index > 3 && 
/* 630 */       contains(value, index - 4, 1, new String[] { "B", "H" }))) {
/*     */       
/* 632 */       index += 2;
/*     */     } else {
/* 634 */       if (index > 2 && charAt(value, index - 1) == 'U' && 
/* 635 */         contains(value, index - 3, 1, new String[] { "C", "G", "L", "R", "T" })) {
/*     */         
/* 637 */         result.append('F');
/* 638 */       } else if (index > 0 && charAt(value, index - 1) != 'I') {
/* 639 */         result.append('K');
/*     */       } 
/* 641 */       index += 2;
/*     */     } 
/* 643 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleH(String value, DoubleMetaphoneResult result, int index) {
/* 651 */     if ((index == 0 || isVowel(charAt(value, index - 1))) && 
/* 652 */       isVowel(charAt(value, index + 1))) {
/* 653 */       result.append('H');
/* 654 */       index += 2;
/*     */     } else {
/*     */       
/* 657 */       index++;
/*     */     } 
/* 659 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleJ(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic) {
/* 667 */     if (contains(value, index, 4, new String[] { "JOSE" }) || contains(value, 0, 4, new String[] { "SAN " })) {
/*     */       
/* 669 */       if ((index == 0 && charAt(value, index + 4) == ' ') || value
/* 670 */         .length() == 4 || contains(value, 0, 4, new String[] { "SAN " })) {
/* 671 */         result.append('H');
/*     */       } else {
/* 673 */         result.append('J', 'H');
/*     */       } 
/* 675 */       index++;
/*     */     } else {
/* 677 */       if (index == 0 && !contains(value, index, 4, new String[] { "JOSE" })) {
/* 678 */         result.append('J', 'A');
/* 679 */       } else if (isVowel(charAt(value, index - 1)) && !slavoGermanic && (
/* 680 */         charAt(value, index + 1) == 'A' || charAt(value, index + 1) == 'O')) {
/* 681 */         result.append('J', 'H');
/* 682 */       } else if (index == value.length() - 1) {
/* 683 */         result.append('J', ' ');
/* 684 */       } else if (!contains(value, index + 1, 1, L_T_K_S_N_M_B_Z) && 
/* 685 */         !contains(value, index - 1, 1, new String[] { "S", "K", "L" })) {
/* 686 */         result.append('J');
/*     */       } 
/*     */       
/* 689 */       if (charAt(value, index + 1) == 'J') {
/* 690 */         index += 2;
/*     */       } else {
/* 692 */         index++;
/*     */       } 
/*     */     } 
/* 695 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleL(String value, DoubleMetaphoneResult result, int index) {
/* 702 */     if (charAt(value, index + 1) == 'L') {
/* 703 */       if (conditionL0(value, index)) {
/* 704 */         result.appendPrimary('L');
/*     */       } else {
/* 706 */         result.append('L');
/*     */       } 
/* 708 */       index += 2;
/*     */     } else {
/* 710 */       index++;
/* 711 */       result.append('L');
/*     */     } 
/* 713 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleP(String value, DoubleMetaphoneResult result, int index) {
/* 720 */     if (charAt(value, index + 1) == 'H') {
/* 721 */       result.append('F');
/* 722 */       index += 2;
/*     */     } else {
/* 724 */       result.append('P');
/* 725 */       index = contains(value, index + 1, 1, new String[] { "P", "B" }) ? (index + 2) : (index + 1);
/*     */     } 
/* 727 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleR(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic) {
/* 735 */     if (index == value.length() - 1 && !slavoGermanic && 
/* 736 */       contains(value, index - 2, 2, new String[] { "IE"
/* 737 */         }) && !contains(value, index - 4, 2, new String[] { "ME", "MA" })) {
/* 738 */       result.appendAlternate('R');
/*     */     } else {
/* 740 */       result.append('R');
/*     */     } 
/* 742 */     return (charAt(value, index + 1) == 'R') ? (index + 2) : (index + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleS(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic) {
/* 752 */     if (contains(value, index - 1, 3, new String[] { "ISL", "YSL" })) {
/*     */       
/* 754 */       index++;
/* 755 */     } else if (index == 0 && contains(value, index, 5, new String[] { "SUGAR" })) {
/*     */       
/* 757 */       result.append('X', 'S');
/* 758 */       index++;
/* 759 */     } else if (contains(value, index, 2, new String[] { "SH" })) {
/* 760 */       if (contains(value, index + 1, 4, new String[] { "HEIM", "HOEK", "HOLM", "HOLZ" })) {
/*     */         
/* 762 */         result.append('S');
/*     */       } else {
/* 764 */         result.append('X');
/*     */       } 
/* 766 */       index += 2;
/* 767 */     } else if (contains(value, index, 3, new String[] { "SIO", "SIA" }) || contains(value, index, 4, new String[] { "SIAN" })) {
/*     */       
/* 769 */       if (slavoGermanic) {
/* 770 */         result.append('S');
/*     */       } else {
/* 772 */         result.append('S', 'X');
/*     */       } 
/* 774 */       index += 3;
/* 775 */     } else if ((index == 0 && contains(value, index + 1, 1, new String[] { "M", "N", "L", "W"
/* 776 */         })) || contains(value, index + 1, 1, new String[] { "Z" })) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 781 */       result.append('S', 'X');
/* 782 */       index = contains(value, index + 1, 1, new String[] { "Z" }) ? (index + 2) : (index + 1);
/* 783 */     } else if (contains(value, index, 2, new String[] { "SC" })) {
/* 784 */       index = handleSC(value, result, index);
/*     */     } else {
/* 786 */       if (index == value.length() - 1 && contains(value, index - 2, 2, new String[] { "AI", "OI" })) {
/*     */         
/* 788 */         result.appendAlternate('S');
/*     */       } else {
/* 790 */         result.append('S');
/*     */       } 
/* 792 */       index = contains(value, index + 1, 1, new String[] { "S", "Z" }) ? (index + 2) : (index + 1);
/*     */     } 
/* 794 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleSC(String value, DoubleMetaphoneResult result, int index) {
/* 801 */     if (charAt(value, index + 2) == 'H') {
/*     */       
/* 803 */       if (contains(value, index + 3, 2, new String[] { "OO", "ER", "EN", "UY", "ED", "EM" })) {
/*     */         
/* 805 */         if (contains(value, index + 3, 2, new String[] { "ER", "EN" })) {
/*     */           
/* 807 */           result.append("X", "SK");
/*     */         } else {
/* 809 */           result.append("SK");
/*     */         } 
/* 811 */       } else if (index == 0 && !isVowel(charAt(value, 3)) && charAt(value, 3) != 'W') {
/* 812 */         result.append('X', 'S');
/*     */       } else {
/* 814 */         result.append('X');
/*     */       } 
/* 816 */     } else if (contains(value, index + 2, 1, new String[] { "I", "E", "Y" })) {
/* 817 */       result.append('S');
/*     */     } else {
/* 819 */       result.append("SK");
/*     */     } 
/* 821 */     return index + 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleT(String value, DoubleMetaphoneResult result, int index) {
/* 828 */     if (contains(value, index, 4, new String[] { "TION" }) || contains(value, index, 3, new String[] { "TIA", "TCH" })) {
/* 829 */       result.append('X');
/* 830 */       index += 3;
/* 831 */     } else if (contains(value, index, 2, new String[] { "TH" }) || contains(value, index, 3, new String[] { "TTH" })) {
/* 832 */       if (contains(value, index + 2, 2, new String[] { "OM", "AM"
/*     */           
/* 834 */           }) || contains(value, 0, 4, new String[] { "VAN ", "VON "
/* 835 */           }) || contains(value, 0, 3, new String[] { "SCH" })) {
/* 836 */         result.append('T');
/*     */       } else {
/* 838 */         result.append('0', 'T');
/*     */       } 
/* 840 */       index += 2;
/*     */     } else {
/* 842 */       result.append('T');
/* 843 */       index = contains(value, index + 1, 1, new String[] { "T", "D" }) ? (index + 2) : (index + 1);
/*     */     } 
/* 845 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleW(String value, DoubleMetaphoneResult result, int index) {
/* 852 */     if (contains(value, index, 2, new String[] { "WR" })) {
/*     */       
/* 854 */       result.append('R');
/* 855 */       index += 2;
/* 856 */     } else if (index == 0 && (isVowel(charAt(value, index + 1)) || 
/* 857 */       contains(value, index, 2, new String[] { "WH" }))) {
/* 858 */       if (isVowel(charAt(value, index + 1))) {
/*     */         
/* 860 */         result.append('A', 'F');
/*     */       } else {
/*     */         
/* 863 */         result.append('A');
/*     */       } 
/* 865 */       index++;
/* 866 */     } else if ((index == value.length() - 1 && isVowel(charAt(value, index - 1))) || 
/* 867 */       contains(value, index - 1, 5, new String[] { "EWSKI", "EWSKY", "OWSKI", "OWSKY"
/* 868 */         }) || contains(value, 0, 3, new String[] { "SCH" })) {
/*     */       
/* 870 */       result.appendAlternate('F');
/* 871 */       index++;
/* 872 */     } else if (contains(value, index, 4, new String[] { "WICZ", "WITZ" })) {
/*     */       
/* 874 */       result.append("TS", "FX");
/* 875 */       index += 4;
/*     */     } else {
/* 877 */       index++;
/*     */     } 
/* 879 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleX(String value, DoubleMetaphoneResult result, int index) {
/* 886 */     if (index == 0) {
/* 887 */       result.append('S');
/* 888 */       index++;
/*     */     } else {
/* 890 */       if (index != value.length() - 1 || (
/* 891 */         !contains(value, index - 3, 3, new String[] { "IAU", "EAU"
/* 892 */           }) && !contains(value, index - 2, 2, new String[] { "AU", "OU" })))
/*     */       {
/* 894 */         result.append("KS");
/*     */       }
/* 896 */       index = contains(value, index + 1, 1, new String[] { "C", "X" }) ? (index + 2) : (index + 1);
/*     */     } 
/* 898 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int handleZ(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic) {
/* 908 */     if (charAt(value, index + 1) == 'H') {
/*     */       
/* 910 */       result.append('J');
/* 911 */       index += 2;
/*     */     } else {
/* 913 */       if (contains(value, index + 1, 2, new String[] { "ZO", "ZI", "ZA" }) || (slavoGermanic && index > 0 && 
/* 914 */         charAt(value, index - 1) != 'T')) {
/* 915 */         result.append("S", "TS");
/*     */       } else {
/* 917 */         result.append('S');
/*     */       } 
/* 919 */       index = (charAt(value, index + 1) == 'Z') ? (index + 2) : (index + 1);
/*     */     } 
/* 921 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDoubleMetaphoneEqual(String value1, String value2) {
/* 935 */     return isDoubleMetaphoneEqual(value1, value2, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDoubleMetaphoneEqual(String value1, String value2, boolean alternate) {
/* 949 */     return StringUtils.equals(doubleMetaphone(value1, alternate), doubleMetaphone(value2, alternate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSilentStart(String value) {
/* 958 */     boolean result = false;
/* 959 */     for (String element : SILENT_START) {
/* 960 */       if (value.startsWith(element)) {
/* 961 */         result = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 965 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSlavoGermanic(String value) {
/* 973 */     return (value.indexOf('W') > -1 || value.indexOf('K') > -1 || value
/* 974 */       .contains("CZ") || value.contains("WITZ"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isVowel(char ch) {
/* 981 */     return ("AEIOUY".indexOf(ch) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxCodeLen(int maxCodeLen) {
/* 991 */     this.maxCodeLen = maxCodeLen;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\DoubleMetaphone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */