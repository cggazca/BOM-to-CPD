/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColognePhonetic
/*     */   implements StringEncoder
/*     */ {
/*     */   static abstract class CologneBuffer
/*     */   {
/*     */     protected final char[] data;
/*     */     protected int length;
/*     */     
/*     */     public CologneBuffer(char[] data) {
/* 197 */       this.data = data;
/* 198 */       this.length = data.length;
/*     */     }
/*     */     
/*     */     public CologneBuffer(int buffSize) {
/* 202 */       this.data = new char[buffSize];
/* 203 */       this.length = 0;
/*     */     }
/*     */     
/*     */     protected abstract char[] copyData(int param1Int1, int param1Int2);
/*     */     
/*     */     public boolean isEmpty() {
/* 209 */       return (length() == 0);
/*     */     }
/*     */     
/*     */     public int length() {
/* 213 */       return this.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 218 */       return new String(copyData(0, this.length));
/*     */     }
/*     */   }
/*     */   
/*     */   private final class CologneInputBuffer extends CologneBuffer {
/*     */     public CologneInputBuffer(char[] data) {
/* 224 */       super(data);
/*     */     }
/*     */ 
/*     */     
/*     */     protected char[] copyData(int start, int length) {
/* 229 */       char[] newData = new char[length];
/* 230 */       System.arraycopy(this.data, this.data.length - this.length + start, newData, 0, length);
/* 231 */       return newData;
/*     */     }
/*     */     
/*     */     public char getNextChar() {
/* 235 */       return this.data[getNextPos()];
/*     */     }
/*     */     
/*     */     protected int getNextPos() {
/* 239 */       return this.data.length - this.length;
/*     */     }
/*     */     
/*     */     public char removeNext() {
/* 243 */       char ch = getNextChar();
/* 244 */       this.length--;
/* 245 */       return ch;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class CologneOutputBuffer extends CologneBuffer {
/*     */     private char lastCode;
/*     */     
/*     */     public CologneOutputBuffer(int buffSize) {
/* 253 */       super(buffSize);
/* 254 */       this.lastCode = '/';
/*     */     }
/*     */ 
/*     */     
/*     */     protected char[] copyData(int start, int length) {
/* 259 */       return Arrays.copyOfRange(this.data, start, length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void put(char code) {
/* 271 */       if (code != '-' && this.lastCode != code && (code != '0' || this.length == 0)) {
/* 272 */         this.data[this.length] = code;
/* 273 */         this.length++;
/*     */       } 
/* 275 */       this.lastCode = code;
/*     */     }
/*     */   }
/*     */   
/* 279 */   private static final char[] AEIJOUY = new char[] { 'A', 'E', 'I', 'J', 'O', 'U', 'Y' };
/* 280 */   private static final char[] CSZ = new char[] { 'C', 'S', 'Z' };
/* 281 */   private static final char[] FPVW = new char[] { 'F', 'P', 'V', 'W' };
/* 282 */   private static final char[] GKQ = new char[] { 'G', 'K', 'Q' };
/* 283 */   private static final char[] CKQ = new char[] { 'C', 'K', 'Q' };
/* 284 */   private static final char[] AHKLOQRUX = new char[] { 'A', 'H', 'K', 'L', 'O', 'Q', 'R', 'U', 'X' };
/*     */   
/* 286 */   private static final char[] SZ = new char[] { 'S', 'Z' };
/*     */   
/* 288 */   private static final char[] AHKOQUX = new char[] { 'A', 'H', 'K', 'O', 'Q', 'U', 'X' };
/*     */   
/* 290 */   private static final char[] DTX = new char[] { 'D', 'T', 'X' };
/*     */ 
/*     */   
/*     */   private static final char CHAR_IGNORE = '-';
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean arrayContains(char[] arr, char key) {
/* 298 */     for (char element : arr) {
/* 299 */       if (element == key) {
/* 300 */         return true;
/*     */       }
/*     */     } 
/* 303 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String colognePhonetic(String text) {
/* 318 */     if (text == null) {
/* 319 */       return null;
/*     */     }
/*     */     
/* 322 */     CologneInputBuffer input = new CologneInputBuffer(preprocess(text));
/* 323 */     CologneOutputBuffer output = new CologneOutputBuffer(input.length() * 2);
/*     */ 
/*     */ 
/*     */     
/* 327 */     char lastChar = '-';
/*     */ 
/*     */     
/* 330 */     while (!input.isEmpty()) {
/* 331 */       char nextChar, chr = input.removeNext();
/*     */       
/* 333 */       if (!input.isEmpty()) {
/* 334 */         nextChar = input.getNextChar();
/*     */       } else {
/* 336 */         nextChar = '-';
/*     */       } 
/*     */       
/* 339 */       if (chr < 'A' || chr > 'Z') {
/*     */         continue;
/*     */       }
/*     */       
/* 343 */       if (arrayContains(AEIJOUY, chr)) {
/* 344 */         output.put('0');
/* 345 */       } else if (chr == 'B' || (chr == 'P' && nextChar != 'H')) {
/* 346 */         output.put('1');
/* 347 */       } else if ((chr == 'D' || chr == 'T') && !arrayContains(CSZ, nextChar)) {
/* 348 */         output.put('2');
/* 349 */       } else if (arrayContains(FPVW, chr)) {
/* 350 */         output.put('3');
/* 351 */       } else if (arrayContains(GKQ, chr)) {
/* 352 */         output.put('4');
/* 353 */       } else if (chr == 'X' && !arrayContains(CKQ, lastChar)) {
/* 354 */         output.put('4');
/* 355 */         output.put('8');
/* 356 */       } else if (chr == 'S' || chr == 'Z') {
/* 357 */         output.put('8');
/* 358 */       } else if (chr == 'C') {
/* 359 */         if (output.isEmpty()) {
/* 360 */           if (arrayContains(AHKLOQRUX, nextChar)) {
/* 361 */             output.put('4');
/*     */           } else {
/* 363 */             output.put('8');
/*     */           } 
/* 365 */         } else if (arrayContains(SZ, lastChar) || !arrayContains(AHKOQUX, nextChar)) {
/* 366 */           output.put('8');
/*     */         } else {
/* 368 */           output.put('4');
/*     */         } 
/* 370 */       } else if (arrayContains(DTX, chr)) {
/* 371 */         output.put('8');
/*     */       } else {
/* 373 */         switch (chr) {
/*     */           case 'R':
/* 375 */             output.put('7');
/*     */             break;
/*     */           case 'L':
/* 378 */             output.put('5');
/*     */             break;
/*     */           case 'M':
/*     */           case 'N':
/* 382 */             output.put('6');
/*     */             break;
/*     */           case 'H':
/* 385 */             output.put('-');
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 392 */       lastChar = chr;
/*     */     } 
/* 394 */     return output.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object encode(Object object) throws EncoderException {
/* 399 */     if (!(object instanceof String)) {
/* 400 */       throw new EncoderException("This method's parameter was expected to be of the type " + String.class
/* 401 */           .getName() + ". But actually it was of the type " + object
/*     */           
/* 403 */           .getClass().getName() + ".");
/*     */     }
/*     */     
/* 406 */     return encode((String)object);
/*     */   }
/*     */ 
/*     */   
/*     */   public String encode(String text) {
/* 411 */     return colognePhonetic(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEncodeEqual(String text1, String text2) {
/* 423 */     return colognePhonetic(text1).equals(colognePhonetic(text2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] preprocess(String text) {
/* 438 */     char[] chrs = text.toUpperCase(Locale.GERMAN).toCharArray();
/*     */     
/* 440 */     for (int index = 0; index < chrs.length; index++) {
/* 441 */       switch (chrs[index]) {
/*     */         case 'Ä':
/* 443 */           chrs[index] = 'A';
/*     */           break;
/*     */         case 'Ü':
/* 446 */           chrs[index] = 'U';
/*     */           break;
/*     */         case 'Ö':
/* 449 */           chrs[index] = 'O';
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 455 */     return chrs;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\ColognePhonetic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */