/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.codec.CodecPolicy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base16
/*     */   extends BaseNCodec
/*     */ {
/*     */   private static final int BITS_PER_ENCODED_BYTE = 4;
/*     */   private static final int BYTES_PER_ENCODED_BLOCK = 2;
/*     */   private static final int BYTES_PER_UNENCODED_BLOCK = 1;
/*  57 */   private static final byte[] UPPER_CASE_DECODE_TABLE = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final byte[] UPPER_CASE_ENCODE_TABLE = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final byte[] LOWER_CASE_DECODE_TABLE = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private static final byte[] LOWER_CASE_ENCODE_TABLE = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MASK_4BITS = 15;
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] decodeTable;
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] encodeTable;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base16() {
/* 112 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base16(boolean lowerCase) {
/* 121 */     this(lowerCase, DECODING_POLICY_DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Base16(boolean lowerCase, byte[] encodeTable, CodecPolicy decodingPolicy) {
/* 132 */     super(1, 2, 0, 0, (byte)61, decodingPolicy);
/* 133 */     Objects.requireNonNull(encodeTable, "encodeTable");
/* 134 */     this.encodeTable = encodeTable;
/* 135 */     this.decodeTable = (encodeTable == LOWER_CASE_ENCODE_TABLE) ? LOWER_CASE_DECODE_TABLE : UPPER_CASE_DECODE_TABLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base16(boolean lowerCase, CodecPolicy decodingPolicy) {
/* 145 */     this(lowerCase, lowerCase ? LOWER_CASE_ENCODE_TABLE : UPPER_CASE_ENCODE_TABLE, decodingPolicy);
/*     */   }
/*     */ 
/*     */   
/*     */   void decode(byte[] data, int offset, int length, BaseNCodec.Context context) {
/* 150 */     if (context.eof || length < 0) {
/* 151 */       context.eof = true;
/* 152 */       if (context.ibitWorkArea != 0) {
/* 153 */         validateTrailingCharacter();
/*     */       }
/*     */       return;
/*     */     } 
/* 157 */     int dataLen = Math.min(data.length - offset, length);
/* 158 */     int availableChars = ((context.ibitWorkArea != 0) ? 1 : 0) + dataLen;
/*     */     
/* 160 */     if (availableChars == 1 && availableChars == dataLen) {
/*     */       
/* 162 */       context.ibitWorkArea = decodeOctet(data[offset]) + 1;
/*     */       
/*     */       return;
/*     */     } 
/* 166 */     int charsToProcess = (availableChars % 2 == 0) ? availableChars : (availableChars - 1);
/* 167 */     int end = offset + dataLen;
/* 168 */     byte[] buffer = ensureBufferSize(charsToProcess / 2, context);
/*     */     
/* 170 */     if (dataLen < availableChars) {
/*     */       
/* 172 */       int result = context.ibitWorkArea - 1 << 4;
/* 173 */       result |= decodeOctet(data[offset++]);
/* 174 */       buffer[context.pos++] = (byte)result;
/*     */       
/* 176 */       context.ibitWorkArea = 0;
/*     */     } 
/* 178 */     int loopEnd = end - 1;
/* 179 */     while (offset < loopEnd) {
/* 180 */       int result = decodeOctet(data[offset++]) << 4;
/* 181 */       result |= decodeOctet(data[offset++]);
/* 182 */       buffer[context.pos++] = (byte)result;
/*     */     } 
/*     */     
/* 185 */     if (offset < end)
/*     */     {
/* 187 */       context.ibitWorkArea = decodeOctet(data[offset]) + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private int decodeOctet(byte octet) {
/* 192 */     int decoded = -1;
/* 193 */     if ((octet & 0xFF) < this.decodeTable.length) {
/* 194 */       decoded = this.decodeTable[octet];
/*     */     }
/* 196 */     if (decoded == -1) {
/* 197 */       throw new IllegalArgumentException("Invalid octet in encoded value: " + octet);
/*     */     }
/* 199 */     return decoded;
/*     */   }
/*     */ 
/*     */   
/*     */   void encode(byte[] data, int offset, int length, BaseNCodec.Context context) {
/* 204 */     if (context.eof) {
/*     */       return;
/*     */     }
/* 207 */     if (length < 0) {
/* 208 */       context.eof = true;
/*     */       return;
/*     */     } 
/* 211 */     int size = length * 2;
/* 212 */     if (size < 0) {
/* 213 */       throw new IllegalArgumentException("Input length exceeds maximum size for encoded data: " + length);
/*     */     }
/* 215 */     byte[] buffer = ensureBufferSize(size, context);
/* 216 */     int end = offset + length;
/* 217 */     for (int i = offset; i < end; i++) {
/* 218 */       int value = data[i];
/* 219 */       int high = value >> 4 & 0xF;
/* 220 */       int low = value & 0xF;
/* 221 */       buffer[context.pos++] = this.encodeTable[high];
/* 222 */       buffer[context.pos++] = this.encodeTable[low];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInAlphabet(byte octet) {
/* 235 */     return ((octet & 0xFF) < this.decodeTable.length && this.decodeTable[octet] != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateTrailingCharacter() {
/* 244 */     if (isStrictDecoding())
/* 245 */       throw new IllegalArgumentException("Strict decoding: Last encoded character is a valid base 16 alphabet character but not a possible encoding. Decoding requires at least two characters to create one byte."); 
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\binary\Base16.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */