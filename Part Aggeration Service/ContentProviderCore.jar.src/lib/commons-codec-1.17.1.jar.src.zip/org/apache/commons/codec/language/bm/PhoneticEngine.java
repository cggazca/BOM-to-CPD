/*     */ package org.apache.commons.codec.language.bm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PhoneticEngine
/*     */ {
/*     */   private static final int DEFAULT_MAX_PHONEMES = 20;
/*     */   
/*     */   static final class PhonemeBuilder
/*     */   {
/*     */     private final Set<Rule.Phoneme> phonemes;
/*     */     
/*     */     public static PhonemeBuilder empty(Languages.LanguageSet languages) {
/*  75 */       return new PhonemeBuilder(new Rule.Phoneme("", languages));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private PhonemeBuilder(Rule.Phoneme phoneme) {
/*  81 */       this.phonemes = new LinkedHashSet<>();
/*  82 */       this.phonemes.add(phoneme);
/*     */     }
/*     */     
/*     */     private PhonemeBuilder(Set<Rule.Phoneme> phonemes) {
/*  86 */       this.phonemes = phonemes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void append(CharSequence str) {
/*  95 */       this.phonemes.forEach(ph -> ph.append(str));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(Rule.PhonemeExpr phonemeExpr, int maxPhonemes) {
/* 109 */       Set<Rule.Phoneme> newPhonemes = new LinkedHashSet<>(Math.min(this.phonemes.size() * phonemeExpr.size(), maxPhonemes));
/* 110 */       label18: for (Rule.Phoneme left : this.phonemes) {
/* 111 */         for (Rule.Phoneme right : phonemeExpr.getPhonemes()) {
/* 112 */           Languages.LanguageSet languages = left.getLanguages().restrictTo(right.getLanguages());
/* 113 */           if (!languages.isEmpty()) {
/* 114 */             Rule.Phoneme join = new Rule.Phoneme(left, right, languages);
/* 115 */             if (newPhonemes.size() < maxPhonemes) {
/* 116 */               newPhonemes.add(join);
/* 117 */               if (newPhonemes.size() >= maxPhonemes) {
/*     */                 break label18;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 124 */       this.phonemes.clear();
/* 125 */       this.phonemes.addAll(newPhonemes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<Rule.Phoneme> getPhonemes() {
/* 134 */       return this.phonemes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String makeString() {
/* 145 */       return this.phonemes.stream().map(Rule.Phoneme::getPhonemeText).collect(Collectors.joining("|"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class RulesApplication
/*     */   {
/*     */     private final Map<String, List<Rule>> finalRules;
/*     */ 
/*     */     
/*     */     private final CharSequence input;
/*     */ 
/*     */     
/*     */     private final PhoneticEngine.PhonemeBuilder phonemeBuilder;
/*     */ 
/*     */     
/*     */     private int i;
/*     */ 
/*     */     
/*     */     private final int maxPhonemes;
/*     */ 
/*     */     
/*     */     private boolean found;
/*     */ 
/*     */ 
/*     */     
/*     */     public RulesApplication(Map<String, List<Rule>> finalRules, CharSequence input, PhoneticEngine.PhonemeBuilder phonemeBuilder, int i, int maxPhonemes) {
/* 174 */       Objects.requireNonNull(finalRules, "finalRules");
/* 175 */       this.finalRules = finalRules;
/* 176 */       this.phonemeBuilder = phonemeBuilder;
/* 177 */       this.input = input;
/* 178 */       this.i = i;
/* 179 */       this.maxPhonemes = maxPhonemes;
/*     */     }
/*     */     
/*     */     public int getI() {
/* 183 */       return this.i;
/*     */     }
/*     */     
/*     */     public PhoneticEngine.PhonemeBuilder getPhonemeBuilder() {
/* 187 */       return this.phonemeBuilder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RulesApplication invoke() {
/* 198 */       this.found = false;
/* 199 */       int patternLength = 1;
/* 200 */       List<Rule> rules = this.finalRules.get(this.input.subSequence(this.i, this.i + patternLength));
/* 201 */       if (rules != null) {
/* 202 */         for (Rule rule : rules) {
/* 203 */           String pattern = rule.getPattern();
/* 204 */           patternLength = pattern.length();
/* 205 */           if (rule.patternAndContextMatches(this.input, this.i)) {
/* 206 */             this.phonemeBuilder.apply(rule.getPhoneme(), this.maxPhonemes);
/* 207 */             this.found = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 213 */       if (!this.found) {
/* 214 */         patternLength = 1;
/*     */       }
/*     */       
/* 217 */       this.i += patternLength;
/* 218 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isFound() {
/* 222 */       return this.found;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 228 */   private static final Map<NameType, Set<String>> NAME_PREFIXES = new EnumMap<>(NameType.class);
/*     */   
/*     */   static {
/* 231 */     NAME_PREFIXES.put(NameType.ASHKENAZI, 
/* 232 */         Collections.unmodifiableSet(new HashSet<>(
/* 233 */             Arrays.asList(new String[] { "bar", "ben", "da", "de", "van", "von" }))));
/* 234 */     NAME_PREFIXES.put(NameType.SEPHARDIC, 
/* 235 */         Collections.unmodifiableSet(new HashSet<>(
/* 236 */             Arrays.asList(new String[] { 
/*     */                 "al", "el", "da", "dal", "de", "del", "dela", "de la", "della", "des", 
/* 238 */                 "di", "do", "dos", "du", "van", "von" })))); NAME_PREFIXES.put(NameType.GENERIC, 
/* 239 */         Collections.unmodifiableSet(new HashSet<>(
/* 240 */             Arrays.asList(new String[] { 
/*     */                 "da", "dal", "de", "del", "dela", "de la", "della", "des", "di", "do", 
/*     */                 "dos", "du", "van", "von" }))));
/*     */   }
/*     */   
/*     */   private final Lang lang;
/*     */   private final NameType nameType;
/*     */   private final RuleType ruleType;
/*     */   private final boolean concat;
/*     */   private final int maxPhonemes;
/*     */   
/*     */   private static String join(List<String> strings, String sep) {
/* 252 */     return strings.stream().collect(Collectors.joining(sep));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PhoneticEngine(NameType nameType, RuleType ruleType, boolean concatenate) {
/* 276 */     this(nameType, ruleType, concatenate, 20);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PhoneticEngine(NameType nameType, RuleType ruleType, boolean concatenate, int maxPhonemes) {
/* 293 */     if (ruleType == RuleType.RULES) {
/* 294 */       throw new IllegalArgumentException("ruleType must not be " + RuleType.RULES);
/*     */     }
/* 296 */     this.nameType = nameType;
/* 297 */     this.ruleType = ruleType;
/* 298 */     this.concat = concatenate;
/* 299 */     this.lang = Lang.instance(nameType);
/* 300 */     this.maxPhonemes = maxPhonemes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PhonemeBuilder applyFinalRules(PhonemeBuilder phonemeBuilder, Map<String, List<Rule>> finalRules) {
/* 313 */     Objects.requireNonNull(finalRules, "finalRules");
/* 314 */     if (finalRules.isEmpty()) {
/* 315 */       return phonemeBuilder;
/*     */     }
/*     */     
/* 318 */     Map<Rule.Phoneme, Rule.Phoneme> phonemes = new TreeMap<>(Rule.Phoneme.COMPARATOR);
/*     */     
/* 320 */     phonemeBuilder.getPhonemes().forEach(phoneme -> {
/*     */           PhonemeBuilder subBuilder = PhonemeBuilder.empty(phoneme.getLanguages());
/*     */ 
/*     */ 
/*     */           
/*     */           String phonemeText = phoneme.getPhonemeText().toString();
/*     */ 
/*     */           
/*     */           int i;
/*     */ 
/*     */           
/*     */           for (i = 0; i < phonemeText.length(); i = rulesApplication.getI()) {
/*     */             RulesApplication rulesApplication = (new RulesApplication(finalRules, phonemeText, subBuilder, i, this.maxPhonemes)).invoke();
/*     */ 
/*     */             
/*     */             boolean found = rulesApplication.isFound();
/*     */ 
/*     */             
/*     */             subBuilder = rulesApplication.getPhonemeBuilder();
/*     */ 
/*     */             
/*     */             if (!found) {
/*     */               subBuilder.append(phonemeText.subSequence(i, i + 1));
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/*     */           subBuilder.getPhonemes().forEach(());
/*     */         });
/*     */ 
/*     */     
/* 351 */     return new PhonemeBuilder(phonemes.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String input) {
/* 362 */     Languages.LanguageSet languageSet = this.lang.guessLanguages(input);
/* 363 */     return encode(input, languageSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String input, Languages.LanguageSet languageSet) {
/* 377 */     Map<String, List<Rule>> rules = Rule.getInstanceMap(this.nameType, RuleType.RULES, languageSet);
/*     */     
/* 379 */     Map<String, List<Rule>> finalRules1 = Rule.getInstanceMap(this.nameType, this.ruleType, "common");
/*     */     
/* 381 */     Map<String, List<Rule>> finalRules2 = Rule.getInstanceMap(this.nameType, this.ruleType, languageSet);
/*     */ 
/*     */ 
/*     */     
/* 385 */     input = input.toLowerCase(Locale.ENGLISH).replace('-', ' ').trim();
/*     */     
/* 387 */     if (this.nameType == NameType.GENERIC) {
/* 388 */       if (input.startsWith("d'")) {
/* 389 */         String remainder = input.substring(2);
/* 390 */         String combined = "d" + remainder;
/* 391 */         return "(" + encode(remainder) + ")-(" + encode(combined) + ")";
/*     */       } 
/* 393 */       for (String l : NAME_PREFIXES.get(this.nameType)) {
/*     */         
/* 395 */         if (input.startsWith(l + " ")) {
/*     */           
/* 397 */           String remainder = input.substring(l.length() + 1);
/* 398 */           String combined = l + remainder;
/* 399 */           return "(" + encode(remainder) + ")-(" + encode(combined) + ")";
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 404 */     List<String> words = Arrays.asList(input.split("\\s+"));
/* 405 */     List<String> words2 = new ArrayList<>();
/*     */ 
/*     */     
/* 408 */     switch (this.nameType) {
/*     */       case SEPHARDIC:
/* 410 */         words.forEach(aWord -> {
/*     */               String[] parts = aWord.split("'", -1);
/*     */               words2.add(parts[parts.length - 1]);
/*     */             });
/* 414 */         words2.removeAll(NAME_PREFIXES.get(this.nameType));
/*     */         break;
/*     */       case ASHKENAZI:
/* 417 */         words2.addAll(words);
/* 418 */         words2.removeAll(NAME_PREFIXES.get(this.nameType));
/*     */         break;
/*     */       case GENERIC:
/* 421 */         words2.addAll(words);
/*     */         break;
/*     */       default:
/* 424 */         throw new IllegalStateException("Unreachable case: " + this.nameType);
/*     */     } 
/*     */     
/* 427 */     if (this.concat) {
/*     */       
/* 429 */       input = join(words2, " ");
/* 430 */     } else if (words2.size() == 1) {
/*     */       
/* 432 */       input = words.iterator().next();
/* 433 */     } else if (!words2.isEmpty()) {
/*     */       
/* 435 */       StringBuilder result = new StringBuilder();
/* 436 */       words2.forEach(word -> result.append("-").append(encode(word)));
/*     */       
/* 438 */       return result.substring(1);
/*     */     } 
/*     */     
/* 441 */     PhonemeBuilder phonemeBuilder = PhonemeBuilder.empty(languageSet);
/*     */ 
/*     */     
/* 444 */     for (int i = 0; i < input.length(); ) {
/*     */       
/* 446 */       RulesApplication rulesApplication = (new RulesApplication(rules, input, phonemeBuilder, i, this.maxPhonemes)).invoke();
/* 447 */       i = rulesApplication.getI();
/* 448 */       phonemeBuilder = rulesApplication.getPhonemeBuilder();
/*     */     } 
/*     */ 
/*     */     
/* 452 */     phonemeBuilder = applyFinalRules(phonemeBuilder, finalRules1);
/*     */     
/* 454 */     phonemeBuilder = applyFinalRules(phonemeBuilder, finalRules2);
/*     */     
/* 456 */     return phonemeBuilder.makeString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lang getLang() {
/* 465 */     return this.lang;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxPhonemes() {
/* 475 */     return this.maxPhonemes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameType getNameType() {
/* 484 */     return this.nameType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleType getRuleType() {
/* 493 */     return this.ruleType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConcat() {
/* 502 */     return this.concat;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\bm\PhoneticEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */