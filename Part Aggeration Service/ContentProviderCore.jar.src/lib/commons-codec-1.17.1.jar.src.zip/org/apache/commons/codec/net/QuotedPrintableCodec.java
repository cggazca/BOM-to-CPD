/*     */ package org.apache.commons.codec.net;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.BitSet;
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringDecoder;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ import org.apache.commons.codec.binary.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuotedPrintableCodec
/*     */   implements BinaryEncoder, BinaryDecoder, StringEncoder, StringDecoder
/*     */ {
/*  75 */   private static final BitSet PRINTABLE_CHARS = new BitSet(256);
/*     */ 
/*     */   
/*     */   private static final byte ESCAPE_CHAR = 61;
/*     */ 
/*     */   
/*     */   private static final byte TAB = 9;
/*     */   
/*     */   private static final byte SPACE = 32;
/*     */   
/*     */   private static final byte CR = 13;
/*     */   
/*     */   private static final byte LF = 10;
/*     */   
/*     */   private static final int MIN_BYTES = 3;
/*     */   
/*     */   private static final int SAFE_LENGTH = 73;
/*     */   
/*     */   private final Charset charset;
/*     */   
/*     */   private final boolean strict;
/*     */ 
/*     */   
/*     */   static {
/*     */     int i;
/* 100 */     for (i = 33; i <= 60; i++) {
/* 101 */       PRINTABLE_CHARS.set(i);
/*     */     }
/* 103 */     for (i = 62; i <= 126; i++) {
/* 104 */       PRINTABLE_CHARS.set(i);
/*     */     }
/* 106 */     PRINTABLE_CHARS.set(9);
/* 107 */     PRINTABLE_CHARS.set(32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[] decodeQuotedPrintable(byte[] bytes) throws DecoderException {
/* 125 */     if (bytes == null) {
/* 126 */       return null;
/*     */     }
/* 128 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 129 */     for (int i = 0; i < bytes.length; i++) {
/* 130 */       int b = bytes[i];
/* 131 */       if (b == 61) {
/*     */         
/*     */         try {
/* 134 */           if (bytes[++i] != 13)
/*     */           
/*     */           { 
/* 137 */             int u = Utils.digit16(bytes[i]);
/* 138 */             int l = Utils.digit16(bytes[++i]);
/* 139 */             buffer.write((char)((u << 4) + l)); } 
/* 140 */         } catch (ArrayIndexOutOfBoundsException e) {
/* 141 */           throw new DecoderException("Invalid quoted-printable encoding", e);
/*     */         } 
/* 143 */       } else if (b != 13 && b != 10) {
/*     */         
/* 145 */         buffer.write(b);
/*     */       } 
/*     */     } 
/* 148 */     return buffer.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int encodeByte(int b, boolean encode, ByteArrayOutputStream buffer) {
/* 163 */     if (encode) {
/* 164 */       return encodeQuotedPrintable(b, buffer);
/*     */     }
/* 166 */     buffer.write(b);
/* 167 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[] encodeQuotedPrintable(BitSet printable, byte[] bytes) {
/* 184 */     return encodeQuotedPrintable(printable, bytes, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[] encodeQuotedPrintable(BitSet printable, byte[] bytes, boolean strict) {
/* 205 */     if (bytes == null) {
/* 206 */       return null;
/*     */     }
/* 208 */     if (printable == null) {
/* 209 */       printable = PRINTABLE_CHARS;
/*     */     }
/* 211 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 212 */     int bytesLength = bytes.length;
/*     */     
/* 214 */     if (strict) {
/* 215 */       if (bytesLength < 3) {
/* 216 */         return null;
/*     */       }
/*     */       
/* 219 */       int pos = 1;
/*     */ 
/*     */       
/* 222 */       for (int i = 0; i < bytesLength - 3; i++) {
/* 223 */         int k = getUnsignedOctet(i, bytes);
/* 224 */         if (pos < 73) {
/*     */           
/* 226 */           pos += encodeByte(k, !printable.get(k), buffer);
/*     */         } else {
/*     */           
/* 229 */           encodeByte(k, (!printable.get(k) || isWhitespace(k)), buffer);
/*     */ 
/*     */           
/* 232 */           buffer.write(61);
/* 233 */           buffer.write(13);
/* 234 */           buffer.write(10);
/* 235 */           pos = 1;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 241 */       int b = getUnsignedOctet(bytesLength - 3, bytes);
/* 242 */       boolean encode = (!printable.get(b) || (isWhitespace(b) && pos > 68));
/* 243 */       pos += encodeByte(b, encode, buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       if (pos > 71) {
/* 249 */         buffer.write(61);
/* 250 */         buffer.write(13);
/* 251 */         buffer.write(10);
/*     */       } 
/* 253 */       for (int j = bytesLength - 2; j < bytesLength; j++) {
/* 254 */         b = getUnsignedOctet(j, bytes);
/*     */         
/* 256 */         encode = (!printable.get(b) || (j > bytesLength - 2 && isWhitespace(b)));
/* 257 */         encodeByte(b, encode, buffer);
/*     */       } 
/*     */     } else {
/* 260 */       for (byte c : bytes) {
/* 261 */         int b = c;
/* 262 */         if (b < 0) {
/* 263 */           b = 256 + b;
/*     */         }
/* 265 */         if (printable.get(b)) {
/* 266 */           buffer.write(b);
/*     */         } else {
/* 268 */           encodeQuotedPrintable(b, buffer);
/*     */         } 
/*     */       } 
/*     */     } 
/* 272 */     return buffer.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int encodeQuotedPrintable(int b, ByteArrayOutputStream buffer) {
/* 285 */     buffer.write(61);
/* 286 */     char hex1 = Utils.hexDigit(b >> 4);
/* 287 */     char hex2 = Utils.hexDigit(b);
/* 288 */     buffer.write(hex1);
/* 289 */     buffer.write(hex2);
/* 290 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getUnsignedOctet(int index, byte[] bytes) {
/* 304 */     int b = bytes[index];
/* 305 */     if (b < 0) {
/* 306 */       b = 256 + b;
/*     */     }
/* 308 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isWhitespace(int b) {
/* 319 */     return (b == 32 || b == 9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuotedPrintableCodec() {
/* 336 */     this(StandardCharsets.UTF_8, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuotedPrintableCodec(boolean strict) {
/* 347 */     this(StandardCharsets.UTF_8, strict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuotedPrintableCodec(Charset charset) {
/* 358 */     this(charset, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuotedPrintableCodec(Charset charset, boolean strict) {
/* 371 */     this.charset = charset;
/* 372 */     this.strict = strict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuotedPrintableCodec(String charsetName) throws IllegalCharsetNameException, IllegalArgumentException, UnsupportedCharsetException {
/* 391 */     this(Charset.forName(charsetName), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] bytes) throws DecoderException {
/* 410 */     return decodeQuotedPrintable(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(Object obj) throws DecoderException {
/* 426 */     if (obj == null) {
/* 427 */       return null;
/*     */     }
/* 429 */     if (obj instanceof byte[]) {
/* 430 */       return decode((byte[])obj);
/*     */     }
/* 432 */     if (obj instanceof String) {
/* 433 */       return decode((String)obj);
/*     */     }
/* 435 */     throw new DecoderException("Objects of type " + obj.getClass().getName() + " cannot be quoted-printable decoded");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decode(String sourceStr) throws DecoderException {
/* 451 */     return decode(sourceStr, getCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decode(String sourceStr, Charset sourceCharset) throws DecoderException {
/* 468 */     if (sourceStr == null) {
/* 469 */       return null;
/*     */     }
/* 471 */     return new String(decode(StringUtils.getBytesUsAscii(sourceStr)), sourceCharset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decode(String sourceStr, String sourceCharset) throws DecoderException, UnsupportedEncodingException {
/* 489 */     if (sourceStr == null) {
/* 490 */       return null;
/*     */     }
/* 492 */     return new String(decode(StringUtils.getBytesUsAscii(sourceStr)), sourceCharset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encode(byte[] bytes) {
/* 509 */     return encodeQuotedPrintable(PRINTABLE_CHARS, bytes, this.strict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 524 */     if (obj == null) {
/* 525 */       return null;
/*     */     }
/* 527 */     if (obj instanceof byte[]) {
/* 528 */       return encode((byte[])obj);
/*     */     }
/* 530 */     if (obj instanceof String) {
/* 531 */       return encode((String)obj);
/*     */     }
/* 533 */     throw new EncoderException("Objects of type " + obj.getClass().getName() + " cannot be quoted-printable encoded");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String sourceStr) throws EncoderException {
/* 554 */     return encode(sourceStr, getCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String sourceStr, Charset sourceCharset) {
/* 573 */     if (sourceStr == null) {
/* 574 */       return null;
/*     */     }
/* 576 */     return StringUtils.newStringUsAscii(encode(sourceStr.getBytes(sourceCharset)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String sourceStr, String sourceCharset) throws UnsupportedEncodingException {
/* 596 */     if (sourceStr == null) {
/* 597 */       return null;
/*     */     }
/* 599 */     return StringUtils.newStringUsAscii(encode(sourceStr.getBytes(sourceCharset)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/* 609 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/* 618 */     return this.charset.name();
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\net\QuotedPrintableCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */