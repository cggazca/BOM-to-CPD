/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryCodec
/*     */   implements BinaryDecoder, BinaryEncoder
/*     */ {
/*  41 */   private static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*     */ 
/*     */   
/*  44 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */ 
/*     */   
/*     */   private static final int BIT_0 = 1;
/*     */ 
/*     */   
/*     */   private static final int BIT_1 = 2;
/*     */ 
/*     */   
/*     */   private static final int BIT_2 = 4;
/*     */ 
/*     */   
/*     */   private static final int BIT_3 = 8;
/*     */ 
/*     */   
/*     */   private static final int BIT_4 = 16;
/*     */ 
/*     */   
/*     */   private static final int BIT_5 = 32;
/*     */ 
/*     */   
/*     */   private static final int BIT_6 = 64;
/*     */ 
/*     */   
/*     */   private static final int BIT_7 = 128;
/*     */   
/*  70 */   private static final int[] BITS = new int[] { 1, 2, 4, 8, 16, 32, 64, 128 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] fromAscii(byte[] ascii) {
/*  80 */     if (isEmpty(ascii)) {
/*  81 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*  83 */     int asciiLength = ascii.length;
/*     */     
/*  85 */     byte[] raw = new byte[asciiLength >> 3];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     for (int ii = 0, jj = asciiLength - 1; ii < raw.length; ii++, jj -= 8) {
/*  91 */       for (int bits = 0; bits < BITS.length; bits++) {
/*  92 */         if (ascii[jj - bits] == 49) {
/*  93 */           raw[ii] = (byte)(raw[ii] | BITS[bits]);
/*     */         }
/*     */       } 
/*     */     } 
/*  97 */     return raw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] fromAscii(char[] ascii) {
/* 108 */     if (ascii == null || ascii.length == 0) {
/* 109 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 111 */     int asciiLength = ascii.length;
/*     */     
/* 113 */     byte[] raw = new byte[asciiLength >> 3];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     for (int ii = 0, jj = asciiLength - 1; ii < raw.length; ii++, jj -= 8) {
/* 119 */       for (int bits = 0; bits < BITS.length; bits++) {
/* 120 */         if (ascii[jj - bits] == '1') {
/* 121 */           raw[ii] = (byte)(raw[ii] | BITS[bits]);
/*     */         }
/*     */       } 
/*     */     } 
/* 125 */     return raw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEmpty(byte[] array) {
/* 136 */     return (array == null || array.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toAsciiBytes(byte[] raw) {
/* 149 */     if (isEmpty(raw)) {
/* 150 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 152 */     int rawLength = raw.length;
/*     */     
/* 154 */     byte[] l_ascii = new byte[rawLength << 3];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     for (int ii = 0, jj = l_ascii.length - 1; ii < rawLength; ii++, jj -= 8) {
/* 160 */       for (int bits = 0; bits < BITS.length; bits++) {
/* 161 */         if ((raw[ii] & BITS[bits]) == 0) {
/* 162 */           l_ascii[jj - bits] = 48;
/*     */         } else {
/* 164 */           l_ascii[jj - bits] = 49;
/*     */         } 
/*     */       } 
/*     */     } 
/* 168 */     return l_ascii;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] toAsciiChars(byte[] raw) {
/* 180 */     if (isEmpty(raw)) {
/* 181 */       return EMPTY_CHAR_ARRAY;
/*     */     }
/* 183 */     int rawLength = raw.length;
/*     */     
/* 185 */     char[] l_ascii = new char[rawLength << 3];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     for (int ii = 0, jj = l_ascii.length - 1; ii < rawLength; ii++, jj -= 8) {
/* 191 */       for (int bits = 0; bits < BITS.length; bits++) {
/* 192 */         if ((raw[ii] & BITS[bits]) == 0) {
/* 193 */           l_ascii[jj - bits] = '0';
/*     */         } else {
/* 195 */           l_ascii[jj - bits] = '1';
/*     */         } 
/*     */       } 
/*     */     } 
/* 199 */     return l_ascii;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toAsciiString(byte[] raw) {
/* 211 */     return new String(toAsciiChars(raw));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] ascii) {
/* 224 */     return fromAscii(ascii);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(Object ascii) throws DecoderException {
/* 239 */     if (ascii == null) {
/* 240 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 242 */     if (ascii instanceof byte[]) {
/* 243 */       return fromAscii((byte[])ascii);
/*     */     }
/* 245 */     if (ascii instanceof char[]) {
/* 246 */       return fromAscii((char[])ascii);
/*     */     }
/* 248 */     if (ascii instanceof String) {
/* 249 */       return fromAscii(((String)ascii).toCharArray());
/*     */     }
/* 251 */     throw new DecoderException("argument not a byte array");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encode(byte[] raw) {
/* 264 */     return toAsciiBytes(raw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object raw) throws EncoderException {
/* 279 */     if (!(raw instanceof byte[])) {
/* 280 */       throw new EncoderException("argument not a byte array");
/*     */     }
/* 282 */     return toAsciiChars((byte[])raw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toByteArray(String ascii) {
/* 294 */     if (ascii == null) {
/* 295 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 297 */     return fromAscii(ascii.toCharArray());
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\binary\BinaryCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */