/*     */ package org.apache.commons.codec.net;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.BitSet;
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PercentCodec
/*     */   implements BinaryEncoder, BinaryDecoder
/*     */ {
/*     */   private static final byte ESCAPE_CHAR = 37;
/*  50 */   private final BitSet alwaysEncodeChars = new BitSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean plusForSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int alwaysEncodeCharsMin = Integer.MAX_VALUE, alwaysEncodeCharsMax = Integer.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec() {
/*  68 */     this.plusForSpace = false;
/*  69 */     insertAlwaysEncodeChar((byte)37);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec(byte[] alwaysEncodeChars, boolean plusForSpace) {
/*  81 */     this.plusForSpace = plusForSpace;
/*  82 */     insertAlwaysEncodeChars(alwaysEncodeChars);
/*     */   }
/*     */   
/*     */   private boolean canEncode(byte c) {
/*  86 */     return (!isAsciiChar(c) || (inAlwaysEncodeCharsRange(c) && this.alwaysEncodeChars.get(c)));
/*     */   }
/*     */   
/*     */   private boolean containsSpace(byte[] bytes) {
/*  90 */     for (byte b : bytes) {
/*  91 */       if (b == 32) {
/*  92 */         return true;
/*     */       }
/*     */     } 
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] bytes) throws DecoderException {
/* 104 */     if (bytes == null) {
/* 105 */       return null;
/*     */     }
/* 107 */     ByteBuffer buffer = ByteBuffer.allocate(expectedDecodingBytes(bytes));
/* 108 */     for (int i = 0; i < bytes.length; i++) {
/* 109 */       byte b = bytes[i];
/* 110 */       if (b == 37) {
/*     */         try {
/* 112 */           int u = Utils.digit16(bytes[++i]);
/* 113 */           int l = Utils.digit16(bytes[++i]);
/* 114 */           buffer.put((byte)((u << 4) + l));
/* 115 */         } catch (ArrayIndexOutOfBoundsException e) {
/* 116 */           throw new DecoderException("Invalid percent decoding: ", e);
/*     */         } 
/* 118 */       } else if (this.plusForSpace && b == 43) {
/* 119 */         buffer.put((byte)32);
/*     */       } else {
/* 121 */         buffer.put(b);
/*     */       } 
/*     */     } 
/* 124 */     return buffer.array();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(Object obj) throws DecoderException {
/* 136 */     if (obj == null) {
/* 137 */       return null;
/*     */     }
/* 139 */     if (obj instanceof byte[]) {
/* 140 */       return decode((byte[])obj);
/*     */     }
/* 142 */     throw new DecoderException("Objects of type " + obj.getClass().getName() + " cannot be Percent decoded");
/*     */   }
/*     */   
/*     */   private byte[] doEncode(byte[] bytes, int expectedLength, boolean willEncode) {
/* 146 */     ByteBuffer buffer = ByteBuffer.allocate(expectedLength);
/* 147 */     for (byte b : bytes) {
/* 148 */       if (willEncode && canEncode(b)) {
/* 149 */         byte bb = b;
/* 150 */         if (bb < 0) {
/* 151 */           bb = (byte)(256 + bb);
/*     */         }
/* 153 */         char hex1 = Utils.hexDigit(bb >> 4);
/* 154 */         char hex2 = Utils.hexDigit(bb);
/* 155 */         buffer.put((byte)37);
/* 156 */         buffer.put((byte)hex1);
/* 157 */         buffer.put((byte)hex2);
/* 158 */       } else if (this.plusForSpace && b == 32) {
/* 159 */         buffer.put((byte)43);
/*     */       } else {
/* 161 */         buffer.put(b);
/*     */       } 
/*     */     } 
/* 164 */     return buffer.array();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encode(byte[] bytes) throws EncoderException {
/* 173 */     if (bytes == null) {
/* 174 */       return null;
/*     */     }
/* 176 */     int expectedEncodingBytes = expectedEncodingBytes(bytes);
/* 177 */     boolean willEncode = (expectedEncodingBytes != bytes.length);
/* 178 */     if (willEncode || (this.plusForSpace && containsSpace(bytes))) {
/* 179 */       return doEncode(bytes, expectedEncodingBytes, willEncode);
/*     */     }
/* 181 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 193 */     if (obj == null) {
/* 194 */       return null;
/*     */     }
/* 196 */     if (obj instanceof byte[]) {
/* 197 */       return encode((byte[])obj);
/*     */     }
/* 199 */     throw new EncoderException("Objects of type " + obj.getClass().getName() + " cannot be Percent encoded");
/*     */   }
/*     */   
/*     */   private int expectedDecodingBytes(byte[] bytes) {
/* 203 */     int byteCount = 0;
/* 204 */     for (int i = 0; i < bytes.length; ) {
/* 205 */       byte b = bytes[i];
/* 206 */       i += (b == 37) ? 3 : 1;
/* 207 */       byteCount++;
/*     */     } 
/* 209 */     return byteCount;
/*     */   }
/*     */   
/*     */   private int expectedEncodingBytes(byte[] bytes) {
/* 213 */     int byteCount = 0;
/* 214 */     for (byte b : bytes) {
/* 215 */       byteCount += canEncode(b) ? 3 : 1;
/*     */     }
/* 217 */     return byteCount;
/*     */   }
/*     */   
/*     */   private boolean inAlwaysEncodeCharsRange(byte c) {
/* 221 */     return (c >= this.alwaysEncodeCharsMin && c <= this.alwaysEncodeCharsMax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertAlwaysEncodeChar(byte b) {
/* 231 */     if (b < 0) {
/* 232 */       throw new IllegalArgumentException("byte must be >= 0");
/*     */     }
/* 234 */     this.alwaysEncodeChars.set(b);
/* 235 */     if (b < this.alwaysEncodeCharsMin) {
/* 236 */       this.alwaysEncodeCharsMin = b;
/*     */     }
/* 238 */     if (b > this.alwaysEncodeCharsMax) {
/* 239 */       this.alwaysEncodeCharsMax = b;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertAlwaysEncodeChars(byte[] alwaysEncodeCharsArray) {
/* 249 */     if (alwaysEncodeCharsArray != null) {
/* 250 */       for (byte b : alwaysEncodeCharsArray) {
/* 251 */         insertAlwaysEncodeChar(b);
/*     */       }
/*     */     }
/* 254 */     insertAlwaysEncodeChar((byte)37);
/*     */   }
/*     */   
/*     */   private boolean isAsciiChar(byte c) {
/* 258 */     return (c >= 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\net\PercentCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */