/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MatchRatingApproachEncoder
/*     */   implements StringEncoder
/*     */ {
/*     */   private static final String SPACE = " ";
/*     */   private static final String EMPTY = "";
/*     */   private static final String PLAIN_ASCII = "AaEeIiOoUuAaEeIiOoUuYyAaEeIiOoUuYyAaOoNnAaEeIiOoUuYyAaCcOoUu";
/*     */   private static final String UNICODE = "ÀàÈèÌìÒòÙùÁáÉéÍíÓóÚúÝýÂâÊêÎîÔôÛûŶŷÃãÕõÑñÄäËëÏïÖöÜüŸÿÅåÇçŐőŰű";
/*  61 */   private static final String[] DOUBLE_CONSONANT = new String[] { "BB", "CC", "DD", "FF", "GG", "HH", "JJ", "KK", "LL", "MM", "NN", "PP", "QQ", "RR", "SS", "TT", "VV", "WW", "XX", "YY", "ZZ" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String cleanName(String name) {
/*  79 */     String upperName = name.toUpperCase(Locale.ENGLISH);
/*     */     
/*  81 */     String[] charsToTrim = { "\\-", "[&]", "\\'", "\\.", "[\\,]" };
/*  82 */     for (String str : charsToTrim) {
/*  83 */       upperName = upperName.replaceAll(str, "");
/*     */     }
/*     */     
/*  86 */     upperName = removeAccents(upperName);
/*  87 */     return upperName.replaceAll("\\s+", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object encode(Object pObject) throws EncoderException {
/* 103 */     if (!(pObject instanceof String)) {
/* 104 */       throw new EncoderException("Parameter supplied to Match Rating Approach encoder is not of type java.lang.String");
/*     */     }
/*     */     
/* 107 */     return encode((String)pObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String encode(String name) {
/* 120 */     if (name == null || "".equalsIgnoreCase(name) || " ".equalsIgnoreCase(name) || name.length() == 1) {
/* 121 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 125 */     name = cleanName(name);
/*     */ 
/*     */     
/* 128 */     if (" ".equals(name) || name.isEmpty()) {
/* 129 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 134 */     name = removeVowels(name);
/*     */ 
/*     */     
/* 137 */     if (" ".equals(name) || name.isEmpty()) {
/* 138 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 142 */     name = removeDoubleConsonants(name);
/*     */     
/* 144 */     return getFirst3Last3(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getFirst3Last3(String name) {
/* 160 */     int nameLength = name.length();
/*     */     
/* 162 */     if (nameLength > 6) {
/* 163 */       String firstThree = name.substring(0, 3);
/* 164 */       String lastThree = name.substring(nameLength - 3, nameLength);
/* 165 */       return firstThree + lastThree;
/*     */     } 
/* 167 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getMinRating(int sumLength) {
/* 184 */     int minRating = 0;
/*     */     
/* 186 */     if (sumLength <= 4) {
/* 187 */       minRating = 5;
/* 188 */     } else if (sumLength <= 7) {
/* 189 */       minRating = 4;
/* 190 */     } else if (sumLength <= 11) {
/* 191 */       minRating = 3;
/* 192 */     } else if (sumLength == 12) {
/* 193 */       minRating = 2;
/*     */     } else {
/* 195 */       minRating = 1;
/*     */     } 
/*     */     
/* 198 */     return minRating;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEncodeEquals(String name1, String name2) {
/* 213 */     if (name1 == null || "".equalsIgnoreCase(name1) || " ".equalsIgnoreCase(name1)) {
/* 214 */       return false;
/*     */     }
/* 216 */     if (name2 == null || "".equalsIgnoreCase(name2) || " ".equalsIgnoreCase(name2)) {
/* 217 */       return false;
/*     */     }
/* 219 */     if (name1.length() == 1 || name2.length() == 1) {
/* 220 */       return false;
/*     */     }
/* 222 */     if (name1.equalsIgnoreCase(name2)) {
/* 223 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 227 */     name1 = cleanName(name1);
/* 228 */     name2 = cleanName(name2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     name1 = removeVowels(name1);
/* 234 */     name2 = removeVowels(name2);
/*     */ 
/*     */     
/* 237 */     name1 = removeDoubleConsonants(name1);
/* 238 */     name2 = removeDoubleConsonants(name2);
/*     */ 
/*     */     
/* 241 */     name1 = getFirst3Last3(name1);
/* 242 */     name2 = getFirst3Last3(name2);
/*     */ 
/*     */ 
/*     */     
/* 246 */     if (Math.abs(name1.length() - name2.length()) >= 3) {
/* 247 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 252 */     int sumLength = Math.abs(name1.length() + name2.length());
/* 253 */     int minRating = getMinRating(sumLength);
/*     */ 
/*     */ 
/*     */     
/* 257 */     int count = leftToRightThenRightToLeftProcessing(name1, name2);
/*     */ 
/*     */ 
/*     */     
/* 261 */     return (count >= minRating);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isVowel(String letter) {
/* 278 */     return (letter.equalsIgnoreCase("E") || letter.equalsIgnoreCase("A") || letter.equalsIgnoreCase("O") || letter
/* 279 */       .equalsIgnoreCase("I") || letter.equalsIgnoreCase("U"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int leftToRightThenRightToLeftProcessing(String name1, String name2) {
/* 296 */     char[] name1Char = name1.toCharArray();
/* 297 */     char[] name2Char = name2.toCharArray();
/*     */     
/* 299 */     int name1Size = name1.length() - 1;
/* 300 */     int name2Size = name2.length() - 1;
/*     */     
/* 302 */     String name1LtRStart = "";
/* 303 */     String name1LtREnd = "";
/*     */     
/* 305 */     String name2RtLStart = "";
/* 306 */     String name2RtLEnd = "";
/*     */     
/* 308 */     for (int i = 0; i < name1Char.length && 
/* 309 */       i <= name2Size; i++) {
/*     */ 
/*     */ 
/*     */       
/* 313 */       name1LtRStart = name1.substring(i, i + 1);
/* 314 */       name1LtREnd = name1.substring(name1Size - i, name1Size - i + 1);
/*     */       
/* 316 */       name2RtLStart = name2.substring(i, i + 1);
/* 317 */       name2RtLEnd = name2.substring(name2Size - i, name2Size - i + 1);
/*     */ 
/*     */       
/* 320 */       if (name1LtRStart.equals(name2RtLStart)) {
/* 321 */         name1Char[i] = ' ';
/* 322 */         name2Char[i] = ' ';
/*     */       } 
/*     */ 
/*     */       
/* 326 */       if (name1LtREnd.equals(name2RtLEnd)) {
/* 327 */         name1Char[name1Size - i] = ' ';
/* 328 */         name2Char[name2Size - i] = ' ';
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 333 */     String strA = (new String(name1Char)).replaceAll("\\s+", "");
/* 334 */     String strB = (new String(name2Char)).replaceAll("\\s+", "");
/*     */ 
/*     */     
/* 337 */     if (strA.length() > strB.length()) {
/* 338 */       return Math.abs(6 - strA.length());
/*     */     }
/* 340 */     return Math.abs(6 - strB.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String removeAccents(String accentedWord) {
/* 352 */     if (accentedWord == null) {
/* 353 */       return null;
/*     */     }
/*     */     
/* 356 */     StringBuilder sb = new StringBuilder();
/* 357 */     int n = accentedWord.length();
/*     */     
/* 359 */     for (int i = 0; i < n; i++) {
/* 360 */       char c = accentedWord.charAt(i);
/* 361 */       int pos = "ÀàÈèÌìÒòÙùÁáÉéÍíÓóÚúÝýÂâÊêÎîÔôÛûŶŷÃãÕõÑñÄäËëÏïÖöÜüŸÿÅåÇçŐőŰű".indexOf(c);
/* 362 */       if (pos > -1) {
/* 363 */         sb.append("AaEeIiOoUuAaEeIiOoUuYyAaEeIiOoUuYyAaOoNnAaEeIiOoUuYyAaCcOoUu".charAt(pos));
/*     */       } else {
/* 365 */         sb.append(c);
/*     */       } 
/*     */     } 
/*     */     
/* 369 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String removeDoubleConsonants(String name) {
/* 385 */     String replacedName = name.toUpperCase(Locale.ENGLISH);
/* 386 */     for (String dc : DOUBLE_CONSONANT) {
/* 387 */       if (replacedName.contains(dc)) {
/* 388 */         String singleLetter = dc.substring(0, 1);
/* 389 */         replacedName = replacedName.replace(dc, singleLetter);
/*     */       } 
/*     */     } 
/* 392 */     return replacedName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String removeVowels(String name) {
/* 409 */     String firstLetter = name.substring(0, 1);
/*     */     
/* 411 */     name = name.replace("A", "");
/* 412 */     name = name.replace("E", "");
/* 413 */     name = name.replace("I", "");
/* 414 */     name = name.replace("O", "");
/* 415 */     name = name.replace("U", "");
/*     */     
/* 417 */     name = name.replaceAll("\\s{2,}\\b", " ");
/*     */ 
/*     */     
/* 420 */     if (isVowel(firstLetter)) {
/* 421 */       return firstLetter + name;
/*     */     }
/* 423 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\MatchRatingApproachEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */