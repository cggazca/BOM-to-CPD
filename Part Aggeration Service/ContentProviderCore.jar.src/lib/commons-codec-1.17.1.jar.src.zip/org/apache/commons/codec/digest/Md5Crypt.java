/*     */ package org.apache.commons.codec.digest;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.Random;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Md5Crypt
/*     */ {
/*     */   static final String APR1_PREFIX = "$apr1$";
/*     */   private static final int BLOCKSIZE = 16;
/*     */   static final String MD5_PREFIX = "$1$";
/*     */   private static final int ROUNDS = 1000;
/*     */   
/*     */   public static String apr1Crypt(byte[] keyBytes) {
/*  80 */     return apr1Crypt(keyBytes, "$apr1$" + B64.getRandomSalt(8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String apr1Crypt(byte[] keyBytes, Random random) {
/*  98 */     return apr1Crypt(keyBytes, "$apr1$" + B64.getRandomSalt(8, random));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String apr1Crypt(byte[] keyBytes, String salt) {
/* 120 */     if (salt != null && !salt.startsWith("$apr1$")) {
/* 121 */       salt = "$apr1$" + salt;
/*     */     }
/* 123 */     return md5Crypt(keyBytes, salt, "$apr1$");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String apr1Crypt(String keyBytes) {
/* 140 */     return apr1Crypt(keyBytes.getBytes(StandardCharsets.UTF_8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String apr1Crypt(String keyBytes, String salt) {
/* 162 */     return apr1Crypt(keyBytes.getBytes(StandardCharsets.UTF_8), salt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String md5Crypt(byte[] keyBytes) {
/* 181 */     return md5Crypt(keyBytes, "$1$" + B64.getRandomSalt(8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String md5Crypt(byte[] keyBytes, Random random) {
/* 204 */     return md5Crypt(keyBytes, "$1$" + B64.getRandomSalt(8, random));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String md5Crypt(byte[] keyBytes, String salt) {
/* 226 */     return md5Crypt(keyBytes, salt, "$1$");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String md5Crypt(byte[] keyBytes, String salt, String prefix) {
/* 250 */     return md5Crypt(keyBytes, salt, prefix, new SecureRandom());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String md5Crypt(byte[] keyBytes, String salt, String prefix, Random random) {
/*     */     String saltString;
/* 277 */     int keyLen = keyBytes.length;
/*     */ 
/*     */ 
/*     */     
/* 281 */     if (salt == null) {
/* 282 */       saltString = B64.getRandomSalt(8, random);
/*     */     } else {
/* 284 */       Objects.requireNonNull(prefix, "prefix");
/* 285 */       if (prefix.length() < 3) {
/* 286 */         throw new IllegalArgumentException("Invalid prefix value: " + prefix);
/*     */       }
/* 288 */       if (prefix.charAt(0) != '$' && prefix.charAt(prefix.length() - 1) != '$') {
/* 289 */         throw new IllegalArgumentException("Invalid prefix value: " + prefix);
/*     */       }
/* 291 */       Pattern p = Pattern.compile("^" + prefix.replace("$", "\\$") + "([\\.\\/a-zA-Z0-9]{1,8}).*");
/* 292 */       Matcher m = p.matcher(salt);
/* 293 */       if (!m.find()) {
/* 294 */         throw new IllegalArgumentException("Invalid salt value: " + salt);
/*     */       }
/* 296 */       saltString = m.group(1);
/*     */     } 
/* 298 */     byte[] saltBytes = saltString.getBytes(StandardCharsets.UTF_8);
/*     */     
/* 300 */     MessageDigest ctx = DigestUtils.getMd5Digest();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     ctx.update(keyBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     ctx.update(prefix.getBytes(StandardCharsets.UTF_8));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     ctx.update(saltBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     MessageDigest ctx1 = DigestUtils.getMd5Digest();
/* 321 */     ctx1.update(keyBytes);
/* 322 */     ctx1.update(saltBytes);
/* 323 */     ctx1.update(keyBytes);
/* 324 */     byte[] finalb = ctx1.digest();
/* 325 */     int ii = keyLen;
/* 326 */     while (ii > 0) {
/* 327 */       ctx.update(finalb, 0, Math.min(ii, 16));
/* 328 */       ii -= 16;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     Arrays.fill(finalb, (byte)0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     ii = keyLen;
/* 340 */     int j = 0;
/* 341 */     while (ii > 0) {
/* 342 */       if ((ii & 0x1) == 1) {
/* 343 */         ctx.update(finalb[0]);
/*     */       } else {
/* 345 */         ctx.update(keyBytes[0]);
/*     */       } 
/* 347 */       ii >>= 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     StringBuilder passwd = new StringBuilder(prefix + saltString + "$");
/* 354 */     finalb = ctx.digest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     for (int i = 0; i < 1000; i++) {
/* 361 */       ctx1 = DigestUtils.getMd5Digest();
/* 362 */       if ((i & 0x1) != 0) {
/* 363 */         ctx1.update(keyBytes);
/*     */       } else {
/* 365 */         ctx1.update(finalb, 0, 16);
/*     */       } 
/*     */       
/* 368 */       if (i % 3 != 0) {
/* 369 */         ctx1.update(saltBytes);
/*     */       }
/*     */       
/* 372 */       if (i % 7 != 0) {
/* 373 */         ctx1.update(keyBytes);
/*     */       }
/*     */       
/* 376 */       if ((i & 0x1) != 0) {
/* 377 */         ctx1.update(finalb, 0, 16);
/*     */       } else {
/* 379 */         ctx1.update(keyBytes);
/*     */       } 
/* 381 */       finalb = ctx1.digest();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     B64.b64from24bit(finalb[0], finalb[6], finalb[12], 4, passwd);
/* 388 */     B64.b64from24bit(finalb[1], finalb[7], finalb[13], 4, passwd);
/* 389 */     B64.b64from24bit(finalb[2], finalb[8], finalb[14], 4, passwd);
/* 390 */     B64.b64from24bit(finalb[3], finalb[9], finalb[15], 4, passwd);
/* 391 */     B64.b64from24bit(finalb[4], finalb[10], finalb[5], 4, passwd);
/* 392 */     B64.b64from24bit((byte)0, (byte)0, finalb[11], 2, passwd);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 398 */     ctx.reset();
/* 399 */     ctx1.reset();
/* 400 */     Arrays.fill(keyBytes, (byte)0);
/* 401 */     Arrays.fill(saltBytes, (byte)0);
/* 402 */     Arrays.fill(finalb, (byte)0);
/*     */     
/* 404 */     return passwd.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\Md5Crypt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */