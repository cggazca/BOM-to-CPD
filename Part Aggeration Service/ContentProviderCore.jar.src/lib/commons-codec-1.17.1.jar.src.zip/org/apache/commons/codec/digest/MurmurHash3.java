/*      */ package org.apache.commons.codec.digest;
/*      */ 
/*      */ import org.apache.commons.codec.binary.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MurmurHash3
/*      */ {
/*      */   @Deprecated
/*      */   public static final long NULL_HASHCODE = 2862933555777941757L;
/*      */   public static final int DEFAULT_SEED = 104729;
/*      */   private static final int C1_32 = -862048943;
/*      */   private static final int C2_32 = 461845907;
/*      */   private static final int R1_32 = 15;
/*      */   private static final int R2_32 = 13;
/*      */   private static final int M_32 = 5;
/*      */   private static final int N_32 = -430675100;
/*      */   private static final long C1 = -8663945395140668459L;
/*      */   private static final long C2 = 5545529020109919103L;
/*      */   private static final int R1 = 31;
/*      */   private static final int R2 = 27;
/*      */   private static final int R3 = 33;
/*      */   private static final int M = 5;
/*      */   private static final int N1 = 1390208809;
/*      */   private static final int N2 = 944331445;
/*      */   
/*      */   @Deprecated
/*      */   public static class IncrementalHash32
/*      */     extends IncrementalHash32x86
/*      */   {
/*      */     @Deprecated
/*      */     int finalise(int hash, int unprocessedLength, byte[] unprocessed, int totalLen) {
/*   88 */       int result = hash;
/*      */ 
/*      */ 
/*      */       
/*   92 */       int k1 = 0;
/*   93 */       switch (unprocessedLength) {
/*      */         case 3:
/*   95 */           k1 ^= unprocessed[2] << 16;
/*      */         case 2:
/*   97 */           k1 ^= unprocessed[1] << 8;
/*      */         case 1:
/*   99 */           k1 ^= unprocessed[0];
/*      */ 
/*      */           
/*  102 */           k1 *= -862048943;
/*  103 */           k1 = Integer.rotateLeft(k1, 15);
/*  104 */           k1 *= 461845907;
/*  105 */           result ^= k1;
/*      */           break;
/*      */       } 
/*      */       
/*  109 */       result ^= totalLen;
/*  110 */       return MurmurHash3.fmix32(result);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IncrementalHash32x86
/*      */   {
/*      */     private static final int BLOCK_SIZE = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static int orBytes(byte b1, byte b2, byte b3, byte b4) {
/*  140 */       return b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24;
/*      */     }
/*      */ 
/*      */     
/*  144 */     private final byte[] unprocessed = new byte[3];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int unprocessedLength;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int totalLen;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int hash;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void add(byte[] data, int offset, int length) {
/*      */       int newOffset, newLength;
/*  166 */       if (length <= 0) {
/*      */         return;
/*      */       }
/*      */       
/*  170 */       this.totalLen += length;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  184 */       if (this.unprocessedLength + length - 4 < 0) {
/*      */         
/*  186 */         System.arraycopy(data, offset, this.unprocessed, this.unprocessedLength, length);
/*  187 */         this.unprocessedLength += length;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*  194 */       if (this.unprocessedLength > 0) {
/*  195 */         int k = -1;
/*  196 */         switch (this.unprocessedLength) {
/*      */           case 1:
/*  198 */             k = orBytes(this.unprocessed[0], data[offset], data[offset + 1], data[offset + 2]);
/*      */             break;
/*      */           case 2:
/*  201 */             k = orBytes(this.unprocessed[0], this.unprocessed[1], data[offset], data[offset + 1]);
/*      */             break;
/*      */           case 3:
/*  204 */             k = orBytes(this.unprocessed[0], this.unprocessed[1], this.unprocessed[2], data[offset]);
/*      */             break;
/*      */           default:
/*  207 */             throw new IllegalStateException("Unprocessed length should be 1, 2, or 3: " + this.unprocessedLength);
/*      */         } 
/*  209 */         this.hash = MurmurHash3.mix32(k, this.hash);
/*      */         
/*  211 */         int j = 4 - this.unprocessedLength;
/*  212 */         newOffset = offset + j;
/*  213 */         newLength = length - j;
/*      */       } else {
/*  215 */         newOffset = offset;
/*  216 */         newLength = length;
/*      */       } 
/*      */ 
/*      */       
/*  220 */       int nblocks = newLength >> 2;
/*      */       
/*  222 */       for (int i = 0; i < nblocks; i++) {
/*  223 */         int index = newOffset + (i << 2);
/*  224 */         int k = MurmurHash3.getLittleEndianInt(data, index);
/*  225 */         this.hash = MurmurHash3.mix32(k, this.hash);
/*      */       } 
/*      */ 
/*      */       
/*  229 */       int consumed = nblocks << 2;
/*  230 */       this.unprocessedLength = newLength - consumed;
/*  231 */       if (this.unprocessedLength != 0) {
/*  232 */         System.arraycopy(data, newOffset + consumed, this.unprocessed, 0, this.unprocessedLength);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int end() {
/*  244 */       return finalise(this.hash, this.unprocessedLength, this.unprocessed, this.totalLen);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int finalise(int hash, int unprocessedLength, byte[] unprocessed, int totalLen) {
/*  258 */       int result = hash;
/*  259 */       int k1 = 0;
/*  260 */       switch (unprocessedLength) {
/*      */         case 3:
/*  262 */           k1 ^= (unprocessed[2] & 0xFF) << 16;
/*      */         case 2:
/*  264 */           k1 ^= (unprocessed[1] & 0xFF) << 8;
/*      */         case 1:
/*  266 */           k1 ^= unprocessed[0] & 0xFF;
/*      */ 
/*      */           
/*  269 */           k1 *= -862048943;
/*  270 */           k1 = Integer.rotateLeft(k1, 15);
/*  271 */           k1 *= 461845907;
/*  272 */           result ^= k1;
/*      */           break;
/*      */       } 
/*      */       
/*  276 */       result ^= totalLen;
/*  277 */       return MurmurHash3.fmix32(result);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void start(int seed) {
/*  287 */       this.unprocessedLength = this.totalLen = 0;
/*  288 */       this.hash = seed;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int fmix32(int hash) {
/*  331 */     hash ^= hash >>> 16;
/*  332 */     hash *= -2048144789;
/*  333 */     hash ^= hash >>> 13;
/*  334 */     hash *= -1028477387;
/*  335 */     hash ^= hash >>> 16;
/*  336 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long fmix64(long hash) {
/*  346 */     hash ^= hash >>> 33L;
/*  347 */     hash *= -49064778989728563L;
/*  348 */     hash ^= hash >>> 33L;
/*  349 */     hash *= -4265267296055464877L;
/*  350 */     hash ^= hash >>> 33L;
/*  351 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getLittleEndianInt(byte[] data, int index) {
/*  362 */     return data[index] & 0xFF | (data[index + 1] & 0xFF) << 8 | (data[index + 2] & 0xFF) << 16 | (data[index + 3] & 0xFF) << 24;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long getLittleEndianLong(byte[] data, int index) {
/*  376 */     return data[index] & 0xFFL | (data[index + 1] & 0xFFL) << 8L | (data[index + 2] & 0xFFL) << 16L | (data[index + 3] & 0xFFL) << 24L | (data[index + 4] & 0xFFL) << 32L | (data[index + 5] & 0xFFL) << 40L | (data[index + 6] & 0xFFL) << 48L | (data[index + 7] & 0xFFL) << 56L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] hash128(byte[] data) {
/*  404 */     return hash128(data, 0, data.length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long[] hash128(byte[] data, int offset, int length, int seed) {
/*  431 */     return hash128x64Internal(data, offset, length, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long[] hash128(String data) {
/*  462 */     byte[] bytes = StringUtils.getBytesUtf8(data);
/*  463 */     return hash128(bytes, 0, bytes.length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] hash128x64(byte[] data) {
/*  482 */     return hash128x64(data, 0, data.length, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] hash128x64(byte[] data, int offset, int length, int seed) {
/*  500 */     return hash128x64Internal(data, offset, length, seed & 0xFFFFFFFFL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long[] hash128x64Internal(byte[] data, int offset, int length, long seed) {
/*  516 */     long h1 = seed;
/*  517 */     long h2 = seed;
/*  518 */     int nblocks = length >> 4;
/*      */ 
/*      */     
/*  521 */     for (int i = 0; i < nblocks; i++) {
/*  522 */       int j = offset + (i << 4);
/*  523 */       long l1 = getLittleEndianLong(data, j);
/*  524 */       long l2 = getLittleEndianLong(data, j + 8);
/*      */ 
/*      */       
/*  527 */       l1 *= -8663945395140668459L;
/*  528 */       l1 = Long.rotateLeft(l1, 31);
/*  529 */       l1 *= 5545529020109919103L;
/*  530 */       h1 ^= l1;
/*  531 */       h1 = Long.rotateLeft(h1, 27);
/*  532 */       h1 += h2;
/*  533 */       h1 = h1 * 5L + 1390208809L;
/*      */ 
/*      */       
/*  536 */       l2 *= 5545529020109919103L;
/*  537 */       l2 = Long.rotateLeft(l2, 33);
/*  538 */       l2 *= -8663945395140668459L;
/*  539 */       h2 ^= l2;
/*  540 */       h2 = Long.rotateLeft(h2, 31);
/*  541 */       h2 += h1;
/*  542 */       h2 = h2 * 5L + 944331445L;
/*      */     } 
/*      */ 
/*      */     
/*  546 */     long k1 = 0L;
/*  547 */     long k2 = 0L;
/*  548 */     int index = offset + (nblocks << 4);
/*  549 */     switch (offset + length - index) {
/*      */       case 15:
/*  551 */         k2 ^= (data[index + 14] & 0xFFL) << 48L;
/*      */       case 14:
/*  553 */         k2 ^= (data[index + 13] & 0xFFL) << 40L;
/*      */       case 13:
/*  555 */         k2 ^= (data[index + 12] & 0xFFL) << 32L;
/*      */       case 12:
/*  557 */         k2 ^= (data[index + 11] & 0xFFL) << 24L;
/*      */       case 11:
/*  559 */         k2 ^= (data[index + 10] & 0xFFL) << 16L;
/*      */       case 10:
/*  561 */         k2 ^= (data[index + 9] & 0xFFL) << 8L;
/*      */       case 9:
/*  563 */         k2 ^= (data[index + 8] & 0xFF);
/*  564 */         k2 *= 5545529020109919103L;
/*  565 */         k2 = Long.rotateLeft(k2, 33);
/*  566 */         k2 *= -8663945395140668459L;
/*  567 */         h2 ^= k2;
/*      */       
/*      */       case 8:
/*  570 */         k1 ^= (data[index + 7] & 0xFFL) << 56L;
/*      */       case 7:
/*  572 */         k1 ^= (data[index + 6] & 0xFFL) << 48L;
/*      */       case 6:
/*  574 */         k1 ^= (data[index + 5] & 0xFFL) << 40L;
/*      */       case 5:
/*  576 */         k1 ^= (data[index + 4] & 0xFFL) << 32L;
/*      */       case 4:
/*  578 */         k1 ^= (data[index + 3] & 0xFFL) << 24L;
/*      */       case 3:
/*  580 */         k1 ^= (data[index + 2] & 0xFFL) << 16L;
/*      */       case 2:
/*  582 */         k1 ^= (data[index + 1] & 0xFFL) << 8L;
/*      */       case 1:
/*  584 */         k1 ^= (data[index] & 0xFF);
/*  585 */         k1 *= -8663945395140668459L;
/*  586 */         k1 = Long.rotateLeft(k1, 31);
/*  587 */         k1 *= 5545529020109919103L;
/*  588 */         h1 ^= k1;
/*      */         break;
/*      */     } 
/*      */     
/*  592 */     h1 ^= length;
/*  593 */     h2 ^= length;
/*      */     
/*  595 */     h1 += h2;
/*  596 */     h2 += h1;
/*      */     
/*  598 */     h1 = fmix64(h1);
/*  599 */     h2 = fmix64(h2);
/*      */     
/*  601 */     h1 += h2;
/*  602 */     h2 += h1;
/*      */     
/*  604 */     return new long[] { h1, h2 };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int hash32(byte[] data) {
/*  628 */     return hash32(data, 0, data.length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int hash32(byte[] data, int length) {
/*  653 */     return hash32(data, length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int hash32(byte[] data, int length, int seed) {
/*  678 */     return hash32(data, 0, length, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int hash32(byte[] data, int offset, int length, int seed) {
/*  700 */     int hash = seed;
/*  701 */     int nblocks = length >> 2;
/*      */ 
/*      */     
/*  704 */     for (int i = 0; i < nblocks; i++) {
/*  705 */       int j = offset + (i << 2);
/*  706 */       int k = getLittleEndianInt(data, j);
/*  707 */       hash = mix32(k, hash);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  714 */     int index = offset + (nblocks << 2);
/*  715 */     int k1 = 0;
/*  716 */     switch (offset + length - index) {
/*      */       case 3:
/*  718 */         k1 ^= data[index + 2] << 16;
/*      */       case 2:
/*  720 */         k1 ^= data[index + 1] << 8;
/*      */       case 1:
/*  722 */         k1 ^= data[index];
/*      */ 
/*      */         
/*  725 */         k1 *= -862048943;
/*  726 */         k1 = Integer.rotateLeft(k1, 15);
/*  727 */         k1 *= 461845907;
/*  728 */         hash ^= k1;
/*      */         break;
/*      */     } 
/*  731 */     hash ^= length;
/*  732 */     return fmix32(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hash32(long data) {
/*  752 */     return hash32(data, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hash32(long data, int seed) {
/*  772 */     int hash = seed;
/*  773 */     long r0 = Long.reverseBytes(data);
/*      */     
/*  775 */     hash = mix32((int)r0, hash);
/*  776 */     hash = mix32((int)(r0 >>> 32L), hash);
/*      */     
/*  778 */     hash ^= 0x8;
/*  779 */     return fmix32(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hash32(long data1, long data2) {
/*  801 */     return hash32(data1, data2, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hash32(long data1, long data2, int seed) {
/*  823 */     int hash = seed;
/*  824 */     long r0 = Long.reverseBytes(data1);
/*  825 */     long r1 = Long.reverseBytes(data2);
/*      */     
/*  827 */     hash = mix32((int)r0, hash);
/*  828 */     hash = mix32((int)(r0 >>> 32L), hash);
/*  829 */     hash = mix32((int)r1, hash);
/*  830 */     hash = mix32((int)(r1 >>> 32L), hash);
/*      */     
/*  832 */     hash ^= 0x10;
/*  833 */     return fmix32(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int hash32(String data) {
/*  863 */     byte[] bytes = StringUtils.getBytesUtf8(data);
/*  864 */     return hash32(bytes, 0, bytes.length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hash32x86(byte[] data) {
/*  883 */     return hash32x86(data, 0, data.length, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hash32x86(byte[] data, int offset, int length, int seed) {
/*  900 */     int hash = seed;
/*  901 */     int nblocks = length >> 2;
/*      */ 
/*      */     
/*  904 */     for (int i = 0; i < nblocks; i++) {
/*  905 */       int j = offset + (i << 2);
/*  906 */       int k = getLittleEndianInt(data, j);
/*  907 */       hash = mix32(k, hash);
/*      */     } 
/*      */ 
/*      */     
/*  911 */     int index = offset + (nblocks << 2);
/*  912 */     int k1 = 0;
/*  913 */     switch (offset + length - index) {
/*      */       case 3:
/*  915 */         k1 ^= (data[index + 2] & 0xFF) << 16;
/*      */       case 2:
/*  917 */         k1 ^= (data[index + 1] & 0xFF) << 8;
/*      */       case 1:
/*  919 */         k1 ^= data[index] & 0xFF;
/*      */ 
/*      */         
/*  922 */         k1 *= -862048943;
/*  923 */         k1 = Integer.rotateLeft(k1, 15);
/*  924 */         k1 *= 461845907;
/*  925 */         hash ^= k1;
/*      */         break;
/*      */     } 
/*  928 */     hash ^= length;
/*  929 */     return fmix32(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long hash64(byte[] data) {
/*  961 */     return hash64(data, 0, data.length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long hash64(byte[] data, int offset, int length) {
/*  994 */     return hash64(data, offset, length, 104729);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long hash64(byte[] data, int offset, int length, int seed) {
/* 1030 */     long hash = seed;
/* 1031 */     int nblocks = length >> 3;
/*      */ 
/*      */     
/* 1034 */     for (int i = 0; i < nblocks; i++) {
/* 1035 */       int j = offset + (i << 3);
/* 1036 */       long k = getLittleEndianLong(data, j);
/*      */ 
/*      */       
/* 1039 */       k *= -8663945395140668459L;
/* 1040 */       k = Long.rotateLeft(k, 31);
/* 1041 */       k *= 5545529020109919103L;
/* 1042 */       hash ^= k;
/* 1043 */       hash = Long.rotateLeft(hash, 27) * 5L + 1390208809L;
/*      */     } 
/*      */ 
/*      */     
/* 1047 */     long k1 = 0L;
/* 1048 */     int index = offset + (nblocks << 3);
/* 1049 */     switch (offset + length - index) {
/*      */       case 7:
/* 1051 */         k1 ^= (data[index + 6] & 0xFFL) << 48L;
/*      */       case 6:
/* 1053 */         k1 ^= (data[index + 5] & 0xFFL) << 40L;
/*      */       case 5:
/* 1055 */         k1 ^= (data[index + 4] & 0xFFL) << 32L;
/*      */       case 4:
/* 1057 */         k1 ^= (data[index + 3] & 0xFFL) << 24L;
/*      */       case 3:
/* 1059 */         k1 ^= (data[index + 2] & 0xFFL) << 16L;
/*      */       case 2:
/* 1061 */         k1 ^= (data[index + 1] & 0xFFL) << 8L;
/*      */       case 1:
/* 1063 */         k1 ^= data[index] & 0xFFL;
/* 1064 */         k1 *= -8663945395140668459L;
/* 1065 */         k1 = Long.rotateLeft(k1, 31);
/* 1066 */         k1 *= 5545529020109919103L;
/* 1067 */         hash ^= k1;
/*      */         break;
/*      */     } 
/*      */     
/* 1071 */     hash ^= length;
/* 1072 */     return fmix64(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long hash64(int data) {
/* 1106 */     long k1 = Integer.reverseBytes(data) & 0xFFFFFFFFL;
/* 1107 */     long hash = 104729L;
/* 1108 */     k1 *= -8663945395140668459L;
/* 1109 */     k1 = Long.rotateLeft(k1, 31);
/* 1110 */     k1 *= 5545529020109919103L;
/* 1111 */     hash ^= k1;
/*      */     
/* 1113 */     hash ^= 0x4L;
/* 1114 */     return fmix64(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long hash64(long data) {
/* 1148 */     long hash = 104729L;
/* 1149 */     long k = Long.reverseBytes(data);
/*      */     
/* 1151 */     k *= -8663945395140668459L;
/* 1152 */     k = Long.rotateLeft(k, 31);
/* 1153 */     k *= 5545529020109919103L;
/* 1154 */     hash ^= k;
/* 1155 */     hash = Long.rotateLeft(hash, 27) * 5L + 1390208809L;
/*      */     
/* 1157 */     hash ^= 0x8L;
/* 1158 */     return fmix64(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static long hash64(short data) {
/* 1192 */     long hash = 104729L;
/* 1193 */     long k1 = 0L;
/* 1194 */     k1 ^= (data & 0xFFL) << 8L;
/* 1195 */     k1 ^= ((data & 0xFF00) >> 8) & 0xFFL;
/* 1196 */     k1 *= -8663945395140668459L;
/* 1197 */     k1 = Long.rotateLeft(k1, 31);
/* 1198 */     k1 *= 5545529020109919103L;
/* 1199 */     hash ^= k1;
/*      */ 
/*      */     
/* 1202 */     hash ^= 0x2L;
/* 1203 */     return fmix64(hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int mix32(int k, int hash) {
/* 1214 */     k *= -862048943;
/* 1215 */     k = Integer.rotateLeft(k, 15);
/* 1216 */     k *= 461845907;
/* 1217 */     hash ^= k;
/* 1218 */     return Integer.rotateLeft(hash, 13) * 5 + -430675100;
/*      */   }
/*      */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\MurmurHash3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */