/*     */ package org.apache.commons.codec.cli;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.codec.binary.Hex;
/*     */ import org.apache.commons.codec.digest.DigestUtils;
/*     */ import org.apache.commons.codec.digest.MessageDigestAlgorithms;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Digest
/*     */ {
/*     */   private final String algorithm;
/*     */   private final String[] args;
/*     */   private final String[] inputs;
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*  54 */     (new Digest(args)).run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Digest(String[] args) {
/*  62 */     Objects.requireNonNull(args);
/*  63 */     int argsLength = args.length;
/*  64 */     if (argsLength == 0) {
/*  65 */       throw new IllegalArgumentException(
/*  66 */           String.format("Usage: java %s [algorithm] [FILE|DIRECTORY|string] ...", new Object[] { Digest.class.getName() }));
/*     */     }
/*  68 */     this.args = args;
/*  69 */     this.algorithm = args[0];
/*  70 */     if (argsLength <= 1) {
/*  71 */       this.inputs = null;
/*     */     } else {
/*  73 */       this.inputs = Arrays.<String>copyOfRange(args, 1, argsLength);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void println(String prefix, byte[] digest) {
/*  78 */     println(prefix, digest, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void println(String prefix, byte[] digest, String fileName) {
/*  87 */     System.out.println(prefix + Hex.encodeHexString(digest) + ((fileName != null) ? ("  " + fileName) : ""));
/*     */   }
/*     */   
/*     */   private void run() throws IOException {
/*  91 */     if (this.algorithm.equalsIgnoreCase("ALL") || this.algorithm.equals("*")) {
/*  92 */       run(MessageDigestAlgorithms.values());
/*     */       return;
/*     */     } 
/*  95 */     MessageDigest messageDigest = DigestUtils.getDigest(this.algorithm, null);
/*  96 */     if (messageDigest != null) {
/*  97 */       run("", messageDigest);
/*     */     } else {
/*  99 */       run("", DigestUtils.getDigest(this.algorithm.toUpperCase(Locale.ROOT)));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void run(String prefix, MessageDigest messageDigest) throws IOException {
/* 104 */     if (this.inputs == null) {
/* 105 */       println(prefix, DigestUtils.digest(messageDigest, System.in));
/*     */       return;
/*     */     } 
/* 108 */     for (String source : this.inputs) {
/* 109 */       File file = new File(source);
/* 110 */       if (file.isFile()) {
/* 111 */         println(prefix, DigestUtils.digest(messageDigest, file), source);
/* 112 */       } else if (file.isDirectory()) {
/* 113 */         File[] listFiles = file.listFiles();
/* 114 */         if (listFiles != null) {
/* 115 */           run(prefix, messageDigest, listFiles);
/*     */         }
/*     */       } else {
/*     */         
/* 119 */         byte[] bytes = source.getBytes(Charset.defaultCharset());
/* 120 */         println(prefix, DigestUtils.digest(messageDigest, bytes));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void run(String prefix, MessageDigest messageDigest, File[] files) throws IOException {
/* 126 */     for (File file : files) {
/* 127 */       if (file.isFile()) {
/* 128 */         println(prefix, DigestUtils.digest(messageDigest, file), file.getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void run(String prefix, String messageDigestAlgorithm) throws IOException {
/* 134 */     run(prefix, DigestUtils.getDigest(messageDigestAlgorithm));
/*     */   }
/*     */   
/*     */   private void run(String[] digestAlgorithms) throws IOException {
/* 138 */     for (String messageDigestAlgorithm : digestAlgorithms) {
/* 139 */       if (DigestUtils.isAvailable(messageDigestAlgorithm)) {
/* 140 */         run(messageDigestAlgorithm + " ", messageDigestAlgorithm);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     return String.format("%s %s", new Object[] { super.toString(), Arrays.toString((Object[])this.args) });
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\cli\Digest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */