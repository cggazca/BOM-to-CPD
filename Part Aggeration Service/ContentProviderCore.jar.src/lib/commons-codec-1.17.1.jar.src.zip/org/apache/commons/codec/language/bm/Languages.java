/*     */ package org.apache.commons.codec.language.bm;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Scanner;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.codec.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Languages
/*     */ {
/*     */   public static final String ANY = "any";
/*     */   
/*     */   public static abstract class LanguageSet
/*     */   {
/*     */     public static LanguageSet from(Set<String> langs) {
/*  74 */       return langs.isEmpty() ? Languages.NO_LANGUAGES : new Languages.SomeLanguages(langs);
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract boolean contains(String param1String);
/*     */     
/*     */     public abstract String getAny();
/*     */     
/*     */     public abstract boolean isEmpty();
/*     */     
/*     */     public abstract boolean isSingleton();
/*     */     
/*     */     abstract LanguageSet merge(LanguageSet param1LanguageSet);
/*     */     
/*     */     public abstract LanguageSet restrictTo(LanguageSet param1LanguageSet);
/*     */   }
/*     */   
/*     */   public static final class SomeLanguages
/*     */     extends LanguageSet
/*     */   {
/*     */     private final Set<String> languages;
/*     */     
/*     */     private SomeLanguages(Set<String> languages) {
/*  97 */       this.languages = Collections.unmodifiableSet(languages);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(String language) {
/* 102 */       return this.languages.contains(language);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAny() {
/* 107 */       return this.languages.iterator().next();
/*     */     }
/*     */     
/*     */     public Set<String> getLanguages() {
/* 111 */       return this.languages;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 116 */       return this.languages.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSingleton() {
/* 121 */       return (this.languages.size() == 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public Languages.LanguageSet merge(Languages.LanguageSet other) {
/* 126 */       if (other == Languages.NO_LANGUAGES) {
/* 127 */         return this;
/*     */       }
/* 129 */       if (other == Languages.ANY_LANGUAGE) {
/* 130 */         return other;
/*     */       }
/* 132 */       SomeLanguages someLanguages = (SomeLanguages)other;
/* 133 */       Set<String> set = new HashSet<>(this.languages);
/* 134 */       set.addAll(someLanguages.languages);
/* 135 */       return from(set);
/*     */     }
/*     */ 
/*     */     
/*     */     public Languages.LanguageSet restrictTo(Languages.LanguageSet other) {
/* 140 */       if (other == Languages.NO_LANGUAGES) {
/* 141 */         return other;
/*     */       }
/* 143 */       if (other == Languages.ANY_LANGUAGE) {
/* 144 */         return this;
/*     */       }
/* 146 */       SomeLanguages someLanguages = (SomeLanguages)other;
/* 147 */       return from((Set<String>)this.languages.stream().filter(lang -> someLanguages.languages.contains(lang)).collect(Collectors.toSet()));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 152 */       return "Languages(" + this.languages.toString() + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   private static final Map<NameType, Languages> LANGUAGES = new EnumMap<>(NameType.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public static final LanguageSet NO_LANGUAGES = new LanguageSet()
/*     */     {
/*     */       public boolean contains(String language) {
/* 167 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getAny() {
/* 172 */         throw new NoSuchElementException("Can't fetch any language from the empty language set.");
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isEmpty() {
/* 177 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSingleton() {
/* 182 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public Languages.LanguageSet merge(Languages.LanguageSet other) {
/* 187 */         return other;
/*     */       }
/*     */ 
/*     */       
/*     */       public Languages.LanguageSet restrictTo(Languages.LanguageSet other) {
/* 192 */         return this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String toString() {
/* 197 */         return "NO_LANGUAGES";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public static final LanguageSet ANY_LANGUAGE = new LanguageSet()
/*     */     {
/*     */       public boolean contains(String language) {
/* 207 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getAny() {
/* 212 */         throw new NoSuchElementException("Can't fetch any language from the any language set.");
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isEmpty() {
/* 217 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSingleton() {
/* 222 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public Languages.LanguageSet merge(Languages.LanguageSet other) {
/* 227 */         return other;
/*     */       }
/*     */ 
/*     */       
/*     */       public Languages.LanguageSet restrictTo(Languages.LanguageSet other) {
/* 232 */         return other;
/*     */       }
/*     */ 
/*     */       
/*     */       public String toString() {
/* 237 */         return "ANY_LANGUAGE";
/*     */       }
/*     */     };
/*     */   private final Set<String> languages;
/*     */   static {
/* 242 */     for (NameType s : NameType.values()) {
/* 243 */       LANGUAGES.put(s, getInstance(langResourceName(s)));
/*     */     }
/*     */   }
/*     */   
/*     */   public static Languages getInstance(NameType nameType) {
/* 248 */     return LANGUAGES.get(nameType);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Languages getInstance(String languagesResourceName) {
/* 253 */     Set<String> ls = new HashSet<>();
/* 254 */     Scanner lsScanner = new Scanner(Resources.getInputStream(languagesResourceName), ResourceConstants.ENCODING);
/*     */     
/* 256 */     try { boolean inExtendedComment = false;
/* 257 */       while (lsScanner.hasNextLine()) {
/* 258 */         String line = lsScanner.nextLine().trim();
/* 259 */         if (inExtendedComment) {
/* 260 */           if (line.endsWith("*/"))
/* 261 */             inExtendedComment = false;  continue;
/*     */         } 
/* 263 */         if (line.startsWith("/*")) {
/* 264 */           inExtendedComment = true; continue;
/* 265 */         }  if (!line.isEmpty()) {
/* 266 */           ls.add(line);
/*     */         }
/*     */       } 
/* 269 */       Languages languages = new Languages(Collections.unmodifiableSet(ls));
/* 270 */       lsScanner.close(); return languages; }
/*     */     catch (Throwable throwable) { try { lsScanner.close(); }
/*     */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 274 */      } private static String langResourceName(NameType nameType) { return String.format("org/apache/commons/codec/language/bm/%s_languages.txt", new Object[] { nameType.getName() }); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Languages(Set<String> languages) {
/* 280 */     this.languages = languages;
/*     */   }
/*     */   
/*     */   public Set<String> getLanguages() {
/* 284 */     return this.languages;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\bm\Languages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */