/*     */ package org.apache.commons.codec.net;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.BitSet;
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.CharEncoding;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringDecoder;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ import org.apache.commons.codec.binary.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLCodec
/*     */   implements BinaryEncoder, BinaryDecoder, StringEncoder, StringDecoder
/*     */ {
/*     */   protected static final byte ESCAPE_CHAR = 37;
/*     */   @Deprecated
/*     */   protected static final BitSet WWW_FORM_URL;
/*  65 */   private static final BitSet WWW_FORM_URL_SAFE = new BitSet(256);
/*     */ 
/*     */   
/*     */   static {
/*     */     int i;
/*  70 */     for (i = 97; i <= 122; i++) {
/*  71 */       WWW_FORM_URL_SAFE.set(i);
/*     */     }
/*  73 */     for (i = 65; i <= 90; i++) {
/*  74 */       WWW_FORM_URL_SAFE.set(i);
/*     */     }
/*     */     
/*  77 */     for (i = 48; i <= 57; i++) {
/*  78 */       WWW_FORM_URL_SAFE.set(i);
/*     */     }
/*     */     
/*  81 */     WWW_FORM_URL_SAFE.set(45);
/*  82 */     WWW_FORM_URL_SAFE.set(95);
/*  83 */     WWW_FORM_URL_SAFE.set(46);
/*  84 */     WWW_FORM_URL_SAFE.set(42);
/*     */     
/*  86 */     WWW_FORM_URL_SAFE.set(32);
/*     */ 
/*     */     
/*  89 */     WWW_FORM_URL = (BitSet)WWW_FORM_URL_SAFE.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected volatile String charset;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[] decodeUrl(byte[] bytes) throws DecoderException {
/* 103 */     if (bytes == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 107 */     for (int i = 0; i < bytes.length; i++) {
/* 108 */       int b = bytes[i];
/* 109 */       if (b == 43) {
/* 110 */         buffer.write(32);
/* 111 */       } else if (b == 37) {
/*     */         try {
/* 113 */           int u = Utils.digit16(bytes[++i]);
/* 114 */           int l = Utils.digit16(bytes[++i]);
/* 115 */           buffer.write((char)((u << 4) + l));
/* 116 */         } catch (ArrayIndexOutOfBoundsException e) {
/* 117 */           throw new DecoderException("Invalid URL encoding: ", e);
/*     */         } 
/*     */       } else {
/* 120 */         buffer.write(b);
/*     */       } 
/*     */     } 
/* 123 */     return buffer.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[] encodeUrl(BitSet urlsafe, byte[] bytes) {
/* 136 */     if (bytes == null) {
/* 137 */       return null;
/*     */     }
/* 139 */     if (urlsafe == null) {
/* 140 */       urlsafe = WWW_FORM_URL_SAFE;
/*     */     }
/*     */     
/* 143 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 144 */     for (byte c : bytes) {
/* 145 */       int b = c;
/* 146 */       if (b < 0) {
/* 147 */         b = 256 + b;
/*     */       }
/* 149 */       if (urlsafe.get(b)) {
/* 150 */         if (b == 32) {
/* 151 */           b = 43;
/*     */         }
/* 153 */         buffer.write(b);
/*     */       } else {
/* 155 */         buffer.write(37);
/* 156 */         char hex1 = Utils.hexDigit(b >> 4);
/* 157 */         char hex2 = Utils.hexDigit(b);
/* 158 */         buffer.write(hex1);
/* 159 */         buffer.write(hex2);
/*     */       } 
/*     */     } 
/* 162 */     return buffer.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLCodec() {
/* 177 */     this(CharEncoding.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLCodec(String charset) {
/* 186 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] bytes) throws DecoderException {
/* 201 */     return decodeUrl(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(Object obj) throws DecoderException {
/* 217 */     if (obj == null) {
/* 218 */       return null;
/*     */     }
/* 220 */     if (obj instanceof byte[]) {
/* 221 */       return decode((byte[])obj);
/*     */     }
/* 223 */     if (obj instanceof String) {
/* 224 */       return decode((String)obj);
/*     */     }
/* 226 */     throw new DecoderException("Objects of type " + obj.getClass().getName() + " cannot be URL decoded");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decode(String str) throws DecoderException {
/* 242 */     if (str == null) {
/* 243 */       return null;
/*     */     }
/*     */     try {
/* 246 */       return decode(str, getDefaultCharset());
/* 247 */     } catch (UnsupportedEncodingException e) {
/* 248 */       throw new DecoderException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decode(String str, String charsetName) throws DecoderException, UnsupportedEncodingException {
/* 268 */     if (str == null) {
/* 269 */       return null;
/*     */     }
/* 271 */     return new String(decode(StringUtils.getBytesUsAscii(str)), charsetName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encode(byte[] bytes) {
/* 283 */     return encodeUrl(WWW_FORM_URL_SAFE, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 297 */     if (obj == null) {
/* 298 */       return null;
/*     */     }
/* 300 */     if (obj instanceof byte[]) {
/* 301 */       return encode((byte[])obj);
/*     */     }
/* 303 */     if (obj instanceof String) {
/* 304 */       return encode((String)obj);
/*     */     }
/* 306 */     throw new EncoderException("Objects of type " + obj.getClass().getName() + " cannot be URL encoded");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String str) throws EncoderException {
/* 322 */     if (str == null) {
/* 323 */       return null;
/*     */     }
/*     */     try {
/* 326 */       return encode(str, getDefaultCharset());
/* 327 */     } catch (UnsupportedEncodingException e) {
/* 328 */       throw new EncoderException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String str, String charsetName) throws UnsupportedEncodingException {
/* 344 */     if (str == null) {
/* 345 */       return null;
/*     */     }
/* 347 */     return StringUtils.newStringUsAscii(encode(str.getBytes(charsetName)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/* 356 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getEncoding() {
/* 368 */     return this.charset;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\net\URLCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */