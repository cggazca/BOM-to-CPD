/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.codec.CodecPolicy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */   extends BaseNCodec
/*     */ {
/*     */   private static final int BITS_PER_ENCODED_BYTE = 6;
/*     */   private static final int BYTES_PER_UNENCODED_BLOCK = 3;
/*     */   private static final int BYTES_PER_ENCODED_BLOCK = 4;
/*     */   private static final int ALPHABET_LENGTH = 64;
/*     */   private static final int DECODING_TABLE_LENGTH = 256;
/*     */   
/*     */   public static class Builder
/*     */     extends BaseNCodec.AbstractBuilder<Base64, Builder>
/*     */   {
/*     */     public Builder() {
/*  83 */       super(Base64.STANDARD_ENCODE_TABLE);
/*     */     }
/*     */ 
/*     */     
/*     */     public Base64 get() {
/*  88 */       return new Base64(getLineLength(), getLineSeparator(), getPadding(), getEncodeTable(), getDecodingPolicy());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setUrlSafe(boolean urlSafe) {
/*  98 */       return setEncodeTable(Base64.toUrlSafeEncodeTable(urlSafe));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private static final byte[] STANDARD_ENCODE_TABLE = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   private static final byte[] URL_SAFE_ENCODE_TABLE = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   private static final byte[] DECODE_TABLE = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, 62, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51 };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MASK_6BITS = 63;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MASK_4BITS = 15;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MASK_2BITS = 3;
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] encodeTable;
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] decodeTable;
/*     */ 
/*     */   
/*     */   private final byte[] lineSeparator;
/*     */ 
/*     */   
/*     */   private final int encodeSize;
/*     */ 
/*     */   
/*     */   private final boolean isUrlSafe;
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 190 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeBase64(byte[] base64Data) {
/* 204 */     return (new Base64()).decode(base64Data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeBase64(String base64String) {
/* 219 */     return (new Base64()).decode(base64String);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger decodeInteger(byte[] pArray) {
/* 231 */     return new BigInteger(1, decodeBase64(pArray));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64(byte[] binaryData) {
/* 242 */     return encodeBase64(binaryData, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64(byte[] binaryData, boolean isChunked) {
/* 257 */     return encodeBase64(binaryData, isChunked, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64(byte[] binaryData, boolean isChunked, boolean urlSafe) {
/* 276 */     return encodeBase64(binaryData, isChunked, urlSafe, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64(byte[] binaryData, boolean isChunked, boolean urlSafe, int maxResultSize) {
/* 298 */     if (BinaryCodec.isEmpty(binaryData)) {
/* 299 */       return binaryData;
/*     */     }
/*     */ 
/*     */     
/* 303 */     Base64 b64 = isChunked ? new Base64(urlSafe) : new Base64(0, CHUNK_SEPARATOR, urlSafe);
/* 304 */     long len = b64.getEncodedLength(binaryData);
/* 305 */     if (len > maxResultSize) {
/* 306 */       throw new IllegalArgumentException("Input array too big, the output array would be bigger (" + len + ") than the specified maximum size of " + maxResultSize);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 311 */     return b64.encode(binaryData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64Chunked(byte[] binaryData) {
/* 322 */     return encodeBase64(binaryData, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeBase64String(byte[] binaryData) {
/* 337 */     return StringUtils.newStringUsAscii(encodeBase64(binaryData, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64URLSafe(byte[] binaryData) {
/* 350 */     return encodeBase64(binaryData, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeBase64URLSafeString(byte[] binaryData) {
/* 363 */     return StringUtils.newStringUsAscii(encodeBase64(binaryData, false, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeInteger(BigInteger bigInteger) {
/* 377 */     Objects.requireNonNull(bigInteger, "bigInteger");
/* 378 */     return encodeBase64(toIntegerBytes(bigInteger), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isArrayByteBase64(byte[] arrayOctet) {
/* 393 */     return isBase64(arrayOctet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBase64(byte octet) {
/* 405 */     return (octet == 61 || (octet >= 0 && octet < DECODE_TABLE.length && DECODE_TABLE[octet] != -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBase64(byte[] arrayOctet) {
/* 419 */     for (byte element : arrayOctet) {
/* 420 */       if (!isBase64(element) && !Character.isWhitespace(element)) {
/* 421 */         return false;
/*     */       }
/*     */     } 
/* 424 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBase64(String base64) {
/* 438 */     return isBase64(StringUtils.getBytesUtf8(base64));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] toIntegerBytes(BigInteger bigInt) {
/* 449 */     int bitlen = bigInt.bitLength();
/*     */     
/* 451 */     bitlen = bitlen + 7 >> 3 << 3;
/* 452 */     byte[] bigBytes = bigInt.toByteArray();
/*     */     
/* 454 */     if (bigInt.bitLength() % 8 != 0 && bigInt.bitLength() / 8 + 1 == bitlen / 8) {
/* 455 */       return bigBytes;
/*     */     }
/*     */     
/* 458 */     int startSrc = 0;
/* 459 */     int len = bigBytes.length;
/*     */ 
/*     */     
/* 462 */     if (bigInt.bitLength() % 8 == 0) {
/* 463 */       startSrc = 1;
/* 464 */       len--;
/*     */     } 
/* 466 */     int startDst = bitlen / 8 - len;
/* 467 */     byte[] resizedBytes = new byte[bitlen / 8];
/* 468 */     System.arraycopy(bigBytes, startSrc, resizedBytes, startDst, len);
/* 469 */     return resizedBytes;
/*     */   }
/*     */   
/*     */   private static byte[] toUrlSafeEncodeTable(boolean urlSafe) {
/* 473 */     return urlSafe ? URL_SAFE_ENCODE_TABLE : STANDARD_ENCODE_TABLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64() {
/* 512 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64(boolean urlSafe) {
/* 530 */     this(76, CHUNK_SEPARATOR, urlSafe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64(int lineLength) {
/* 554 */     this(lineLength, CHUNK_SEPARATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64(int lineLength, byte[] lineSeparator) {
/* 581 */     this(lineLength, lineSeparator, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64(int lineLength, byte[] lineSeparator, boolean urlSafe) {
/* 612 */     this(lineLength, lineSeparator, (byte)61, toUrlSafeEncodeTable(urlSafe), DECODING_POLICY_DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64(int lineLength, byte[] lineSeparator, boolean urlSafe, CodecPolicy decodingPolicy) {
/* 644 */     this(lineLength, lineSeparator, (byte)61, toUrlSafeEncodeTable(urlSafe), decodingPolicy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Base64(int lineLength, byte[] lineSeparator, byte padding, byte[] encodeTable, CodecPolicy decodingPolicy) {
/* 668 */     super(3, 4, lineLength, toLength(lineSeparator), padding, decodingPolicy);
/* 669 */     Objects.requireNonNull(encodeTable, "encodeTable");
/* 670 */     if (encodeTable.length != 64) {
/* 671 */       throw new IllegalArgumentException("encodeTable must have exactly 64 entries.");
/*     */     }
/* 673 */     this.isUrlSafe = (encodeTable == URL_SAFE_ENCODE_TABLE);
/* 674 */     if (encodeTable == STANDARD_ENCODE_TABLE || this.isUrlSafe) {
/* 675 */       this.decodeTable = DECODE_TABLE;
/*     */       
/* 677 */       this.encodeTable = encodeTable;
/*     */     } else {
/* 679 */       this.encodeTable = (byte[])encodeTable.clone();
/* 680 */       this.decodeTable = calculateDecodeTable(this.encodeTable);
/*     */     } 
/*     */ 
/*     */     
/* 684 */     if (lineSeparator != null) {
/* 685 */       byte[] lineSeparatorCopy = (byte[])lineSeparator.clone();
/* 686 */       if (containsAlphabetOrPad(lineSeparatorCopy)) {
/* 687 */         String sep = StringUtils.newStringUtf8(lineSeparatorCopy);
/* 688 */         throw new IllegalArgumentException("lineSeparator must not contain base64 characters: [" + sep + "]");
/*     */       } 
/* 690 */       if (lineLength > 0) {
/* 691 */         this.encodeSize = 4 + lineSeparatorCopy.length;
/* 692 */         this.lineSeparator = lineSeparatorCopy;
/*     */       } else {
/* 694 */         this.encodeSize = 4;
/* 695 */         this.lineSeparator = null;
/*     */       } 
/*     */     } else {
/* 698 */       this.encodeSize = 4;
/* 699 */       this.lineSeparator = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] calculateDecodeTable(byte[] encodeTable) {
/* 710 */     byte[] decodeTable = new byte[256];
/* 711 */     Arrays.fill(decodeTable, (byte)-1);
/* 712 */     for (int i = 0; i < encodeTable.length; i++) {
/* 713 */       decodeTable[encodeTable[i]] = (byte)i;
/*     */     }
/* 715 */     return decodeTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decode(byte[] input, int inPos, int inAvail, BaseNCodec.Context context) {
/* 745 */     if (context.eof) {
/*     */       return;
/*     */     }
/* 748 */     if (inAvail < 0) {
/* 749 */       context.eof = true;
/*     */     }
/* 751 */     int decodeSize = this.encodeSize - 1;
/* 752 */     for (int i = 0; i < inAvail; i++) {
/* 753 */       byte[] buffer = ensureBufferSize(decodeSize, context);
/* 754 */       byte b = input[inPos++];
/* 755 */       if (b == this.pad) {
/*     */         
/* 757 */         context.eof = true;
/*     */         break;
/*     */       } 
/* 760 */       if (b >= 0 && b < this.decodeTable.length) {
/* 761 */         int result = this.decodeTable[b];
/* 762 */         if (result >= 0) {
/* 763 */           context.modulus = (context.modulus + 1) % 4;
/* 764 */           context.ibitWorkArea = (context.ibitWorkArea << 6) + result;
/* 765 */           if (context.modulus == 0) {
/* 766 */             buffer[context.pos++] = (byte)(context.ibitWorkArea >> 16 & 0xFF);
/* 767 */             buffer[context.pos++] = (byte)(context.ibitWorkArea >> 8 & 0xFF);
/* 768 */             buffer[context.pos++] = (byte)(context.ibitWorkArea & 0xFF);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 777 */     if (context.eof && context.modulus != 0) {
/* 778 */       byte[] buffer = ensureBufferSize(decodeSize, context);
/*     */ 
/*     */ 
/*     */       
/* 782 */       switch (context.modulus) {
/*     */         
/*     */         case 1:
/* 785 */           validateTrailingCharacter();
/*     */           return;
/*     */         case 2:
/* 788 */           validateCharacter(15, context);
/* 789 */           context.ibitWorkArea >>= 4;
/* 790 */           buffer[context.pos++] = (byte)(context.ibitWorkArea & 0xFF);
/*     */           return;
/*     */         case 3:
/* 793 */           validateCharacter(3, context);
/* 794 */           context.ibitWorkArea >>= 2;
/* 795 */           buffer[context.pos++] = (byte)(context.ibitWorkArea >> 8 & 0xFF);
/* 796 */           buffer[context.pos++] = (byte)(context.ibitWorkArea & 0xFF);
/*     */           return;
/*     */       } 
/* 799 */       throw new IllegalStateException("Impossible modulus " + context.modulus);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void encode(byte[] in, int inPos, int inAvail, BaseNCodec.Context context) {
/* 827 */     if (context.eof) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 832 */     if (inAvail < 0) {
/* 833 */       context.eof = true;
/* 834 */       if (0 == context.modulus && this.lineLength == 0) {
/*     */         return;
/*     */       }
/* 837 */       byte[] buffer = ensureBufferSize(this.encodeSize, context);
/* 838 */       int savedPos = context.pos;
/* 839 */       switch (context.modulus) {
/*     */         case 0:
/*     */           break;
/*     */         
/*     */         case 1:
/* 844 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea >> 2 & 0x3F];
/*     */           
/* 846 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea << 4 & 0x3F];
/*     */           
/* 848 */           if (this.encodeTable == STANDARD_ENCODE_TABLE) {
/* 849 */             buffer[context.pos++] = this.pad;
/* 850 */             buffer[context.pos++] = this.pad;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 2:
/* 855 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea >> 10 & 0x3F];
/* 856 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea >> 4 & 0x3F];
/* 857 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea << 2 & 0x3F];
/*     */           
/* 859 */           if (this.encodeTable == STANDARD_ENCODE_TABLE) {
/* 860 */             buffer[context.pos++] = this.pad;
/*     */           }
/*     */           break;
/*     */         default:
/* 864 */           throw new IllegalStateException("Impossible modulus " + context.modulus);
/*     */       } 
/* 866 */       context.currentLinePos += context.pos - savedPos;
/*     */       
/* 868 */       if (this.lineLength > 0 && context.currentLinePos > 0) {
/* 869 */         System.arraycopy(this.lineSeparator, 0, buffer, context.pos, this.lineSeparator.length);
/* 870 */         context.pos += this.lineSeparator.length;
/*     */       } 
/*     */     } else {
/* 873 */       for (int i = 0; i < inAvail; i++) {
/* 874 */         byte[] buffer = ensureBufferSize(this.encodeSize, context);
/* 875 */         context.modulus = (context.modulus + 1) % 3;
/* 876 */         int b = in[inPos++];
/* 877 */         if (b < 0) {
/* 878 */           b += 256;
/*     */         }
/* 880 */         context.ibitWorkArea = (context.ibitWorkArea << 8) + b;
/* 881 */         if (0 == context.modulus) {
/* 882 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea >> 18 & 0x3F];
/* 883 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea >> 12 & 0x3F];
/* 884 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea >> 6 & 0x3F];
/* 885 */           buffer[context.pos++] = this.encodeTable[context.ibitWorkArea & 0x3F];
/* 886 */           context.currentLinePos += 4;
/* 887 */           if (this.lineLength > 0 && this.lineLength <= context.currentLinePos) {
/* 888 */             System.arraycopy(this.lineSeparator, 0, buffer, context.pos, this.lineSeparator.length);
/* 889 */             context.pos += this.lineSeparator.length;
/* 890 */             context.currentLinePos = 0;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getLineSeparator() {
/* 903 */     return this.lineSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInAlphabet(byte octet) {
/* 915 */     return (octet >= 0 && octet < this.decodeTable.length && this.decodeTable[octet] != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUrlSafe() {
/* 925 */     return this.isUrlSafe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateCharacter(int emptyBitsMask, BaseNCodec.Context context) {
/* 942 */     if (isStrictDecoding() && (context.ibitWorkArea & emptyBitsMask) != 0) {
/* 943 */       throw new IllegalArgumentException("Strict decoding: Last encoded character (before the paddings if any) is a valid base 64 alphabet but not a possible encoding. Expected the discarded bits from the character to be zero.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateTrailingCharacter() {
/* 957 */     if (isStrictDecoding())
/* 958 */       throw new IllegalArgumentException("Strict decoding: Last encoded character (before the paddings if any) is a valid base 64 alphabet but not a possible encoding. Decoding requires at least two trailing 6-bit characters to create bytes."); 
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\binary\Base64.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */