/*     */ package org.apache.commons.codec.net;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.BitSet;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringDecoder;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QCodec
/*     */   extends RFC1522Codec
/*     */   implements StringEncoder, StringDecoder
/*     */ {
/*  58 */   private static final BitSet PRINTABLE_CHARS = new BitSet(256);
/*     */   
/*     */   private static final byte SPACE = 32;
/*     */   
/*     */   static {
/*  63 */     PRINTABLE_CHARS.set(32);
/*  64 */     PRINTABLE_CHARS.set(33);
/*  65 */     PRINTABLE_CHARS.set(34);
/*  66 */     PRINTABLE_CHARS.set(35);
/*  67 */     PRINTABLE_CHARS.set(36);
/*  68 */     PRINTABLE_CHARS.set(37);
/*  69 */     PRINTABLE_CHARS.set(38);
/*  70 */     PRINTABLE_CHARS.set(39);
/*  71 */     PRINTABLE_CHARS.set(40);
/*  72 */     PRINTABLE_CHARS.set(41);
/*  73 */     PRINTABLE_CHARS.set(42);
/*  74 */     PRINTABLE_CHARS.set(43);
/*  75 */     PRINTABLE_CHARS.set(44);
/*  76 */     PRINTABLE_CHARS.set(45);
/*  77 */     PRINTABLE_CHARS.set(46);
/*  78 */     PRINTABLE_CHARS.set(47); int i;
/*  79 */     for (i = 48; i <= 57; i++) {
/*  80 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  82 */     PRINTABLE_CHARS.set(58);
/*  83 */     PRINTABLE_CHARS.set(59);
/*  84 */     PRINTABLE_CHARS.set(60);
/*  85 */     PRINTABLE_CHARS.set(62);
/*  86 */     PRINTABLE_CHARS.set(64);
/*  87 */     for (i = 65; i <= 90; i++) {
/*  88 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  90 */     PRINTABLE_CHARS.set(91);
/*  91 */     PRINTABLE_CHARS.set(92);
/*  92 */     PRINTABLE_CHARS.set(93);
/*  93 */     PRINTABLE_CHARS.set(94);
/*  94 */     PRINTABLE_CHARS.set(96);
/*  95 */     for (i = 97; i <= 122; i++) {
/*  96 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  98 */     PRINTABLE_CHARS.set(123);
/*  99 */     PRINTABLE_CHARS.set(124);
/* 100 */     PRINTABLE_CHARS.set(125);
/* 101 */     PRINTABLE_CHARS.set(126);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte UNDERSCORE = 95;
/*     */ 
/*     */   
/*     */   private boolean encodeBlanks;
/*     */ 
/*     */   
/*     */   public QCodec() {
/* 113 */     this(StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QCodec(Charset charset) {
/* 126 */     super(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QCodec(String charsetName) {
/* 140 */     this(Charset.forName(charsetName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(Object obj) throws DecoderException {
/* 156 */     if (obj == null) {
/* 157 */       return null;
/*     */     }
/* 159 */     if (obj instanceof String) {
/* 160 */       return decode((String)obj);
/*     */     }
/* 162 */     throw new DecoderException("Objects of type " + obj.getClass().getName() + " cannot be decoded using Q codec");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decode(String str) throws DecoderException {
/*     */     try {
/* 178 */       return decodeText(str);
/* 179 */     } catch (UnsupportedEncodingException e) {
/* 180 */       throw new DecoderException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected byte[] doDecoding(byte[] bytes) throws DecoderException {
/* 186 */     if (bytes == null) {
/* 187 */       return null;
/*     */     }
/* 189 */     boolean hasUnderscores = false;
/* 190 */     for (byte b : bytes) {
/* 191 */       if (b == 95) {
/* 192 */         hasUnderscores = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 196 */     if (hasUnderscores) {
/* 197 */       byte[] tmp = new byte[bytes.length];
/* 198 */       for (int i = 0; i < bytes.length; i++) {
/* 199 */         byte b = bytes[i];
/* 200 */         if (b != 95) {
/* 201 */           tmp[i] = b;
/*     */         } else {
/* 203 */           tmp[i] = 32;
/*     */         } 
/*     */       } 
/* 206 */       return QuotedPrintableCodec.decodeQuotedPrintable(tmp);
/*     */     } 
/* 208 */     return QuotedPrintableCodec.decodeQuotedPrintable(bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected byte[] doEncoding(byte[] bytes) {
/* 213 */     if (bytes == null) {
/* 214 */       return null;
/*     */     }
/* 216 */     byte[] data = QuotedPrintableCodec.encodeQuotedPrintable(PRINTABLE_CHARS, bytes);
/* 217 */     if (this.encodeBlanks) {
/* 218 */       for (int i = 0; i < data.length; i++) {
/* 219 */         if (data[i] == 32) {
/* 220 */           data[i] = 95;
/*     */         }
/*     */       } 
/*     */     }
/* 224 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 238 */     if (obj == null) {
/* 239 */       return null;
/*     */     }
/* 241 */     if (obj instanceof String) {
/* 242 */       return encode((String)obj);
/*     */     }
/* 244 */     throw new EncoderException("Objects of type " + obj.getClass().getName() + " cannot be encoded using Q codec");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String sourceStr) throws EncoderException {
/* 258 */     return encode(sourceStr, getCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String sourceStr, Charset sourceCharset) throws EncoderException {
/* 274 */     return encodeText(sourceStr, sourceCharset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String sourceStr, String sourceCharset) throws EncoderException {
/*     */     try {
/* 290 */       return encodeText(sourceStr, sourceCharset);
/* 291 */     } catch (UnsupportedCharsetException e) {
/* 292 */       throw new EncoderException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getEncoding() {
/* 298 */     return "Q";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEncodeBlanks() {
/* 307 */     return this.encodeBlanks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodeBlanks(boolean b) {
/* 317 */     this.encodeBlanks = b;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\net\QCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */