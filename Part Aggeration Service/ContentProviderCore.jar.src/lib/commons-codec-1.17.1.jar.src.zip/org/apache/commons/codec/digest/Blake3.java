/*     */ package org.apache.commons.codec.digest;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Blake3
/*     */ {
/*     */   private static final int BLOCK_LEN = 64;
/*     */   private static final int BLOCK_INTS = 16;
/*     */   private static final int KEY_LEN = 32;
/*     */   private static final int KEY_INTS = 8;
/*     */   private static final int OUT_LEN = 32;
/*     */   private static final int CHUNK_LEN = 1024;
/*     */   private static final int CHAINING_VALUE_INTS = 8;
/*     */   
/*     */   private static final class ChunkState
/*     */   {
/*     */     private int[] chainingValue;
/*     */     private final long chunkCounter;
/*     */     private final int flags;
/*  84 */     private final byte[] block = new byte[64];
/*     */     private int blockLength;
/*     */     private int blocksCompressed;
/*     */     
/*     */     private ChunkState(int[] key, long chunkCounter, int flags) {
/*  89 */       this.chainingValue = key;
/*  90 */       this.chunkCounter = chunkCounter;
/*  91 */       this.flags = flags;
/*     */     }
/*     */     
/*     */     private int length() {
/*  95 */       return 64 * this.blocksCompressed + this.blockLength;
/*     */     }
/*     */     
/*     */     private Blake3.Output output() {
/*  99 */       int[] blockWords = Blake3.unpackInts(this.block, 16);
/* 100 */       int outputFlags = this.flags | startFlag() | 0x2;
/* 101 */       return new Blake3.Output(this.chainingValue, blockWords, this.chunkCounter, this.blockLength, outputFlags);
/*     */     }
/*     */     
/*     */     private int startFlag() {
/* 105 */       return (this.blocksCompressed == 0) ? 1 : 0;
/*     */     }
/*     */     
/*     */     private void update(byte[] input, int offset, int length) {
/* 109 */       while (length > 0) {
/* 110 */         if (this.blockLength == 64) {
/*     */ 
/*     */           
/* 113 */           int[] blockWords = Blake3.unpackInts(this.block, 16);
/* 114 */           this.chainingValue = Arrays.copyOf(Blake3
/* 115 */               .compress(this.chainingValue, blockWords, 64, this.chunkCounter, this.flags | startFlag()), 8);
/*     */           
/* 117 */           this.blocksCompressed++;
/* 118 */           this.blockLength = 0;
/* 119 */           Arrays.fill(this.block, (byte)0);
/*     */         } 
/*     */         
/* 122 */         int want = 64 - this.blockLength;
/* 123 */         int take = Math.min(want, length);
/* 124 */         System.arraycopy(input, offset, this.block, this.blockLength, take);
/* 125 */         this.blockLength += take;
/* 126 */         offset += take;
/* 127 */         length -= take;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class EngineState
/*     */   {
/*     */     private final int[] key;
/*     */     
/*     */     private final int flags;
/* 138 */     private final int[][] cvStack = new int[54][];
/*     */     private int stackLen;
/*     */     private Blake3.ChunkState state;
/*     */     
/*     */     private EngineState(int[] key, int flags) {
/* 143 */       this.key = key;
/* 144 */       this.flags = flags;
/* 145 */       this.state = new Blake3.ChunkState(key, 0L, flags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void addChunkCV(int[] firstCV, long totalChunks) {
/* 157 */       int[] newCV = firstCV;
/* 158 */       long chunkCounter = totalChunks;
/* 159 */       while ((chunkCounter & 0x1L) == 0L) {
/* 160 */         newCV = Blake3.parentChainingValue(popCV(), newCV, this.key, this.flags);
/* 161 */         chunkCounter >>= 1L;
/*     */       } 
/* 163 */       pushCV(newCV);
/*     */     }
/*     */     
/*     */     private void inputData(byte[] in, int offset, int length) {
/* 167 */       while (length > 0) {
/*     */ 
/*     */         
/* 170 */         if (this.state.length() == 1024) {
/* 171 */           int[] chunkCV = this.state.output().chainingValue();
/* 172 */           long totalChunks = this.state.chunkCounter + 1L;
/* 173 */           addChunkCV(chunkCV, totalChunks);
/* 174 */           this.state = new Blake3.ChunkState(this.key, totalChunks, this.flags);
/*     */         } 
/*     */ 
/*     */         
/* 178 */         int want = 1024 - this.state.length();
/* 179 */         int take = Math.min(want, length);
/* 180 */         this.state.update(in, offset, take);
/* 181 */         offset += take;
/* 182 */         length -= take;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void outputHash(byte[] out, int offset, int length) {
/* 190 */       Blake3.Output output = this.state.output();
/* 191 */       int parentNodesRemaining = this.stackLen;
/* 192 */       while (parentNodesRemaining-- > 0) {
/* 193 */         int[] parentCV = this.cvStack[parentNodesRemaining];
/* 194 */         output = Blake3.parentOutput(parentCV, output.chainingValue(), this.key, this.flags);
/*     */       } 
/* 196 */       output.rootOutputBytes(out, offset, length);
/*     */     }
/*     */     
/*     */     private int[] popCV() {
/* 200 */       return this.cvStack[--this.stackLen];
/*     */     }
/*     */     
/*     */     private void pushCV(int[] cv) {
/* 204 */       this.cvStack[this.stackLen++] = cv;
/*     */     }
/*     */     
/*     */     private void reset() {
/* 208 */       this.stackLen = 0;
/* 209 */       Arrays.fill((Object[])this.cvStack, (Object)null);
/* 210 */       this.state = new Blake3.ChunkState(this.key, 0L, this.flags);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Output
/*     */   {
/*     */     private final int[] inputChainingValue;
/*     */     
/*     */     private final int[] blockWords;
/*     */     
/*     */     private final long counter;
/*     */     
/*     */     private final int blockLength;
/*     */     private final int flags;
/*     */     
/*     */     private Output(int[] inputChainingValue, int[] blockWords, long counter, int blockLength, int flags) {
/* 227 */       this.inputChainingValue = inputChainingValue;
/* 228 */       this.blockWords = blockWords;
/* 229 */       this.counter = counter;
/* 230 */       this.blockLength = blockLength;
/* 231 */       this.flags = flags;
/*     */     }
/*     */     
/*     */     private int[] chainingValue() {
/* 235 */       return Arrays.copyOf(Blake3.compress(this.inputChainingValue, this.blockWords, this.blockLength, this.counter, this.flags), 8);
/*     */     }
/*     */     
/*     */     private void rootOutputBytes(byte[] out, int offset, int length) {
/* 239 */       int outputBlockCounter = 0;
/* 240 */       while (length > 0) {
/* 241 */         int chunkLength = Math.min(64, length);
/* 242 */         length -= chunkLength;
/* 243 */         int[] words = Blake3.compress(this.inputChainingValue, this.blockWords, this.blockLength, outputBlockCounter++, this.flags | 0x8);
/* 244 */         int wordCounter = 0;
/* 245 */         while (chunkLength > 0) {
/* 246 */           int wordLength = Math.min(4, chunkLength);
/* 247 */           Blake3.packInt(words[wordCounter++], out, offset, wordLength);
/* 248 */           offset += wordLength;
/* 249 */           chunkLength -= wordLength;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   private static final int[] IV = new int[] { 1779033703, -1150833019, 1013904242, -1521486534, 1359893119, -1694144372, 528734635, 1541459225 };
/*     */   
/*     */   private static final int CHUNK_START = 1;
/*     */   
/*     */   private static final int CHUNK_END = 2;
/*     */   
/*     */   private static final int PARENT = 4;
/*     */   
/*     */   private static final int ROOT = 8;
/*     */   
/*     */   private static final int KEYED_HASH = 16;
/*     */   
/*     */   private static final int DERIVE_KEY_CONTEXT = 32;
/*     */   
/*     */   private static final int DERIVE_KEY_MATERIAL = 64;
/* 281 */   private static final byte[][] MSG_SCHEDULE = new byte[][] { { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }, { 2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8 }, { 3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1 }, { 10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6 }, { 12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4 }, { 9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7 }, { 11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13 } };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final EngineState engineState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkBufferArgs(byte[] buffer, int offset, int length) {
/* 293 */     Objects.requireNonNull(buffer);
/* 294 */     if (offset < 0) {
/* 295 */       throw new IndexOutOfBoundsException("Offset must be non-negative");
/*     */     }
/* 297 */     if (length < 0) {
/* 298 */       throw new IndexOutOfBoundsException("Length must be non-negative");
/*     */     }
/* 300 */     int bufferLength = buffer.length;
/* 301 */     if (offset > bufferLength - length) {
/* 302 */       throw new IndexOutOfBoundsException("Offset " + offset + " and length " + length + " out of bounds with buffer length " + bufferLength);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int[] compress(int[] chainingValue, int[] blockWords, int blockLength, long counter, int flags) {
/* 307 */     int[] state = Arrays.copyOf(chainingValue, 16);
/* 308 */     System.arraycopy(IV, 0, state, 8, 4);
/* 309 */     state[12] = (int)counter;
/* 310 */     state[13] = (int)(counter >> 32L);
/* 311 */     state[14] = blockLength;
/* 312 */     state[15] = flags; int i;
/* 313 */     for (i = 0; i < 7; i++) {
/* 314 */       byte[] schedule = MSG_SCHEDULE[i];
/* 315 */       round(state, blockWords, schedule);
/*     */     } 
/* 317 */     for (i = 0; i < state.length / 2; i++) {
/* 318 */       state[i] = state[i] ^ state[i + 8];
/* 319 */       state[i + 8] = state[i + 8] ^ chainingValue[i];
/*     */     } 
/* 321 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void g(int[] state, int a, int b, int c, int d, int mx, int my) {
/* 328 */     state[a] = state[a] + state[b] + mx;
/* 329 */     state[d] = Integer.rotateRight(state[d] ^ state[a], 16);
/* 330 */     state[c] = state[c] + state[d];
/* 331 */     state[b] = Integer.rotateRight(state[b] ^ state[c], 12);
/* 332 */     state[a] = state[a] + state[b] + my;
/* 333 */     state[d] = Integer.rotateRight(state[d] ^ state[a], 8);
/* 334 */     state[c] = state[c] + state[d];
/* 335 */     state[b] = Integer.rotateRight(state[b] ^ state[c], 7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] hash(byte[] data) {
/* 346 */     return initHash().update(data).doFinalize(32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Blake3 initHash() {
/* 355 */     return new Blake3(IV, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Blake3 initKeyDerivationFunction(byte[] kdfContext) {
/* 368 */     Objects.requireNonNull(kdfContext);
/* 369 */     EngineState kdf = new EngineState(IV, 32);
/* 370 */     kdf.inputData(kdfContext, 0, kdfContext.length);
/* 371 */     byte[] key = new byte[32];
/* 372 */     kdf.outputHash(key, 0, key.length);
/* 373 */     return new Blake3(unpackInts(key, 8), 64);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Blake3 initKeyedHash(byte[] key) {
/* 386 */     Objects.requireNonNull(key);
/* 387 */     if (key.length != 32) {
/* 388 */       throw new IllegalArgumentException("Blake3 keys must be 32 bytes");
/*     */     }
/* 390 */     return new Blake3(unpackInts(key, 8), 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] keyedHash(byte[] key, byte[] data) {
/* 402 */     return initKeyedHash(key).update(data).doFinalize(32);
/*     */   }
/*     */   
/*     */   private static void packInt(int value, byte[] dst, int off, int len) {
/* 406 */     for (int i = 0; i < len; i++) {
/* 407 */       dst[off + i] = (byte)(value >>> i * 8);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int[] parentChainingValue(int[] leftChildCV, int[] rightChildCV, int[] key, int flags) {
/* 412 */     return parentOutput(leftChildCV, rightChildCV, key, flags).chainingValue();
/*     */   }
/*     */   
/*     */   private static Output parentOutput(int[] leftChildCV, int[] rightChildCV, int[] key, int flags) {
/* 416 */     int[] blockWords = Arrays.copyOf(leftChildCV, 16);
/* 417 */     System.arraycopy(rightChildCV, 0, blockWords, 8, 8);
/* 418 */     return new Output((int[])key.clone(), blockWords, 0L, 64, flags | 0x4);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void round(int[] state, int[] msg, byte[] schedule) {
/* 423 */     g(state, 0, 4, 8, 12, msg[schedule[0]], msg[schedule[1]]);
/* 424 */     g(state, 1, 5, 9, 13, msg[schedule[2]], msg[schedule[3]]);
/* 425 */     g(state, 2, 6, 10, 14, msg[schedule[4]], msg[schedule[5]]);
/* 426 */     g(state, 3, 7, 11, 15, msg[schedule[6]], msg[schedule[7]]);
/*     */ 
/*     */     
/* 429 */     g(state, 0, 5, 10, 15, msg[schedule[8]], msg[schedule[9]]);
/* 430 */     g(state, 1, 6, 11, 12, msg[schedule[10]], msg[schedule[11]]);
/* 431 */     g(state, 2, 7, 8, 13, msg[schedule[12]], msg[schedule[13]]);
/* 432 */     g(state, 3, 4, 9, 14, msg[schedule[14]], msg[schedule[15]]);
/*     */   }
/*     */   
/*     */   private static int unpackInt(byte[] buf, int off) {
/* 436 */     return buf[off] & 0xFF | (buf[off + 1] & 0xFF) << 8 | (buf[off + 2] & 0xFF) << 16 | (buf[off + 3] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */   private static int[] unpackInts(byte[] buf, int nrInts) {
/* 440 */     int[] values = new int[nrInts];
/* 441 */     for (int i = 0, off = 0; i < nrInts; i++, off += 4) {
/* 442 */       values[i] = unpackInt(buf, off);
/*     */     }
/* 444 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Blake3(int[] key, int flags) {
/* 450 */     this.engineState = new EngineState(key, flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blake3 doFinalize(byte[] out) {
/* 462 */     return doFinalize(out, 0, out.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blake3 doFinalize(byte[] out, int offset, int length) {
/* 478 */     checkBufferArgs(out, offset, length);
/* 479 */     this.engineState.outputHash(out, offset, length);
/* 480 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] doFinalize(int nrBytes) {
/* 491 */     if (nrBytes < 0) {
/* 492 */       throw new IllegalArgumentException("Requested bytes must be non-negative");
/*     */     }
/* 494 */     byte[] hash = new byte[nrBytes];
/* 495 */     doFinalize(hash);
/* 496 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blake3 reset() {
/* 504 */     this.engineState.reset();
/* 505 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blake3 update(byte[] in) {
/* 516 */     return update(in, 0, in.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blake3 update(byte[] in, int offset, int length) {
/* 531 */     checkBufferArgs(in, offset, length);
/* 532 */     this.engineState.inputData(in, offset, length);
/* 533 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\Blake3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */