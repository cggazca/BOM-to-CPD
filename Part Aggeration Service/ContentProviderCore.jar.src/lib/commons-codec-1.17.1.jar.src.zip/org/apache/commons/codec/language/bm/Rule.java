/*     */ package org.apache.commons.codec.language.bm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Scanner;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.codec.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rule
/*     */ {
/*     */   public static final class Phoneme
/*     */     implements PhonemeExpr
/*     */   {
/*     */     public static final Comparator<Phoneme> COMPARATOR;
/*     */     private final StringBuilder phonemeText;
/*     */     private final Languages.LanguageSet languages;
/*     */     
/*     */     static {
/*  89 */       COMPARATOR = ((o1, o2) -> {
/*     */           int o1Length = o1.phonemeText.length();
/*     */           int o2Length = o2.phonemeText.length();
/*     */           for (int i = 0; i < o1Length; i++) {
/*     */             if (i >= o2Length) {
/*     */               return 1;
/*     */             }
/*     */             int c = o1.phonemeText.charAt(i) - o2.phonemeText.charAt(i);
/*     */             if (c != 0) {
/*     */               return c;
/*     */             }
/*     */           } 
/*     */           return (o1Length < o2Length) ? -1 : 0;
/*     */         });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Phoneme(CharSequence phonemeText, Languages.LanguageSet languages) {
/* 113 */       this.phonemeText = new StringBuilder(phonemeText);
/* 114 */       this.languages = languages;
/*     */     }
/*     */     
/*     */     public Phoneme(Phoneme phonemeLeft, Phoneme phonemeRight) {
/* 118 */       this(phonemeLeft.phonemeText, phonemeLeft.languages);
/* 119 */       this.phonemeText.append(phonemeRight.phonemeText);
/*     */     }
/*     */     
/*     */     public Phoneme(Phoneme phonemeLeft, Phoneme phonemeRight, Languages.LanguageSet languages) {
/* 123 */       this(phonemeLeft.phonemeText, languages);
/* 124 */       this.phonemeText.append(phonemeRight.phonemeText);
/*     */     }
/*     */     
/*     */     public Phoneme append(CharSequence str) {
/* 128 */       this.phonemeText.append(str);
/* 129 */       return this;
/*     */     }
/*     */     
/*     */     public Languages.LanguageSet getLanguages() {
/* 133 */       return this.languages;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterable<Phoneme> getPhonemes() {
/* 138 */       return Collections.singleton(this);
/*     */     }
/*     */     
/*     */     public CharSequence getPhonemeText() {
/* 142 */       return this.phonemeText;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Phoneme join(Phoneme right) {
/* 154 */       return new Phoneme(this.phonemeText.toString() + right.phonemeText.toString(), this.languages
/* 155 */           .restrictTo(right.languages));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Phoneme mergeWithLanguage(Languages.LanguageSet lang) {
/* 166 */       return new Phoneme(this.phonemeText.toString(), this.languages.merge(lang));
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 171 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 176 */       return this.phonemeText.toString() + "[" + this.languages + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface PhonemeExpr
/*     */   {
/*     */     Iterable<Rule.Phoneme> getPhonemes();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default int size() {
/* 191 */       return (int)Math.min(getPhonemes().spliterator().getExactSizeIfKnown(), 2147483647L);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class PhonemeList
/*     */     implements PhonemeExpr {
/*     */     private final List<Rule.Phoneme> phonemeList;
/*     */     
/*     */     public PhonemeList(List<Rule.Phoneme> phonemes) {
/* 200 */       this.phonemeList = phonemes;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Rule.Phoneme> getPhonemes() {
/* 205 */       return this.phonemeList;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 210 */       return this.phonemeList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final RPattern ALL_STRINGS_RMATCHER = input -> true;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ALL = "ALL";
/*     */ 
/*     */   
/*     */   private static final String DOUBLE_QUOTE = "\"";
/*     */ 
/*     */   
/*     */   private static final String HASH_INCLUDE = "#include";
/*     */ 
/*     */   
/* 229 */   private static final int HASH_INCLUDE_LENGTH = "#include".length();
/*     */   
/* 231 */   private static final Map<NameType, Map<RuleType, Map<String, Map<String, List<Rule>>>>> RULES = new EnumMap<>(NameType.class); private final RPattern lContext; private final String pattern; private final PhonemeExpr phoneme;
/*     */   private final RPattern rContext;
/*     */   
/*     */   static {
/* 235 */     for (NameType s : NameType.values()) {
/* 236 */       Map<RuleType, Map<String, Map<String, List<Rule>>>> rts = new EnumMap<>(RuleType.class);
/*     */ 
/*     */       
/* 239 */       for (RuleType rt : RuleType.values()) {
/* 240 */         Map<String, Map<String, List<Rule>>> rs = new HashMap<>();
/*     */         
/* 242 */         Languages ls = Languages.getInstance(s);
/* 243 */         ls.getLanguages().forEach(l -> { try { Scanner scanner = createScanner(s, rt, l); try { rs.put(l, parseRules(scanner, createResourceName(s, rt, l))); if (scanner != null)
/* 244 */                     scanner.close();  } catch (Throwable throwable) { if (scanner != null) try { scanner.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */                  }
/* 246 */               catch (IllegalStateException e)
/*     */               { throw new IllegalStateException("Problem processing " + createResourceName(s, rt, l), e); }
/*     */             
/*     */             });
/* 250 */         if (!rt.equals(RuleType.RULES)) {
/* 251 */           Scanner scanner = createScanner(s, rt, "common"); 
/* 252 */           try { rs.put("common", parseRules(scanner, createResourceName(s, rt, "common")));
/* 253 */             if (scanner != null) scanner.close();  } catch (Throwable throwable) { if (scanner != null)
/*     */               try { scanner.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */         
/* 256 */         }  rts.put(rt, Collections.unmodifiableMap(rs));
/*     */       } 
/*     */       
/* 259 */       RULES.put(s, Collections.unmodifiableMap(rts));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean contains(CharSequence chars, char input) {
/* 264 */     return chars.chars().anyMatch(c -> (c == input));
/*     */   }
/*     */   
/*     */   private static String createResourceName(NameType nameType, RuleType rt, String lang) {
/* 268 */     return String.format("org/apache/commons/codec/language/bm/%s_%s_%s.txt", new Object[] { nameType
/* 269 */           .getName(), rt.getName(), lang });
/*     */   }
/*     */ 
/*     */   
/*     */   private static Scanner createScanner(NameType nameType, RuleType rt, String lang) {
/* 274 */     String resName = createResourceName(nameType, rt, lang);
/* 275 */     return new Scanner(Resources.getInputStream(resName), ResourceConstants.ENCODING);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Scanner createScanner(String lang) {
/* 280 */     String resName = String.format("org/apache/commons/codec/language/bm/%s.txt", new Object[] { lang });
/* 281 */     return new Scanner(Resources.getInputStream(resName), ResourceConstants.ENCODING);
/*     */   }
/*     */   
/*     */   private static boolean endsWith(CharSequence input, CharSequence suffix) {
/* 285 */     int suffixLength = suffix.length();
/* 286 */     int inputLength = input.length();
/*     */     
/* 288 */     if (suffixLength > inputLength) {
/* 289 */       return false;
/*     */     }
/* 291 */     for (int i = inputLength - 1, j = suffixLength - 1; j >= 0; i--, j--) {
/* 292 */       if (input.charAt(i) != suffix.charAt(j)) {
/* 293 */         return false;
/*     */       }
/*     */     } 
/* 296 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Rule> getInstance(NameType nameType, RuleType rt, Languages.LanguageSet langs) {
/* 312 */     Map<String, List<Rule>> ruleMap = getInstanceMap(nameType, rt, langs);
/* 313 */     List<Rule> allRules = new ArrayList<>();
/* 314 */     ruleMap.values().forEach(rules -> allRules.addAll(rules));
/* 315 */     return allRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Rule> getInstance(NameType nameType, RuleType rt, String lang) {
/* 330 */     return getInstance(nameType, rt, Languages.LanguageSet.from(new HashSet<>(Arrays.asList(new String[] { lang }))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, List<Rule>> getInstanceMap(NameType nameType, RuleType rt, Languages.LanguageSet langs) {
/* 347 */     return langs.isSingleton() ? getInstanceMap(nameType, rt, langs.getAny()) : 
/* 348 */       getInstanceMap(nameType, rt, "any");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, List<Rule>> getInstanceMap(NameType nameType, RuleType rt, String lang) {
/* 365 */     Map<String, List<Rule>> rules = (Map<String, List<Rule>>)((Map)((Map)RULES.get(nameType)).get(rt)).get(lang);
/*     */     
/* 367 */     if (rules == null) {
/* 368 */       throw new IllegalArgumentException(String.format("No rules found for %s, %s, %s.", new Object[] { nameType
/* 369 */               .getName(), rt.getName(), lang }));
/*     */     }
/*     */     
/* 372 */     return rules;
/*     */   }
/*     */   
/*     */   private static Phoneme parsePhoneme(String ph) {
/* 376 */     int open = ph.indexOf("[");
/* 377 */     if (open >= 0) {
/* 378 */       if (!ph.endsWith("]")) {
/* 379 */         throw new IllegalArgumentException("Phoneme expression contains a '[' but does not end in ']'");
/*     */       }
/* 381 */       String before = ph.substring(0, open);
/* 382 */       String in = ph.substring(open + 1, ph.length() - 1);
/* 383 */       Set<String> langs = new HashSet<>(Arrays.asList(in.split("[+]")));
/*     */       
/* 385 */       return new Phoneme(before, Languages.LanguageSet.from(langs));
/*     */     } 
/* 387 */     return new Phoneme(ph, Languages.ANY_LANGUAGE);
/*     */   }
/*     */   
/*     */   private static PhonemeExpr parsePhonemeExpr(String ph) {
/* 391 */     if (ph.startsWith("(")) {
/* 392 */       if (!ph.endsWith(")")) {
/* 393 */         throw new IllegalArgumentException("Phoneme starts with '(' so must end with ')'");
/*     */       }
/*     */       
/* 396 */       List<Phoneme> phs = new ArrayList<>();
/* 397 */       String body = ph.substring(1, ph.length() - 1);
/* 398 */       for (String part : body.split("[|]")) {
/* 399 */         phs.add(parsePhoneme(part));
/*     */       }
/* 401 */       if (body.startsWith("|") || body.endsWith("|")) {
/* 402 */         phs.add(new Phoneme("", Languages.ANY_LANGUAGE));
/*     */       }
/*     */       
/* 405 */       return new PhonemeList(phs);
/*     */     } 
/* 407 */     return parsePhoneme(ph);
/*     */   }
/*     */   
/*     */   private static Map<String, List<Rule>> parseRules(Scanner scanner, final String location) {
/* 411 */     Map<String, List<Rule>> lines = new HashMap<>();
/* 412 */     int currentLine = 0;
/*     */     
/* 414 */     boolean inMultilineComment = false;
/* 415 */     while (scanner.hasNextLine()) {
/* 416 */       currentLine++;
/* 417 */       String rawLine = scanner.nextLine();
/* 418 */       String line = rawLine;
/*     */       
/* 420 */       if (inMultilineComment) {
/* 421 */         if (line.endsWith("*/"))
/* 422 */           inMultilineComment = false;  continue;
/*     */       } 
/* 424 */       if (line.startsWith("/*")) {
/* 425 */         inMultilineComment = true;
/*     */         continue;
/*     */       } 
/* 428 */       int cmtI = line.indexOf("//");
/* 429 */       if (cmtI >= 0) {
/* 430 */         line = line.substring(0, cmtI);
/*     */       }
/*     */ 
/*     */       
/* 434 */       line = line.trim();
/*     */       
/* 436 */       if (line.isEmpty()) {
/*     */         continue;
/*     */       }
/*     */       
/* 440 */       if (line.startsWith("#include")) {
/*     */         
/* 442 */         String incl = line.substring(HASH_INCLUDE_LENGTH).trim();
/* 443 */         if (incl.contains(" ")) {
/* 444 */           throw new IllegalArgumentException("Malformed import statement '" + rawLine + "' in " + location);
/*     */         }
/*     */         
/* 447 */         Scanner hashIncludeScanner = createScanner(incl); 
/* 448 */         try { lines.putAll(parseRules(hashIncludeScanner, location + "->" + incl));
/* 449 */           if (hashIncludeScanner != null) hashIncludeScanner.close();  } catch (Throwable throwable) { if (hashIncludeScanner != null)
/*     */             try { hashIncludeScanner.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */          continue;
/* 452 */       }  String[] parts = line.split("\\s+");
/* 453 */       if (parts.length != 4) {
/* 454 */         throw new IllegalArgumentException("Malformed rule statement split into " + parts.length + " parts: " + rawLine + " in " + location);
/*     */       }
/*     */       
/*     */       try {
/* 458 */         final String pat = stripQuotes(parts[0]);
/* 459 */         final String lCon = stripQuotes(parts[1]);
/* 460 */         final String rCon = stripQuotes(parts[2]);
/* 461 */         PhonemeExpr ph = parsePhonemeExpr(stripQuotes(parts[3]));
/* 462 */         final int cLine = currentLine;
/* 463 */         Rule r = new Rule(pat, lCon, rCon, ph) {
/* 464 */             private final int myLine = cLine;
/* 465 */             private final String loc = location;
/*     */ 
/*     */             
/*     */             public String toString() {
/* 469 */               StringBuilder sb = new StringBuilder();
/* 470 */               sb.append("Rule");
/* 471 */               sb.append("{line=").append(this.myLine);
/* 472 */               sb.append(", loc='").append(this.loc).append('\'');
/* 473 */               sb.append(", pat='").append(pat).append('\'');
/* 474 */               sb.append(", lcon='").append(lCon).append('\'');
/* 475 */               sb.append(", rcon='").append(rCon).append('\'');
/* 476 */               sb.append('}');
/* 477 */               return sb.toString();
/*     */             }
/*     */           };
/* 480 */         String patternKey = r.pattern.substring(0, 1);
/* 481 */         List<Rule> rules = lines.computeIfAbsent(patternKey, k -> new ArrayList());
/* 482 */         rules.add(r);
/* 483 */       } catch (IllegalArgumentException e) {
/* 484 */         throw new IllegalStateException("Problem parsing line '" + currentLine + "' in " + location, e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 491 */     return lines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static RPattern pattern(final String regex) {
/* 502 */     boolean startsWith = regex.startsWith("^");
/* 503 */     boolean endsWith = regex.endsWith("$");
/* 504 */     String content = regex.substring(startsWith ? 1 : 0, endsWith ? (regex.length() - 1) : regex.length());
/* 505 */     boolean boxes = content.contains("[");
/*     */     
/* 507 */     if (!boxes) {
/* 508 */       if (startsWith && endsWith) {
/*     */         
/* 510 */         if (content.isEmpty())
/*     */         {
/* 512 */           return input -> (input.length() == 0);
/*     */         }
/* 514 */         return input -> input.equals(content);
/*     */       } 
/* 516 */       if ((startsWith || endsWith) && content.isEmpty())
/*     */       {
/* 518 */         return ALL_STRINGS_RMATCHER;
/*     */       }
/* 520 */       if (startsWith)
/*     */       {
/* 522 */         return input -> startsWith(input, content);
/*     */       }
/* 524 */       if (endsWith)
/*     */       {
/* 526 */         return input -> endsWith(input, content);
/*     */       }
/*     */     } else {
/* 529 */       boolean startsWithBox = content.startsWith("[");
/* 530 */       boolean endsWithBox = content.endsWith("]");
/*     */       
/* 532 */       if (startsWithBox && endsWithBox) {
/* 533 */         String boxContent = content.substring(1, content.length() - 1);
/* 534 */         if (!boxContent.contains("[")) {
/*     */           
/* 536 */           boolean negate = boxContent.startsWith("^");
/* 537 */           if (negate) {
/* 538 */             boxContent = boxContent.substring(1);
/*     */           }
/* 540 */           String bContent = boxContent;
/* 541 */           boolean shouldMatch = !negate;
/*     */           
/* 543 */           if (startsWith && endsWith)
/*     */           {
/* 545 */             return input -> (input.length() == 1 && contains(bContent, input.charAt(0)) == shouldMatch);
/*     */           }
/* 547 */           if (startsWith)
/*     */           {
/* 549 */             return input -> (input.length() > 0 && contains(bContent, input.charAt(0)) == shouldMatch);
/*     */           }
/* 551 */           if (endsWith)
/*     */           {
/* 553 */             return input -> (input.length() > 0 && contains(bContent, input.charAt(input.length() - 1)) == shouldMatch);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 560 */     return new RPattern() {
/* 561 */         final Pattern pattern = Pattern.compile(regex);
/*     */ 
/*     */         
/*     */         public boolean isMatch(CharSequence input) {
/* 565 */           Matcher matcher = this.pattern.matcher(input);
/* 566 */           return matcher.find();
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private static boolean startsWith(CharSequence input, CharSequence prefix) {
/* 572 */     if (prefix.length() > input.length()) {
/* 573 */       return false;
/*     */     }
/* 575 */     for (int i = 0; i < prefix.length(); i++) {
/* 576 */       if (input.charAt(i) != prefix.charAt(i)) {
/* 577 */         return false;
/*     */       }
/*     */     } 
/* 580 */     return true;
/*     */   }
/*     */   
/*     */   private static String stripQuotes(String str) {
/* 584 */     if (str.startsWith("\"")) {
/* 585 */       str = str.substring(1);
/*     */     }
/*     */     
/* 588 */     if (str.endsWith("\"")) {
/* 589 */       str = str.substring(0, str.length() - 1);
/*     */     }
/*     */     
/* 592 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rule(String pattern, String lContext, String rContext, PhonemeExpr phoneme) {
/* 616 */     this.pattern = pattern;
/* 617 */     this.lContext = pattern(lContext + "$");
/* 618 */     this.rContext = pattern("^" + rContext);
/* 619 */     this.phoneme = phoneme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RPattern getLContext() {
/* 628 */     return this.lContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/* 637 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PhonemeExpr getPhoneme() {
/* 646 */     return this.phoneme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RPattern getRContext() {
/* 655 */     return this.rContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean patternAndContextMatches(CharSequence input, int i) {
/* 670 */     if (i < 0) {
/* 671 */       throw new IndexOutOfBoundsException("Can not match pattern at negative indexes");
/*     */     }
/*     */     
/* 674 */     int patternLength = this.pattern.length();
/* 675 */     int ipl = i + patternLength;
/*     */     
/* 677 */     if (ipl > input.length())
/*     */     {
/* 679 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 684 */     if (!input.subSequence(i, ipl).equals(this.pattern)) {
/* 685 */       return false;
/*     */     }
/* 687 */     if (!this.rContext.isMatch(input.subSequence(ipl, input.length()))) {
/* 688 */       return false;
/*     */     }
/* 690 */     return this.lContext.isMatch(input.subSequence(0, i));
/*     */   }
/*     */   
/*     */   public static interface RPattern {
/*     */     boolean isMatch(CharSequence param1CharSequence);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\bm\Rule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */