/*    */ package org.apache.commons.codec.binary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharSequenceUtils
/*    */ {
/*    */   static boolean regionMatches(CharSequence cs, boolean ignoreCase, int thisStart, CharSequence substring, int start, int length) {
/* 56 */     if (cs instanceof String && substring instanceof String) {
/* 57 */       return ((String)cs).regionMatches(ignoreCase, thisStart, (String)substring, start, length);
/*    */     }
/* 59 */     int index1 = thisStart;
/* 60 */     int index2 = start;
/* 61 */     int tmpLen = length;
/* 62 */     while (tmpLen-- > 0) {
/* 63 */       char c1 = cs.charAt(index1++);
/* 64 */       char c2 = substring.charAt(index2++);
/* 65 */       if (c1 == c2) {
/*    */         continue;
/*    */       }
/* 68 */       if (!ignoreCase) {
/* 69 */         return false;
/*    */       }
/*    */       
/* 72 */       if (Character.toUpperCase(c1) != Character.toUpperCase(c2) && 
/* 73 */         Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/* 74 */         return false;
/*    */       }
/*    */     } 
/* 77 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\binary\CharSequenceUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */