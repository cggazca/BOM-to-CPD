/*     */ package org.apache.commons.codec.digest;
/*     */ 
/*     */ import java.util.zip.Checksum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XXHash32
/*     */   implements Checksum
/*     */ {
/*     */   private static final int BUF_SIZE = 16;
/*     */   private static final int ROTATE_BITS = 13;
/*     */   private static final int PRIME1 = -1640531535;
/*     */   private static final int PRIME2 = -2048144777;
/*     */   private static final int PRIME3 = -1028477379;
/*     */   private static final int PRIME4 = 668265263;
/*     */   private static final int PRIME5 = 374761393;
/*     */   
/*     */   private static int getInt(byte[] buffer, int idx) {
/*  57 */     return buffer[idx] & 0xFF | (buffer[idx + 1] & 0xFF) << 8 | (buffer[idx + 2] & 0xFF) << 16 | (buffer[idx + 3] & 0xFF) << 24;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  62 */   private final byte[] oneByte = new byte[1];
/*  63 */   private final int[] state = new int[4];
/*     */ 
/*     */   
/*  66 */   private final byte[] buffer = new byte[16];
/*     */ 
/*     */   
/*     */   private final int seed;
/*     */ 
/*     */   
/*     */   private int totalLen;
/*     */   
/*     */   private int pos;
/*     */   
/*     */   private boolean stateUpdated;
/*     */ 
/*     */   
/*     */   public XXHash32() {
/*  80 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XXHash32(int seed) {
/*  88 */     this.seed = seed;
/*  89 */     initializeState();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getValue() {
/*     */     int hash;
/*  95 */     if (this.stateUpdated) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       hash = Integer.rotateLeft(this.state[0], 1) + Integer.rotateLeft(this.state[1], 7) + Integer.rotateLeft(this.state[2], 12) + Integer.rotateLeft(this.state[3], 18);
/*     */     } else {
/*     */       
/* 104 */       hash = this.state[2] + 374761393;
/*     */     } 
/* 106 */     hash += this.totalLen;
/*     */     
/* 108 */     int idx = 0;
/* 109 */     int limit = this.pos - 4;
/* 110 */     for (; idx <= limit; idx += 4) {
/* 111 */       hash = Integer.rotateLeft(hash + getInt(this.buffer, idx) * -1028477379, 17) * 668265263;
/*     */     }
/* 113 */     while (idx < this.pos) {
/* 114 */       hash = Integer.rotateLeft(hash + (this.buffer[idx++] & 0xFF) * 374761393, 11) * -1640531535;
/*     */     }
/*     */     
/* 117 */     hash ^= hash >>> 15;
/* 118 */     hash *= -2048144777;
/* 119 */     hash ^= hash >>> 13;
/* 120 */     hash *= -1028477379;
/* 121 */     hash ^= hash >>> 16;
/* 122 */     return hash & 0xFFFFFFFFL;
/*     */   }
/*     */   
/*     */   private void initializeState() {
/* 126 */     this.state[0] = this.seed + -1640531535 + -2048144777;
/* 127 */     this.state[1] = this.seed + -2048144777;
/* 128 */     this.state[2] = this.seed;
/* 129 */     this.state[3] = this.seed - -1640531535;
/*     */   }
/*     */ 
/*     */   
/*     */   private void process(byte[] b, int offset) {
/* 134 */     int s0 = this.state[0];
/* 135 */     int s1 = this.state[1];
/* 136 */     int s2 = this.state[2];
/* 137 */     int s3 = this.state[3];
/*     */     
/* 139 */     s0 = Integer.rotateLeft(s0 + getInt(b, offset) * -2048144777, 13) * -1640531535;
/* 140 */     s1 = Integer.rotateLeft(s1 + getInt(b, offset + 4) * -2048144777, 13) * -1640531535;
/* 141 */     s2 = Integer.rotateLeft(s2 + getInt(b, offset + 8) * -2048144777, 13) * -1640531535;
/* 142 */     s3 = Integer.rotateLeft(s3 + getInt(b, offset + 12) * -2048144777, 13) * -1640531535;
/*     */     
/* 144 */     this.state[0] = s0;
/* 145 */     this.state[1] = s1;
/* 146 */     this.state[2] = s2;
/* 147 */     this.state[3] = s3;
/*     */     
/* 149 */     this.stateUpdated = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 154 */     initializeState();
/* 155 */     this.totalLen = 0;
/* 156 */     this.pos = 0;
/* 157 */     this.stateUpdated = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(byte[] b, int off, int len) {
/* 162 */     if (len <= 0) {
/*     */       return;
/*     */     }
/* 165 */     this.totalLen += len;
/*     */     
/* 167 */     int end = off + len;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (this.pos + len - 16 < 0) {
/* 173 */       System.arraycopy(b, off, this.buffer, this.pos, len);
/* 174 */       this.pos += len;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 179 */     if (this.pos > 0) {
/* 180 */       int size = 16 - this.pos;
/* 181 */       System.arraycopy(b, off, this.buffer, this.pos, size);
/* 182 */       process(this.buffer, 0);
/* 183 */       off += size;
/*     */     } 
/*     */     
/* 186 */     int limit = end - 16;
/* 187 */     while (off <= limit) {
/* 188 */       process(b, off);
/* 189 */       off += 16;
/*     */     } 
/*     */ 
/*     */     
/* 193 */     if (off < end) {
/* 194 */       this.pos = end - off;
/* 195 */       System.arraycopy(b, off, this.buffer, 0, this.pos);
/*     */     } else {
/* 197 */       this.pos = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(int b) {
/* 203 */     this.oneByte[0] = (byte)(b & 0xFF);
/* 204 */     update(this.oneByte, 0, 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\XXHash32.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */