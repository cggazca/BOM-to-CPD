/*      */ package org.apache.commons.codec.digest;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import javax.crypto.Mac;
/*      */ import javax.crypto.spec.SecretKeySpec;
/*      */ import org.apache.commons.codec.binary.Hex;
/*      */ import org.apache.commons.codec.binary.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HmacUtils
/*      */ {
/*      */   private static final int STREAM_BUFFER_LENGTH = 1024;
/*      */   private final Mac mac;
/*      */   
/*      */   @Deprecated
/*      */   public static Mac getHmacMd5(byte[] key) {
/*   79 */     return getInitializedMac(HmacAlgorithms.HMAC_MD5, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Mac getHmacSha1(byte[] key) {
/*   99 */     return getInitializedMac(HmacAlgorithms.HMAC_SHA_1, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Mac getHmacSha256(byte[] key) {
/*  119 */     return getInitializedMac(HmacAlgorithms.HMAC_SHA_256, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Mac getHmacSha384(byte[] key) {
/*  139 */     return getInitializedMac(HmacAlgorithms.HMAC_SHA_384, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Mac getHmacSha512(byte[] key) {
/*  159 */     return getInitializedMac(HmacAlgorithms.HMAC_SHA_512, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mac getInitializedMac(HmacAlgorithms algorithm, byte[] key) {
/*  179 */     return getInitializedMac(algorithm.getName(), key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mac getInitializedMac(String algorithm, byte[] key) {
/*  199 */     if (key == null) {
/*  200 */       throw new IllegalArgumentException("Null key");
/*      */     }
/*      */     try {
/*  203 */       SecretKeySpec keySpec = new SecretKeySpec(key, algorithm);
/*  204 */       Mac mac = Mac.getInstance(algorithm);
/*  205 */       mac.init(keySpec);
/*  206 */       return mac;
/*  207 */     } catch (NoSuchAlgorithmException|java.security.InvalidKeyException e) {
/*  208 */       throw new IllegalArgumentException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacMd5(byte[] key, byte[] valueToDigest) {
/*  226 */     return (new HmacUtils(HmacAlgorithms.HMAC_MD5, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacMd5(byte[] key, InputStream valueToDigest) throws IOException {
/*  248 */     return (new HmacUtils(HmacAlgorithms.HMAC_MD5, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacMd5(String key, String valueToDigest) {
/*  265 */     return (new HmacUtils(HmacAlgorithms.HMAC_MD5, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacMd5Hex(byte[] key, byte[] valueToDigest) {
/*  282 */     return (new HmacUtils(HmacAlgorithms.HMAC_MD5, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacMd5Hex(byte[] key, InputStream valueToDigest) throws IOException {
/*  304 */     return (new HmacUtils(HmacAlgorithms.HMAC_MD5, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacMd5Hex(String key, String valueToDigest) {
/*  321 */     return (new HmacUtils(HmacAlgorithms.HMAC_MD5, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha1(byte[] key, byte[] valueToDigest) {
/*  338 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_1, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha1(byte[] key, InputStream valueToDigest) throws IOException {
/*  360 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_1, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha1(String key, String valueToDigest) {
/*  377 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_1, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha1Hex(byte[] key, byte[] valueToDigest) {
/*  396 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_1, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha1Hex(byte[] key, InputStream valueToDigest) throws IOException {
/*  418 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_1, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha1Hex(String key, String valueToDigest) {
/*  435 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_1, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha256(byte[] key, byte[] valueToDigest) {
/*  452 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha256(byte[] key, InputStream valueToDigest) throws IOException {
/*  474 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha256(String key, String valueToDigest) {
/*  491 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha256Hex(byte[] key, byte[] valueToDigest) {
/*  508 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha256Hex(byte[] key, InputStream valueToDigest) throws IOException {
/*  530 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha256Hex(String key, String valueToDigest) {
/*  547 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha384(byte[] key, byte[] valueToDigest) {
/*  564 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_384, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha384(byte[] key, InputStream valueToDigest) throws IOException {
/*  586 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_384, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha384(String key, String valueToDigest) {
/*  603 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_384, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha384Hex(byte[] key, byte[] valueToDigest) {
/*  622 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_384, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha384Hex(byte[] key, InputStream valueToDigest) throws IOException {
/*  644 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_384, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha384Hex(String key, String valueToDigest) {
/*  661 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_384, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha512(byte[] key, byte[] valueToDigest) {
/*  678 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_512, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha512(byte[] key, InputStream valueToDigest) throws IOException {
/*  700 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_512, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] hmacSha512(String key, String valueToDigest) {
/*  717 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_512, key)).hmac(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha512Hex(byte[] key, byte[] valueToDigest) {
/*  736 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_512, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha512Hex(byte[] key, InputStream valueToDigest) throws IOException {
/*  758 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_512, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String hmacSha512Hex(String key, String valueToDigest) {
/*  775 */     return (new HmacUtils(HmacAlgorithms.HMAC_SHA_512, key)).hmacHex(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAvailable(HmacAlgorithms name) {
/*      */     try {
/*  787 */       Mac.getInstance(name.getName());
/*  788 */       return true;
/*  789 */     } catch (NoSuchAlgorithmException e) {
/*  790 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAvailable(String name) {
/*      */     try {
/*  803 */       Mac.getInstance(name);
/*  804 */       return true;
/*  805 */     } catch (NoSuchAlgorithmException e) {
/*  806 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mac updateHmac(Mac mac, byte[] valueToDigest) {
/*  822 */     mac.reset();
/*  823 */     mac.update(valueToDigest);
/*  824 */     return mac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mac updateHmac(Mac mac, InputStream valueToDigest) throws IOException {
/*  844 */     mac.reset();
/*  845 */     byte[] buffer = new byte[1024];
/*  846 */     int read = valueToDigest.read(buffer, 0, 1024);
/*      */     
/*  848 */     while (read > -1) {
/*  849 */       mac.update(buffer, 0, read);
/*  850 */       read = valueToDigest.read(buffer, 0, 1024);
/*      */     } 
/*      */     
/*  853 */     return mac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mac updateHmac(Mac mac, String valueToDigest) {
/*  868 */     mac.reset();
/*  869 */     mac.update(StringUtils.getBytesUtf8(valueToDigest));
/*  870 */     return mac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public HmacUtils() {
/*  882 */     this(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HmacUtils(HmacAlgorithms algorithm, byte[] key) {
/*  895 */     this(algorithm.getName(), key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HmacUtils(HmacAlgorithms algorithm, String key) {
/*  908 */     this(algorithm.getName(), StringUtils.getBytesUtf8(key));
/*      */   }
/*      */   
/*      */   private HmacUtils(Mac mac) {
/*  912 */     this.mac = mac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HmacUtils(String algorithm, byte[] key) {
/*  925 */     this(getInitializedMac(algorithm, key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HmacUtils(String algorithm, String key) {
/*  938 */     this(algorithm, StringUtils.getBytesUtf8(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hmac(byte[] valueToDigest) {
/*  949 */     return this.mac.doFinal(valueToDigest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hmac(ByteBuffer valueToDigest) {
/*  960 */     this.mac.update(valueToDigest);
/*  961 */     return this.mac.doFinal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hmac(File valueToDigest) throws IOException {
/*  974 */     BufferedInputStream stream = new BufferedInputStream(new FileInputStream(valueToDigest)); try {
/*  975 */       byte[] arrayOfByte = hmac(stream);
/*  976 */       stream.close();
/*      */       return arrayOfByte;
/*      */     } catch (Throwable throwable) {
/*      */       try {
/*      */         stream.close();
/*      */       } catch (Throwable throwable1) {
/*      */         throwable.addSuppressed(throwable1);
/*      */       } 
/*      */       throw throwable;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hmac(InputStream valueToDigest) throws IOException {
/*  993 */     byte[] buffer = new byte[1024];
/*      */     
/*      */     int read;
/*  996 */     while ((read = valueToDigest.read(buffer, 0, 1024)) > -1) {
/*  997 */       this.mac.update(buffer, 0, read);
/*      */     }
/*  999 */     return this.mac.doFinal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hmac(String valueToDigest) {
/* 1010 */     return this.mac.doFinal(StringUtils.getBytesUtf8(valueToDigest));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmacHex(byte[] valueToDigest) {
/* 1021 */     return Hex.encodeHexString(hmac(valueToDigest));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmacHex(ByteBuffer valueToDigest) {
/* 1032 */     return Hex.encodeHexString(hmac(valueToDigest));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmacHex(File valueToDigest) throws IOException {
/* 1045 */     return Hex.encodeHexString(hmac(valueToDigest));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmacHex(InputStream valueToDigest) throws IOException {
/* 1062 */     return Hex.encodeHexString(hmac(valueToDigest));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmacHex(String valueToDigest) {
/* 1073 */     return Hex.encodeHexString(hmac(valueToDigest));
/*      */   }
/*      */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\digest\HmacUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */