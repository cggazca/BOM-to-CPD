/*     */ package org.apache.commons.codec.language.bm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Scanner;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.codec.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Lang
/*     */ {
/*     */   private static final class LangRule
/*     */   {
/*     */     private final boolean acceptOnMatch;
/*     */     private final Set<String> languages;
/*     */     private final Pattern pattern;
/*     */     
/*     */     private LangRule(Pattern pattern, Set<String> languages, boolean acceptOnMatch) {
/*  92 */       this.pattern = pattern;
/*  93 */       this.languages = languages;
/*  94 */       this.acceptOnMatch = acceptOnMatch;
/*     */     }
/*     */     
/*     */     public boolean matches(String txt) {
/*  98 */       return this.pattern.matcher(txt).find();
/*     */     }
/*     */   }
/*     */   
/* 102 */   private static final Map<NameType, Lang> LANGS = new EnumMap<>(NameType.class); private static final String LANGUAGE_RULES_RN = "org/apache/commons/codec/language/bm/%s_lang.txt";
/*     */   private final Languages languages;
/*     */   private final List<LangRule> rules;
/*     */   
/*     */   static {
/* 107 */     for (NameType s : NameType.values()) {
/* 108 */       LANGS.put(s, loadFromResource(String.format("org/apache/commons/codec/language/bm/%s_lang.txt", new Object[] { s.getName() }), Languages.getInstance(s)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Lang instance(NameType nameType) {
/* 120 */     return LANGS.get(nameType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Lang loadFromResource(String languageRulesResourceName, Languages languages) {
/* 137 */     List<LangRule> rules = new ArrayList<>();
/* 138 */     Scanner scanner = new Scanner(Resources.getInputStream(languageRulesResourceName), ResourceConstants.ENCODING);
/*     */     
/* 140 */     try { boolean inExtendedComment = false;
/* 141 */       while (scanner.hasNextLine()) {
/* 142 */         String rawLine = scanner.nextLine();
/* 143 */         String line = rawLine;
/* 144 */         if (inExtendedComment) {
/*     */           
/* 146 */           if (line.endsWith("*/"))
/* 147 */             inExtendedComment = false;  continue;
/*     */         } 
/* 149 */         if (line.startsWith("/*")) {
/* 150 */           inExtendedComment = true;
/*     */           continue;
/*     */         } 
/* 153 */         int cmtI = line.indexOf("//");
/* 154 */         if (cmtI >= 0) {
/* 155 */           line = line.substring(0, cmtI);
/*     */         }
/*     */ 
/*     */         
/* 159 */         line = line.trim();
/*     */         
/* 161 */         if (line.isEmpty()) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 166 */         String[] parts = line.split("\\s+");
/*     */         
/* 168 */         if (parts.length != 3) {
/* 169 */           throw new IllegalArgumentException("Malformed line '" + rawLine + "' in language resource '" + languageRulesResourceName + "'");
/*     */         }
/*     */ 
/*     */         
/* 173 */         Pattern pattern = Pattern.compile(parts[0]);
/* 174 */         String[] langs = parts[1].split("\\+");
/* 175 */         boolean accept = parts[2].equals("true");
/*     */         
/* 177 */         rules.add(new LangRule(pattern, new HashSet(Arrays.asList((Object[])langs)), accept));
/*     */       } 
/*     */       
/* 180 */       scanner.close(); } catch (Throwable throwable) { try { scanner.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 181 */      return new Lang(rules, languages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Lang(List<LangRule> rules, Languages languages) {
/* 189 */     this.rules = Collections.unmodifiableList(rules);
/* 190 */     this.languages = languages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String guessLanguage(String text) {
/* 201 */     Languages.LanguageSet ls = guessLanguages(text);
/* 202 */     return ls.isSingleton() ? ls.getAny() : "any";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Languages.LanguageSet guessLanguages(String input) {
/* 213 */     String text = input.toLowerCase(Locale.ENGLISH);
/* 214 */     Set<String> langs = new HashSet<>(this.languages.getLanguages());
/* 215 */     this.rules.forEach(rule -> {
/*     */           if (rule.matches(text)) {
/*     */             if (rule.acceptOnMatch) {
/*     */               langs.retainAll(rule.languages);
/*     */             } else {
/*     */               langs.removeAll(rule.languages);
/*     */             } 
/*     */           }
/*     */         });
/* 224 */     Languages.LanguageSet ls = Languages.LanguageSet.from(langs);
/* 225 */     return ls.equals(Languages.NO_LANGUAGES) ? Languages.ANY_LANGUAGE : ls;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\bm\Lang.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */