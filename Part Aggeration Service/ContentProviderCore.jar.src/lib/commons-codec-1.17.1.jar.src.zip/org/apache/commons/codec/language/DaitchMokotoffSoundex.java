/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Scanner;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.codec.CharEncoding;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.Resources;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DaitchMokotoffSoundex
/*     */   implements StringEncoder
/*     */ {
/*     */   private static final String COMMENT = "//";
/*     */   private static final String DOUBLE_QUOTE = "\"";
/*     */   private static final String MULTILINE_COMMENT_END = "*/";
/*     */   private static final String MULTILINE_COMMENT_START = "/*";
/*     */   private static final String RESOURCE_FILE = "org/apache/commons/codec/language/dmrules.txt";
/*     */   private static final int MAX_LENGTH = 6;
/*     */   
/*     */   private static final class Branch
/*     */   {
/*  81 */     private final StringBuilder builder = new StringBuilder();
/*  82 */     private String lastReplacement = null;
/*  83 */     private String cachedString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Branch createBranch() {
/*  92 */       Branch branch = new Branch();
/*  93 */       branch.builder.append(toString());
/*  94 */       branch.lastReplacement = this.lastReplacement;
/*  95 */       return branch;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 100 */       if (this == other) {
/* 101 */         return true;
/*     */       }
/* 103 */       if (!(other instanceof Branch)) {
/* 104 */         return false;
/*     */       }
/*     */       
/* 107 */       return toString().equals(((Branch)other).toString());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void finish() {
/* 114 */       while (this.builder.length() < 6) {
/* 115 */         this.builder.append('0');
/* 116 */         this.cachedString = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 122 */       return toString().hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void processNextReplacement(String replacement, boolean forceAppend) {
/* 134 */       boolean append = (this.lastReplacement == null || !this.lastReplacement.endsWith(replacement) || forceAppend);
/*     */       
/* 136 */       if (append && this.builder.length() < 6) {
/* 137 */         this.builder.append(replacement);
/*     */         
/* 139 */         if (this.builder.length() > 6) {
/* 140 */           this.builder.delete(6, this.builder.length());
/*     */         }
/* 142 */         this.cachedString = null;
/*     */       } 
/*     */       
/* 145 */       this.lastReplacement = replacement;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 150 */       if (this.cachedString == null) {
/* 151 */         this.cachedString = this.builder.toString();
/*     */       }
/* 153 */       return this.cachedString;
/*     */     }
/*     */ 
/*     */     
/*     */     private Branch() {}
/*     */   }
/*     */   
/*     */   private static final class Rule
/*     */   {
/*     */     private final String pattern;
/*     */     private final String[] replacementAtStart;
/*     */     private final String[] replacementBeforeVowel;
/*     */     private final String[] replacementDefault;
/*     */     
/*     */     protected Rule(String pattern, String replacementAtStart, String replacementBeforeVowel, String replacementDefault) {
/* 168 */       this.pattern = pattern;
/* 169 */       this.replacementAtStart = replacementAtStart.split("\\|");
/* 170 */       this.replacementBeforeVowel = replacementBeforeVowel.split("\\|");
/* 171 */       this.replacementDefault = replacementDefault.split("\\|");
/*     */     }
/*     */     
/*     */     public int getPatternLength() {
/* 175 */       return this.pattern.length();
/*     */     }
/*     */     
/*     */     public String[] getReplacements(String context, boolean atStart) {
/* 179 */       if (atStart) {
/* 180 */         return this.replacementAtStart;
/*     */       }
/*     */       
/* 183 */       int nextIndex = getPatternLength();
/* 184 */       boolean nextCharIsVowel = (nextIndex < context.length() && isVowel(context.charAt(nextIndex)));
/* 185 */       if (nextCharIsVowel) {
/* 186 */         return this.replacementBeforeVowel;
/*     */       }
/*     */       
/* 189 */       return this.replacementDefault;
/*     */     }
/*     */     
/*     */     private boolean isVowel(char ch) {
/* 193 */       return (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u');
/*     */     }
/*     */     
/*     */     public boolean matches(String context) {
/* 197 */       return context.startsWith(this.pattern);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 202 */       return String.format("%s=(%s,%s,%s)", new Object[] { this.pattern, Arrays.asList(this.replacementAtStart), 
/* 203 */             Arrays.asList(this.replacementBeforeVowel), Arrays.asList(this.replacementDefault) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   private static final Map<Character, List<Rule>> RULES = new HashMap<>();
/*     */ 
/*     */   
/* 225 */   private static final Map<Character, Character> FOLDINGS = new HashMap<>(); private final boolean folding;
/*     */   
/*     */   static {
/* 228 */     Scanner scanner = new Scanner(Resources.getInputStream("org/apache/commons/codec/language/dmrules.txt"), CharEncoding.UTF_8); 
/* 229 */     try { parseRules(scanner, "org/apache/commons/codec/language/dmrules.txt", RULES, FOLDINGS);
/* 230 */       scanner.close(); } catch (Throwable throwable) { try { scanner.close(); }
/*     */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 233 */      RULES.forEach((k, v) -> v.sort(()));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void parseRules(Scanner scanner, String location, Map<Character, List<Rule>> ruleMapping, Map<Character, Character> asciiFoldings) {
/* 238 */     int currentLine = 0;
/* 239 */     boolean inMultilineComment = false;
/*     */     
/* 241 */     while (scanner.hasNextLine()) {
/* 242 */       currentLine++;
/* 243 */       String rawLine = scanner.nextLine();
/* 244 */       String line = rawLine;
/*     */       
/* 246 */       if (inMultilineComment) {
/* 247 */         if (line.endsWith("*/")) {
/* 248 */           inMultilineComment = false;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 253 */       if (line.startsWith("/*")) {
/* 254 */         inMultilineComment = true;
/*     */         continue;
/*     */       } 
/* 257 */       int cmtI = line.indexOf("//");
/* 258 */       if (cmtI >= 0) {
/* 259 */         line = line.substring(0, cmtI);
/*     */       }
/*     */ 
/*     */       
/* 263 */       line = line.trim();
/*     */       
/* 265 */       if (line.isEmpty()) {
/*     */         continue;
/*     */       }
/*     */       
/* 269 */       if (line.contains("=")) {
/*     */         
/* 271 */         String[] arrayOfString = line.split("=");
/* 272 */         if (arrayOfString.length != 2) {
/* 273 */           throw new IllegalArgumentException("Malformed folding statement split into " + arrayOfString.length + " parts: " + rawLine + " in " + location);
/*     */         }
/*     */         
/* 276 */         String leftCharacter = arrayOfString[0];
/* 277 */         String rightCharacter = arrayOfString[1];
/*     */         
/* 279 */         if (leftCharacter.length() != 1 || rightCharacter.length() != 1) {
/* 280 */           throw new IllegalArgumentException("Malformed folding statement - patterns are not single characters: " + rawLine + " in " + location);
/*     */         }
/*     */ 
/*     */         
/* 284 */         asciiFoldings.put(Character.valueOf(leftCharacter.charAt(0)), Character.valueOf(rightCharacter.charAt(0)));
/*     */         continue;
/*     */       } 
/* 287 */       String[] parts = line.split("\\s+");
/* 288 */       if (parts.length != 4) {
/* 289 */         throw new IllegalArgumentException("Malformed rule statement split into " + parts.length + " parts: " + rawLine + " in " + location);
/*     */       }
/*     */       
/*     */       try {
/* 293 */         String pattern = stripQuotes(parts[0]);
/* 294 */         String replacement1 = stripQuotes(parts[1]);
/* 295 */         String replacement2 = stripQuotes(parts[2]);
/* 296 */         String replacement3 = stripQuotes(parts[3]);
/*     */         
/* 298 */         Rule r = new Rule(pattern, replacement1, replacement2, replacement3);
/* 299 */         char patternKey = r.pattern.charAt(0);
/* 300 */         List<Rule> rules = ruleMapping.computeIfAbsent(Character.valueOf(patternKey), k -> new ArrayList());
/* 301 */         rules.add(r);
/* 302 */       } catch (IllegalArgumentException e) {
/* 303 */         throw new IllegalStateException("Problem parsing line '" + currentLine + "' in " + location, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String stripQuotes(String str) {
/* 312 */     if (str.startsWith("\"")) {
/* 313 */       str = str.substring(1);
/*     */     }
/*     */     
/* 316 */     if (str.endsWith("\"")) {
/* 317 */       str = str.substring(0, str.length() - 1);
/*     */     }
/*     */     
/* 320 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DaitchMokotoffSoundex() {
/* 330 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DaitchMokotoffSoundex(boolean folding) {
/* 344 */     this.folding = folding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String cleanup(String input) {
/* 358 */     StringBuilder sb = new StringBuilder();
/* 359 */     for (char ch : input.toCharArray()) {
/* 360 */       if (!Character.isWhitespace(ch)) {
/*     */ 
/*     */ 
/*     */         
/* 364 */         ch = Character.toLowerCase(ch);
/* 365 */         Character character = FOLDINGS.get(Character.valueOf(ch));
/* 366 */         if (this.folding && character != null) {
/* 367 */           ch = character.charValue();
/*     */         }
/* 369 */         sb.append(ch);
/*     */       } 
/* 371 */     }  return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/* 394 */     if (!(obj instanceof String)) {
/* 395 */       throw new EncoderException("Parameter supplied to DaitchMokotoffSoundex encode is not of type java.lang.String");
/*     */     }
/*     */     
/* 398 */     return encode((String)obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String source) {
/* 414 */     if (source == null) {
/* 415 */       return null;
/*     */     }
/* 417 */     return soundex(source, false)[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String soundex(String source) {
/* 444 */     String[] branches = soundex(source, true);
/* 445 */     StringBuilder sb = new StringBuilder();
/* 446 */     int index = 0;
/* 447 */     for (String branch : branches) {
/* 448 */       sb.append(branch);
/* 449 */       if (++index < branches.length) {
/* 450 */         sb.append('|');
/*     */       }
/*     */     } 
/* 453 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] soundex(String source, boolean branching) {
/* 467 */     if (source == null) {
/* 468 */       return null;
/*     */     }
/*     */     
/* 471 */     String input = cleanup(source);
/*     */     
/* 473 */     Set<Branch> currentBranches = new LinkedHashSet<>();
/* 474 */     currentBranches.add(new Branch());
/*     */     
/* 476 */     char lastChar = Character.MIN_VALUE;
/* 477 */     for (int index = 0; index < input.length(); index++) {
/* 478 */       char ch = input.charAt(index);
/*     */ 
/*     */       
/* 481 */       if (!Character.isWhitespace(ch)) {
/*     */ 
/*     */ 
/*     */         
/* 485 */         String inputContext = input.substring(index);
/* 486 */         List<Rule> rules = RULES.get(Character.valueOf(ch));
/* 487 */         if (rules != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 492 */           List<Branch> nextBranches = branching ? new ArrayList<>() : Collections.<Branch>emptyList();
/*     */           
/* 494 */           for (Rule rule : rules) {
/* 495 */             if (rule.matches(inputContext)) {
/* 496 */               if (branching) {
/* 497 */                 nextBranches.clear();
/*     */               }
/* 499 */               String[] replacements = rule.getReplacements(inputContext, (lastChar == '\000'));
/* 500 */               boolean branchingRequired = (replacements.length > 1 && branching);
/*     */               
/* 502 */               for (Branch branch : currentBranches) {
/* 503 */                 for (String nextReplacement : replacements) {
/*     */                   
/* 505 */                   Branch nextBranch = branchingRequired ? branch.createBranch() : branch;
/*     */ 
/*     */                   
/* 508 */                   boolean force = ((lastChar == 'm' && ch == 'n') || (lastChar == 'n' && ch == 'm'));
/*     */                   
/* 510 */                   nextBranch.processNextReplacement(nextReplacement, force);
/*     */                   
/* 512 */                   if (!branching) {
/*     */                     break;
/*     */                   }
/* 515 */                   nextBranches.add(nextBranch);
/*     */                 } 
/*     */               } 
/*     */               
/* 519 */               if (branching) {
/* 520 */                 currentBranches.clear();
/* 521 */                 currentBranches.addAll(nextBranches);
/*     */               } 
/* 523 */               index += rule.getPatternLength() - 1;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 528 */           lastChar = ch;
/*     */         } 
/*     */       } 
/* 531 */     }  String[] result = new String[currentBranches.size()];
/* 532 */     int i = 0;
/* 533 */     for (Branch branch : currentBranches) {
/* 534 */       branch.finish();
/* 535 */       result[i++] = branch.toString();
/*     */     } 
/*     */     
/* 538 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\DaitchMokotoffSoundex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */