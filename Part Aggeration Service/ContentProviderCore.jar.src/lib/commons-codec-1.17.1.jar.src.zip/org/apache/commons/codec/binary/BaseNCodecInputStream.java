/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseNCodecInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private final BaseNCodec baseNCodec;
/*     */   private final boolean doEncode;
/*  40 */   private final byte[] singleByte = new byte[1];
/*     */   
/*     */   private final byte[] buf;
/*     */   
/*  44 */   private final BaseNCodec.Context context = new BaseNCodec.Context();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseNCodecInputStream(InputStream inputStream, BaseNCodec baseNCodec, boolean doEncode) {
/*  54 */     super(inputStream);
/*  55 */     this.doEncode = doEncode;
/*  56 */     this.baseNCodec = baseNCodec;
/*  57 */     this.buf = new byte[doEncode ? 4096 : 8192];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  73 */     return this.context.eof ? 0 : 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStrictDecoding() {
/*  89 */     return this.baseNCodec.isStrictDecoding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void mark(int readLimit) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 126 */     int r = read(this.singleByte, 0, 1);
/* 127 */     while (r == 0) {
/* 128 */       r = read(this.singleByte, 0, 1);
/*     */     }
/* 130 */     if (r > 0) {
/* 131 */       byte b = this.singleByte[0];
/* 132 */       return (b < 0) ? (256 + b) : b;
/*     */     } 
/* 134 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] array, int offset, int len) throws IOException {
/* 158 */     Objects.requireNonNull(array, "array");
/* 159 */     if (offset < 0 || len < 0) {
/* 160 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 162 */     if (offset > array.length || offset + len > array.length) {
/* 163 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 165 */     if (len == 0) {
/* 166 */       return 0;
/*     */     }
/* 168 */     int readLen = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     while (readLen < len) {
/* 187 */       if (!this.baseNCodec.hasData(this.context)) {
/*     */ 
/*     */         
/* 190 */         int c = this.in.read(this.buf);
/* 191 */         if (this.doEncode) {
/* 192 */           this.baseNCodec.encode(this.buf, 0, c, this.context);
/*     */         } else {
/* 194 */           this.baseNCodec.decode(this.buf, 0, c, this.context);
/*     */         } 
/*     */       } 
/* 197 */       int read = this.baseNCodec.readResults(array, offset + readLen, len - readLen, this.context);
/* 198 */       if (read < 0)
/*     */       {
/* 200 */         return (readLen != 0) ? readLen : -1;
/*     */       }
/* 202 */       readLen += read;
/*     */     } 
/* 204 */     return readLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void reset() throws IOException {
/* 218 */     throw new IOException("mark/reset not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 229 */     if (n < 0L) {
/* 230 */       throw new IllegalArgumentException("Negative skip length: " + n);
/*     */     }
/*     */     
/* 233 */     byte[] b = new byte[512];
/* 234 */     long todo = n;
/* 235 */     while (todo > 0L) {
/* 236 */       int len = (int)Math.min(b.length, todo);
/* 237 */       len = read(b, 0, len);
/* 238 */       if (len == -1) {
/*     */         break;
/*     */       }
/* 241 */       todo -= len;
/*     */     } 
/* 243 */     return n - todo;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\binary\BaseNCodecInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */