/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Caverphone1
/*     */   extends AbstractCaverphone
/*     */ {
/*     */   private static final String SIX_1 = "111111";
/*     */   
/*     */   public String encode(String source) {
/*  45 */     String txt = source;
/*  46 */     if (txt == null || txt.isEmpty()) {
/*  47 */       return "111111";
/*     */     }
/*     */ 
/*     */     
/*  51 */     txt = txt.toLowerCase(Locale.ENGLISH);
/*     */ 
/*     */     
/*  54 */     txt = txt.replaceAll("[^a-z]", "");
/*     */ 
/*     */ 
/*     */     
/*  58 */     txt = txt.replaceAll("^cough", "cou2f");
/*  59 */     txt = txt.replaceAll("^rough", "rou2f");
/*  60 */     txt = txt.replaceAll("^tough", "tou2f");
/*  61 */     txt = txt.replaceAll("^enough", "enou2f");
/*  62 */     txt = txt.replaceAll("^gn", "2n");
/*     */ 
/*     */     
/*  65 */     txt = txt.replaceAll("mb$", "m2");
/*     */ 
/*     */     
/*  68 */     txt = txt.replace("cq", "2q");
/*  69 */     txt = txt.replace("ci", "si");
/*  70 */     txt = txt.replace("ce", "se");
/*  71 */     txt = txt.replace("cy", "sy");
/*  72 */     txt = txt.replace("tch", "2ch");
/*  73 */     txt = txt.replace("c", "k");
/*  74 */     txt = txt.replace("q", "k");
/*  75 */     txt = txt.replace("x", "k");
/*  76 */     txt = txt.replace("v", "f");
/*  77 */     txt = txt.replace("dg", "2g");
/*  78 */     txt = txt.replace("tio", "sio");
/*  79 */     txt = txt.replace("tia", "sia");
/*  80 */     txt = txt.replace("d", "t");
/*  81 */     txt = txt.replace("ph", "fh");
/*  82 */     txt = txt.replace("b", "p");
/*  83 */     txt = txt.replace("sh", "s2");
/*  84 */     txt = txt.replace("z", "s");
/*  85 */     txt = txt.replaceAll("^[aeiou]", "A");
/*     */     
/*  87 */     txt = txt.replaceAll("[aeiou]", "3");
/*  88 */     txt = txt.replace("3gh3", "3kh3");
/*  89 */     txt = txt.replace("gh", "22");
/*  90 */     txt = txt.replace("g", "k");
/*  91 */     txt = txt.replaceAll("s+", "S");
/*  92 */     txt = txt.replaceAll("t+", "T");
/*  93 */     txt = txt.replaceAll("p+", "P");
/*  94 */     txt = txt.replaceAll("k+", "K");
/*  95 */     txt = txt.replaceAll("f+", "F");
/*  96 */     txt = txt.replaceAll("m+", "M");
/*  97 */     txt = txt.replaceAll("n+", "N");
/*  98 */     txt = txt.replace("w3", "W3");
/*  99 */     txt = txt.replace("wy", "Wy");
/* 100 */     txt = txt.replace("wh3", "Wh3");
/* 101 */     txt = txt.replace("why", "Why");
/* 102 */     txt = txt.replace("w", "2");
/* 103 */     txt = txt.replaceAll("^h", "A");
/* 104 */     txt = txt.replace("h", "2");
/* 105 */     txt = txt.replace("r3", "R3");
/* 106 */     txt = txt.replace("ry", "Ry");
/* 107 */     txt = txt.replace("r", "2");
/* 108 */     txt = txt.replace("l3", "L3");
/* 109 */     txt = txt.replace("ly", "Ly");
/* 110 */     txt = txt.replace("l", "2");
/* 111 */     txt = txt.replace("j", "y");
/* 112 */     txt = txt.replace("y3", "Y3");
/* 113 */     txt = txt.replace("y", "2");
/*     */ 
/*     */     
/* 116 */     txt = txt.replace("2", "");
/* 117 */     txt = txt.replace("3", "");
/*     */ 
/*     */     
/* 120 */     txt = txt + "111111";
/*     */ 
/*     */     
/* 123 */     return txt.substring(0, "111111".length());
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\Caverphone1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */