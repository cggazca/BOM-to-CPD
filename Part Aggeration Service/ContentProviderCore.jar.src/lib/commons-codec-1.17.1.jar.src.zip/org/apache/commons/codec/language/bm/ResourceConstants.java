/*    */ package org.apache.commons.codec.language.bm;
/*    */ 
/*    */ import org.apache.commons.codec.CharEncoding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ResourceConstants
/*    */ {
/*    */   static final String CMT = "//";
/* 32 */   static final String ENCODING = CharEncoding.UTF_8;
/*    */   static final String EXT_CMT_END = "*/";
/*    */   static final String EXT_CMT_START = "/*";
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\bm\ResourceConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */