/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Metaphone
/*     */   implements StringEncoder
/*     */ {
/*     */   private static final String VOWELS = "AEIOU";
/*     */   private static final String FRONTV = "EIY";
/*     */   private static final String VARSON = "CSPTG";
/*  75 */   private int maxCodeLen = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object encode(Object obj) throws EncoderException {
/*  91 */     if (!(obj instanceof String)) {
/*  92 */       throw new EncoderException("Parameter supplied to Metaphone encode is not of type java.lang.String");
/*     */     }
/*  94 */     return metaphone((String)obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String str) {
/* 105 */     return metaphone(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxCodeLen() {
/* 112 */     return this.maxCodeLen;
/*     */   }
/*     */   private boolean isLastChar(int wdsz, int n) {
/* 115 */     return (n + 1 == wdsz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMetaphoneEqual(String str1, String str2) {
/* 127 */     return metaphone(str1).equals(metaphone(str2));
/*     */   }
/*     */   
/*     */   private boolean isNextChar(StringBuilder string, int index, char c) {
/* 131 */     boolean matches = false;
/* 132 */     if (index >= 0 && index < string.length() - 1) {
/* 133 */       matches = (string.charAt(index + 1) == c);
/*     */     }
/* 135 */     return matches;
/*     */   }
/*     */   
/*     */   private boolean isPreviousChar(StringBuilder string, int index, char c) {
/* 139 */     boolean matches = false;
/* 140 */     if (index > 0 && index < string.length()) {
/* 141 */       matches = (string.charAt(index - 1) == c);
/*     */     }
/* 143 */     return matches;
/*     */   }
/*     */   
/*     */   private boolean isVowel(StringBuilder string, int index) {
/* 147 */     return ("AEIOU".indexOf(string.charAt(index)) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String metaphone(String txt) {
/* 161 */     boolean hard = false;
/*     */     int txtLength;
/* 163 */     if (txt == null || (txtLength = txt.length()) == 0) {
/* 164 */       return "";
/*     */     }
/*     */     
/* 167 */     if (txtLength == 1) {
/* 168 */       return txt.toUpperCase(Locale.ENGLISH);
/*     */     }
/*     */     
/* 171 */     char[] inwd = txt.toUpperCase(Locale.ENGLISH).toCharArray();
/*     */     
/* 173 */     StringBuilder local = new StringBuilder(40);
/* 174 */     StringBuilder code = new StringBuilder(10);
/*     */     
/* 176 */     switch (inwd[0]) {
/*     */       case 'G':
/*     */       case 'K':
/*     */       case 'P':
/* 180 */         if (inwd[1] == 'N') {
/* 181 */           local.append(inwd, 1, inwd.length - 1); break;
/*     */         } 
/* 183 */         local.append(inwd);
/*     */         break;
/*     */       
/*     */       case 'A':
/* 187 */         if (inwd[1] == 'E') {
/* 188 */           local.append(inwd, 1, inwd.length - 1); break;
/*     */         } 
/* 190 */         local.append(inwd);
/*     */         break;
/*     */       
/*     */       case 'W':
/* 194 */         if (inwd[1] == 'R') {
/* 195 */           local.append(inwd, 1, inwd.length - 1);
/*     */           break;
/*     */         } 
/* 198 */         if (inwd[1] == 'H') {
/* 199 */           local.append(inwd, 1, inwd.length - 1);
/* 200 */           local.setCharAt(0, 'W'); break;
/*     */         } 
/* 202 */         local.append(inwd);
/*     */         break;
/*     */       
/*     */       case 'X':
/* 206 */         inwd[0] = 'S';
/* 207 */         local.append(inwd);
/*     */         break;
/*     */       default:
/* 210 */         local.append(inwd);
/*     */         break;
/*     */     } 
/* 213 */     int wdsz = local.length();
/* 214 */     int n = 0;
/*     */     
/* 216 */     while (code.length() < getMaxCodeLen() && n < wdsz) {
/* 217 */       char symb = local.charAt(n);
/*     */       
/* 219 */       if (symb == 'C' || !isPreviousChar(local, n, symb))
/*     */       {
/* 221 */         switch (symb) {
/*     */           case 'A':
/*     */           case 'E':
/*     */           case 'I':
/*     */           case 'O':
/*     */           case 'U':
/* 227 */             if (n == 0) {
/* 228 */               code.append(symb);
/*     */             }
/*     */             break;
/*     */           case 'B':
/* 232 */             if (isPreviousChar(local, n, 'M') && isLastChar(wdsz, n)) {
/*     */               break;
/*     */             }
/* 235 */             code.append(symb);
/*     */             break;
/*     */           
/*     */           case 'C':
/* 239 */             if (isPreviousChar(local, n, 'S') && !isLastChar(wdsz, n) && "EIY".indexOf(local.charAt(n + 1)) >= 0) {
/*     */               break;
/*     */             }
/* 242 */             if (regionMatch(local, n, "CIA")) {
/* 243 */               code.append('X');
/*     */               break;
/*     */             } 
/* 246 */             if (!isLastChar(wdsz, n) && "EIY".indexOf(local.charAt(n + 1)) >= 0) {
/* 247 */               code.append('S');
/*     */               break;
/*     */             } 
/* 250 */             if (isPreviousChar(local, n, 'S') && isNextChar(local, n, 'H')) {
/* 251 */               code.append('K');
/*     */               break;
/*     */             } 
/* 254 */             if (!isNextChar(local, n, 'H') || (n == 0 && wdsz >= 3 && isVowel(local, 2))) {
/* 255 */               code.append('K'); break;
/*     */             } 
/* 257 */             code.append('X');
/*     */             break;
/*     */           
/*     */           case 'D':
/* 261 */             if (!isLastChar(wdsz, n + 1) && isNextChar(local, n, 'G') && "EIY".indexOf(local.charAt(n + 2)) >= 0) {
/* 262 */               code.append('J');
/* 263 */               n += 2; break;
/*     */             } 
/* 265 */             code.append('T');
/*     */             break;
/*     */           
/*     */           case 'G':
/* 269 */             if (isLastChar(wdsz, n + 1) && isNextChar(local, n, 'H')) {
/*     */               break;
/*     */             }
/* 272 */             if (!isLastChar(wdsz, n + 1) && isNextChar(local, n, 'H') && !isVowel(local, n + 2)) {
/*     */               break;
/*     */             }
/* 275 */             if (n > 0 && (regionMatch(local, n, "GN") || regionMatch(local, n, "GNED"))) {
/*     */               break;
/*     */             }
/*     */             
/* 279 */             hard = isPreviousChar(local, n, 'G');
/* 280 */             if (!isLastChar(wdsz, n) && "EIY".indexOf(local.charAt(n + 1)) >= 0 && !hard) {
/* 281 */               code.append('J'); break;
/*     */             } 
/* 283 */             code.append('K');
/*     */             break;
/*     */           
/*     */           case 'H':
/* 287 */             if (isLastChar(wdsz, n)) {
/*     */               break;
/*     */             }
/* 290 */             if (n > 0 && "CSPTG".indexOf(local.charAt(n - 1)) >= 0) {
/*     */               break;
/*     */             }
/* 293 */             if (isVowel(local, n + 1)) {
/* 294 */               code.append('H');
/*     */             }
/*     */             break;
/*     */           case 'F':
/*     */           case 'J':
/*     */           case 'L':
/*     */           case 'M':
/*     */           case 'N':
/*     */           case 'R':
/* 303 */             code.append(symb);
/*     */             break;
/*     */           case 'K':
/* 306 */             if (n > 0) {
/* 307 */               if (!isPreviousChar(local, n, 'C'))
/* 308 */                 code.append(symb); 
/*     */               break;
/*     */             } 
/* 311 */             code.append(symb);
/*     */             break;
/*     */           
/*     */           case 'P':
/* 315 */             if (isNextChar(local, n, 'H')) {
/*     */               
/* 317 */               code.append('F'); break;
/*     */             } 
/* 319 */             code.append(symb);
/*     */             break;
/*     */           
/*     */           case 'Q':
/* 323 */             code.append('K');
/*     */             break;
/*     */           case 'S':
/* 326 */             if (regionMatch(local, n, "SH") || regionMatch(local, n, "SIO") || regionMatch(local, n, "SIA")) {
/* 327 */               code.append('X'); break;
/*     */             } 
/* 329 */             code.append('S');
/*     */             break;
/*     */           
/*     */           case 'T':
/* 333 */             if (regionMatch(local, n, "TIA") || regionMatch(local, n, "TIO")) {
/* 334 */               code.append('X');
/*     */               break;
/*     */             } 
/* 337 */             if (regionMatch(local, n, "TCH")) {
/*     */               break;
/*     */             }
/*     */ 
/*     */             
/* 342 */             if (regionMatch(local, n, "TH")) {
/* 343 */               code.append('0'); break;
/*     */             } 
/* 345 */             code.append('T');
/*     */             break;
/*     */           
/*     */           case 'V':
/* 349 */             code.append('F');
/*     */             break;
/*     */           case 'W':
/*     */           case 'Y':
/* 353 */             if (!isLastChar(wdsz, n) && isVowel(local, n + 1)) {
/* 354 */               code.append(symb);
/*     */             }
/*     */             break;
/*     */           case 'X':
/* 358 */             code.append('K');
/* 359 */             code.append('S');
/*     */             break;
/*     */           case 'Z':
/* 362 */             code.append('S');
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 369 */       n++;
/* 370 */       if (code.length() > getMaxCodeLen()) {
/* 371 */         code.setLength(getMaxCodeLen());
/*     */       }
/*     */     } 
/* 374 */     return code.toString();
/*     */   }
/*     */   
/*     */   private boolean regionMatch(StringBuilder string, int index, String test) {
/* 378 */     boolean matches = false;
/* 379 */     if (index >= 0 && index + test.length() - 1 < string.length()) {
/* 380 */       String substring = string.substring(index, index + test.length());
/* 381 */       matches = substring.equals(test);
/*     */     } 
/* 383 */     return matches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxCodeLen(int maxCodeLen) {
/* 390 */     this.maxCodeLen = maxCodeLen;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\commons-codec-1.17.1.jar!\org\apache\commons\codec\language\Metaphone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */