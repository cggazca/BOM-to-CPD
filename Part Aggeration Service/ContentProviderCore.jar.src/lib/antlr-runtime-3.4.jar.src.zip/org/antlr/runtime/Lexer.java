/*     */ package org.antlr.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Lexer
/*     */   extends BaseRecognizer
/*     */   implements TokenSource
/*     */ {
/*     */   protected CharStream input;
/*     */   
/*     */   public Lexer() {}
/*     */   
/*     */   public Lexer(CharStream input) {
/*  43 */     this.input = input;
/*     */   }
/*     */   
/*     */   public Lexer(CharStream input, RecognizerSharedState state) {
/*  47 */     super(state);
/*  48 */     this.input = input;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  52 */     super.reset();
/*     */     
/*  54 */     if (this.input != null) {
/*  55 */       this.input.seek(0);
/*     */     }
/*  57 */     if (this.state == null) {
/*     */       return;
/*     */     }
/*  60 */     this.state.token = null;
/*  61 */     this.state.type = 0;
/*  62 */     this.state.channel = 0;
/*  63 */     this.state.tokenStartCharIndex = -1;
/*  64 */     this.state.tokenStartCharPositionInLine = -1;
/*  65 */     this.state.tokenStartLine = -1;
/*  66 */     this.state.text = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token nextToken() {
/*     */     while (true) {
/*  74 */       this.state.token = null;
/*  75 */       this.state.channel = 0;
/*  76 */       this.state.tokenStartCharIndex = this.input.index();
/*  77 */       this.state.tokenStartCharPositionInLine = this.input.getCharPositionInLine();
/*  78 */       this.state.tokenStartLine = this.input.getLine();
/*  79 */       this.state.text = null;
/*  80 */       if (this.input.LA(1) == -1) {
/*  81 */         Token eof = new CommonToken(this.input, -1, 0, this.input.index(), this.input.index());
/*     */ 
/*     */         
/*  84 */         eof.setLine(getLine());
/*  85 */         eof.setCharPositionInLine(getCharPositionInLine());
/*  86 */         return eof;
/*     */       } 
/*     */       try {
/*  89 */         mTokens();
/*  90 */         if (this.state.token == null) {
/*  91 */           emit();
/*     */         }
/*  93 */         else if (this.state.token == Token.SKIP_TOKEN) {
/*     */           continue;
/*     */         } 
/*  96 */         return this.state.token;
/*     */       }
/*  98 */       catch (MismatchedRangeException re) {
/*  99 */         reportError(re);
/*     */       
/*     */       }
/* 102 */       catch (MismatchedTokenException re) {
/* 103 */         reportError(re);
/*     */       
/*     */       }
/* 106 */       catch (RecognitionException re) {
/* 107 */         reportError(re);
/* 108 */         recover(re);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skip() {
/* 120 */     this.state.token = Token.SKIP_TOKEN;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void mTokens() throws RecognitionException;
/*     */ 
/*     */   
/*     */   public void setCharStream(CharStream input) {
/* 128 */     this.input = null;
/* 129 */     reset();
/* 130 */     this.input = input;
/*     */   }
/*     */   
/*     */   public CharStream getCharStream() {
/* 134 */     return this.input;
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/* 138 */     return this.input.getSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emit(Token token) {
/* 147 */     this.state.token = token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token emit() {
/* 160 */     Token t = new CommonToken(this.input, this.state.type, this.state.channel, this.state.tokenStartCharIndex, getCharIndex() - 1);
/* 161 */     t.setLine(this.state.tokenStartLine);
/* 162 */     t.setText(this.state.text);
/* 163 */     t.setCharPositionInLine(this.state.tokenStartCharPositionInLine);
/* 164 */     emit(t);
/* 165 */     return t;
/*     */   }
/*     */   
/*     */   public void match(String s) throws MismatchedTokenException {
/* 169 */     int i = 0;
/* 170 */     while (i < s.length()) {
/* 171 */       if (this.input.LA(1) != s.charAt(i)) {
/* 172 */         if (this.state.backtracking > 0) {
/* 173 */           this.state.failed = true;
/*     */           return;
/*     */         } 
/* 176 */         MismatchedTokenException mte = new MismatchedTokenException(s.charAt(i), this.input);
/*     */         
/* 178 */         recover(mte);
/* 179 */         throw mte;
/*     */       } 
/* 181 */       i++;
/* 182 */       this.input.consume();
/* 183 */       this.state.failed = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void matchAny() {
/* 188 */     this.input.consume();
/*     */   }
/*     */   
/*     */   public void match(int c) throws MismatchedTokenException {
/* 192 */     if (this.input.LA(1) != c) {
/* 193 */       if (this.state.backtracking > 0) {
/* 194 */         this.state.failed = true;
/*     */         return;
/*     */       } 
/* 197 */       MismatchedTokenException mte = new MismatchedTokenException(c, this.input);
/*     */       
/* 199 */       recover(mte);
/* 200 */       throw mte;
/*     */     } 
/* 202 */     this.input.consume();
/* 203 */     this.state.failed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void matchRange(int a, int b) throws MismatchedRangeException {
/* 209 */     if (this.input.LA(1) < a || this.input.LA(1) > b) {
/* 210 */       if (this.state.backtracking > 0) {
/* 211 */         this.state.failed = true;
/*     */         return;
/*     */       } 
/* 214 */       MismatchedRangeException mre = new MismatchedRangeException(a, b, this.input);
/*     */       
/* 216 */       recover(mre);
/* 217 */       throw mre;
/*     */     } 
/* 219 */     this.input.consume();
/* 220 */     this.state.failed = false;
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 224 */     return this.input.getLine();
/*     */   }
/*     */   
/*     */   public int getCharPositionInLine() {
/* 228 */     return this.input.getCharPositionInLine();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharIndex() {
/* 233 */     return this.input.index();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 240 */     if (this.state.text != null) {
/* 241 */       return this.state.text;
/*     */     }
/* 243 */     return this.input.substring(this.state.tokenStartCharIndex, getCharIndex() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 250 */     this.state.text = text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(RecognitionException e) {
/* 265 */     displayRecognitionError(getTokenNames(), e);
/*     */   }
/*     */   
/*     */   public String getErrorMessage(RecognitionException e, String[] tokenNames) {
/* 269 */     String msg = null;
/* 270 */     if (e instanceof MismatchedTokenException) {
/* 271 */       MismatchedTokenException mte = (MismatchedTokenException)e;
/* 272 */       msg = "mismatched character " + getCharErrorDisplay(e.c) + " expecting " + getCharErrorDisplay(mte.expecting);
/*     */     }
/* 274 */     else if (e instanceof NoViableAltException) {
/* 275 */       NoViableAltException nvae = (NoViableAltException)e;
/*     */ 
/*     */ 
/*     */       
/* 279 */       msg = "no viable alternative at character " + getCharErrorDisplay(e.c);
/*     */     }
/* 281 */     else if (e instanceof EarlyExitException) {
/* 282 */       EarlyExitException eee = (EarlyExitException)e;
/*     */       
/* 284 */       msg = "required (...)+ loop did not match anything at character " + getCharErrorDisplay(e.c);
/*     */     }
/* 286 */     else if (e instanceof MismatchedNotSetException) {
/* 287 */       MismatchedNotSetException mse = (MismatchedNotSetException)e;
/* 288 */       msg = "mismatched character " + getCharErrorDisplay(e.c) + " expecting set " + mse.expecting;
/*     */     }
/* 290 */     else if (e instanceof MismatchedSetException) {
/* 291 */       MismatchedSetException mse = (MismatchedSetException)e;
/* 292 */       msg = "mismatched character " + getCharErrorDisplay(e.c) + " expecting set " + mse.expecting;
/*     */     }
/* 294 */     else if (e instanceof MismatchedRangeException) {
/* 295 */       MismatchedRangeException mre = (MismatchedRangeException)e;
/* 296 */       msg = "mismatched character " + getCharErrorDisplay(e.c) + " expecting set " + getCharErrorDisplay(mre.a) + ".." + getCharErrorDisplay(mre.b);
/*     */     }
/*     */     else {
/*     */       
/* 300 */       msg = super.getErrorMessage(e, tokenNames);
/*     */     } 
/* 302 */     return msg;
/*     */   }
/*     */   
/*     */   public String getCharErrorDisplay(int c) {
/* 306 */     String s = String.valueOf((char)c);
/* 307 */     switch (c) {
/*     */       case -1:
/* 309 */         s = "<EOF>";
/*     */         break;
/*     */       case 10:
/* 312 */         s = "\\n";
/*     */         break;
/*     */       case 9:
/* 315 */         s = "\\t";
/*     */         break;
/*     */       case 13:
/* 318 */         s = "\\r";
/*     */         break;
/*     */     } 
/* 321 */     return "'" + s + "'";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recover(RecognitionException re) {
/* 332 */     this.input.consume();
/*     */   }
/*     */   
/*     */   public void traceIn(String ruleName, int ruleIndex) {
/* 336 */     String inputSymbol = (char)this.input.LT(1) + " line=" + getLine() + ":" + getCharPositionInLine();
/* 337 */     traceIn(ruleName, ruleIndex, inputSymbol);
/*     */   }
/*     */   
/*     */   public void traceOut(String ruleName, int ruleIndex) {
/* 341 */     String inputSymbol = (char)this.input.LT(1) + " line=" + getLine() + ":" + getCharPositionInLine();
/* 342 */     traceOut(ruleName, ruleIndex, inputSymbol);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\Lexer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */