/*     */ package org.antlr.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonTokenStream
/*     */   extends BufferedTokenStream
/*     */ {
/*  50 */   protected int channel = 0;
/*     */   
/*     */   public CommonTokenStream() {}
/*     */   
/*     */   public CommonTokenStream(TokenSource tokenSource) {
/*  55 */     super(tokenSource);
/*     */   }
/*     */   
/*     */   public CommonTokenStream(TokenSource tokenSource, int channel) {
/*  59 */     this(tokenSource);
/*  60 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void consume() {
/*  65 */     if (this.p == -1) setup(); 
/*  66 */     this.p++;
/*  67 */     sync(this.p);
/*  68 */     while (((Token)this.tokens.get(this.p)).getChannel() != this.channel) {
/*  69 */       this.p++;
/*  70 */       sync(this.p);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Token LB(int k) {
/*  75 */     if (k == 0 || this.p - k < 0) return null;
/*     */     
/*  77 */     int i = this.p;
/*  78 */     int n = 1;
/*     */     
/*  80 */     while (n <= k) {
/*     */       
/*  82 */       i = skipOffTokenChannelsReverse(i - 1);
/*  83 */       n++;
/*     */     } 
/*  85 */     if (i < 0) return null; 
/*  86 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public Token LT(int k) {
/*  91 */     if (this.p == -1) setup(); 
/*  92 */     if (k == 0) return null; 
/*  93 */     if (k < 0) return LB(-k); 
/*  94 */     int i = this.p;
/*  95 */     int n = 1;
/*     */     
/*  97 */     while (n < k) {
/*     */       
/*  99 */       i = skipOffTokenChannels(i + 1);
/* 100 */       n++;
/*     */     } 
/* 102 */     if (i > this.range) this.range = i; 
/* 103 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int skipOffTokenChannels(int i) {
/* 110 */     sync(i);
/* 111 */     while (((Token)this.tokens.get(i)).getChannel() != this.channel) {
/* 112 */       i++;
/* 113 */       sync(i);
/*     */     } 
/* 115 */     return i;
/*     */   }
/*     */   
/*     */   protected int skipOffTokenChannelsReverse(int i) {
/* 119 */     while (i >= 0 && ((Token)this.tokens.get(i)).getChannel() != this.channel) {
/* 120 */       i--;
/*     */     }
/* 122 */     return i;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 126 */     super.reset();
/* 127 */     this.p = skipOffTokenChannels(0);
/*     */   }
/*     */   
/*     */   protected void setup() {
/* 131 */     this.p = 0;
/* 132 */     sync(0);
/* 133 */     int i = 0;
/* 134 */     while (((Token)this.tokens.get(i)).getChannel() != this.channel) {
/* 135 */       i++;
/* 136 */       sync(i);
/*     */     } 
/* 138 */     this.p = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfOnChannelTokens() {
/* 143 */     int n = 0;
/* 144 */     fill();
/* 145 */     for (int i = 0; i < this.tokens.size(); i++) {
/* 146 */       Token t = this.tokens.get(i);
/* 147 */       if (t.getChannel() == this.channel) n++; 
/* 148 */       if (t.getType() == -1)
/*     */         break; 
/* 150 */     }  return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenSource(TokenSource tokenSource) {
/* 155 */     super.setTokenSource(tokenSource);
/* 156 */     this.channel = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\CommonTokenStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */