/*    */ package org.antlr.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Token
/*    */ {
/*    */   public static final int EOR_TOKEN_TYPE = 1;
/*    */   public static final int DOWN = 2;
/*    */   public static final int UP = 3;
/*    */   public static final int MIN_TOKEN_TYPE = 4;
/*    */   public static final int EOF = -1;
/* 42 */   public static final Token EOF_TOKEN = new CommonToken(-1);
/*    */   
/*    */   public static final int INVALID_TOKEN_TYPE = 0;
/* 45 */   public static final Token INVALID_TOKEN = new CommonToken(0);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public static final Token SKIP_TOKEN = new CommonToken(0);
/*    */   public static final int DEFAULT_CHANNEL = 0;
/*    */   public static final int HIDDEN_CHANNEL = 99;
/*    */   
/*    */   String getText();
/*    */   
/*    */   void setText(String paramString);
/*    */   
/*    */   int getType();
/*    */   
/*    */   void setType(int paramInt);
/*    */   
/*    */   int getLine();
/*    */   
/*    */   void setLine(int paramInt);
/*    */   
/*    */   int getCharPositionInLine();
/*    */   
/*    */   void setCharPositionInLine(int paramInt);
/*    */   
/*    */   int getChannel();
/*    */   
/*    */   void setChannel(int paramInt);
/*    */   
/*    */   int getTokenIndex();
/*    */   
/*    */   void setTokenIndex(int paramInt);
/*    */   
/*    */   CharStream getInputStream();
/*    */   
/*    */   void setInputStream(CharStream paramCharStream);
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\Token.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */