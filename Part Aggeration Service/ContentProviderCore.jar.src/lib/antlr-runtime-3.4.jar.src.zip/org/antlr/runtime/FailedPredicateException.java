/*    */ package org.antlr.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailedPredicateException
/*    */   extends RecognitionException
/*    */ {
/*    */   public String ruleName;
/*    */   public String predicateText;
/*    */   
/*    */   public FailedPredicateException() {}
/*    */   
/*    */   public FailedPredicateException(IntStream input, String ruleName, String predicateText) {
/* 46 */     super(input);
/* 47 */     this.ruleName = ruleName;
/* 48 */     this.predicateText = predicateText;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 52 */     return "FailedPredicateException(" + this.ruleName + ",{" + this.predicateText + "}?)";
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\FailedPredicateException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */