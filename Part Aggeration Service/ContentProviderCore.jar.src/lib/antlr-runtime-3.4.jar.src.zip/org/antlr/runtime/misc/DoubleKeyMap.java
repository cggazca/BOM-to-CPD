/*    */ package org.antlr.runtime.misc;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class DoubleKeyMap<Key1, Key2, Value> {
/* 10 */   Map data = new LinkedHashMap();
/*    */   
/*    */   public Value put(Key1 k1, Key2 k2, Value v) {
/* 13 */     Map data2 = this.data.get(k1);
/* 14 */     Value prev = null;
/* 15 */     if (data2 == null) {
/* 16 */       data2 = new LinkedHashMap();
/* 17 */       this.data.put(k1, data2);
/*    */     } else {
/*    */       
/* 20 */       prev = data2.get(k2);
/*    */     } 
/* 22 */     data2.put(k2, v);
/* 23 */     return prev;
/*    */   }
/*    */   
/*    */   public Value get(Key1 k1, Key2 k2) {
/* 27 */     Map data2 = this.data.get(k1);
/* 28 */     if (data2 == null) return null; 
/* 29 */     return data2.get(k2);
/*    */   }
/*    */   public Map get(Key1 k1) {
/* 32 */     return this.data.get(k1);
/*    */   }
/*    */   
/*    */   public Collection values(Key1 k1) {
/* 36 */     Map data2 = this.data.get(k1);
/* 37 */     if (data2 == null) return null; 
/* 38 */     return data2.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set keySet() {
/* 43 */     return this.data.keySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set keySet(Key1 k1) {
/* 48 */     Map data2 = this.data.get(k1);
/* 49 */     if (data2 == null) return null; 
/* 50 */     return data2.keySet();
/*    */   }
/*    */   
/*    */   public Collection values() {
/* 54 */     Set s = new HashSet();
/* 55 */     for (Map k2 : this.data.values()) {
/* 56 */       for (Value v : k2.values()) {
/* 57 */         s.add(v);
/*    */       }
/*    */     } 
/* 60 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\misc\DoubleKeyMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */