/*    */ package org.antlr.runtime;
/*    */ 
/*    */ import org.antlr.runtime.misc.LookaheadStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnbufferedTokenStream
/*    */   extends LookaheadStream
/*    */   implements TokenStream
/*    */ {
/*    */   protected TokenSource tokenSource;
/*    */   
/*    */   public boolean isEOF(Object x0) {
/* 50 */     return isEOF((Token)x0); } public Object nextElement() { return nextElement(); } public Token LT(int x0) { return (Token)LT(x0); }
/*    */   
/* 52 */   protected int tokenIndex = 0;
/*    */ 
/*    */   
/* 55 */   protected int channel = 0;
/*    */   
/*    */   public UnbufferedTokenStream(TokenSource tokenSource) {
/* 58 */     this.tokenSource = tokenSource;
/*    */   }
/*    */   
/*    */   public Token nextElement() {
/* 62 */     Token t = this.tokenSource.nextToken();
/* 63 */     t.setTokenIndex(this.tokenIndex++);
/* 64 */     return t;
/*    */   }
/*    */   public boolean isEOF(Token o) {
/* 67 */     return (o.getType() == -1);
/*    */   } public TokenSource getTokenSource() {
/* 69 */     return this.tokenSource;
/*    */   } public String toString(int start, int stop) {
/* 71 */     return "n/a";
/*    */   } public String toString(Token start, Token stop) {
/* 73 */     return "n/a";
/*    */   } public int LA(int i) {
/* 75 */     return ((Token)LT(i)).getType();
/*    */   }
/*    */   public Token get(int i) {
/* 78 */     throw new UnsupportedOperationException("Absolute token indexes are meaningless in an unbuffered stream");
/*    */   }
/*    */   public String getSourceName() {
/* 81 */     return this.tokenSource.getSourceName();
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\UnbufferedTokenStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */