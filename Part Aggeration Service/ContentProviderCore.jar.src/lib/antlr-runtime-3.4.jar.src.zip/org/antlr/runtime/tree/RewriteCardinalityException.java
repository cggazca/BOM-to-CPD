/*    */ package org.antlr.runtime.tree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RewriteCardinalityException
/*    */   extends RuntimeException
/*    */ {
/*    */   public String elementDescription;
/*    */   
/*    */   public RewriteCardinalityException(String elementDescription) {
/* 38 */     this.elementDescription = elementDescription;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 42 */     if (this.elementDescription != null) {
/* 43 */       return this.elementDescription;
/*    */     }
/* 45 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\RewriteCardinalityException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */