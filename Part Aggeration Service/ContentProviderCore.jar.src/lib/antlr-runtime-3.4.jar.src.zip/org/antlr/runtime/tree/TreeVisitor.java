/*    */ package org.antlr.runtime.tree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeVisitor
/*    */ {
/*    */   protected TreeAdaptor adaptor;
/*    */   
/*    */   public TreeVisitor(TreeAdaptor adaptor) {
/* 38 */     this.adaptor = adaptor;
/*    */   } public TreeVisitor() {
/* 40 */     this(new CommonTreeAdaptor());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object visit(Object t, TreeVisitorAction action) {
/* 54 */     boolean isNil = this.adaptor.isNil(t);
/* 55 */     if (action != null && !isNil) {
/* 56 */       t = action.pre(t);
/*    */     }
/* 58 */     for (int i = 0; i < this.adaptor.getChildCount(t); i++) {
/* 59 */       Object child = this.adaptor.getChild(t, i);
/* 60 */       Object visitResult = visit(child, action);
/* 61 */       Object childAfterVisit = this.adaptor.getChild(t, i);
/* 62 */       if (visitResult != childAfterVisit) {
/* 63 */         this.adaptor.setChild(t, i, visitResult);
/*    */       }
/*    */     } 
/* 66 */     if (action != null && !isNil) t = action.post(t); 
/* 67 */     return t;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\TreeVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */