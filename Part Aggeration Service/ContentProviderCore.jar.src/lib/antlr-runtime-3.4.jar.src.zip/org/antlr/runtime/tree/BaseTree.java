/*     */ package org.antlr.runtime.tree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseTree
/*     */   implements Tree
/*     */ {
/*     */   protected List children;
/*     */   
/*     */   public BaseTree() {}
/*     */   
/*     */   public BaseTree(Tree node) {}
/*     */   
/*     */   public Tree getChild(int i) {
/*  53 */     if (this.children == null || i >= this.children.size()) {
/*  54 */       return null;
/*     */     }
/*  56 */     return this.children.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getChildren() {
/*  63 */     return this.children;
/*     */   }
/*     */   
/*     */   public Tree getFirstChildWithType(int type) {
/*  67 */     for (int i = 0; this.children != null && i < this.children.size(); i++) {
/*  68 */       Tree t = this.children.get(i);
/*  69 */       if (t.getType() == type) {
/*  70 */         return t;
/*     */       }
/*     */     } 
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   public int getChildCount() {
/*  77 */     if (this.children == null) {
/*  78 */       return 0;
/*     */     }
/*  80 */     return this.children.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChild(Tree t) {
/*  92 */     if (t == null) {
/*     */       return;
/*     */     }
/*  95 */     BaseTree childTree = (BaseTree)t;
/*  96 */     if (childTree.isNil()) {
/*  97 */       if (this.children != null && this.children == childTree.children) {
/*  98 */         throw new RuntimeException("attempt to add child list to itself");
/*     */       }
/*     */       
/* 101 */       if (childTree.children != null) {
/* 102 */         if (this.children != null) {
/* 103 */           int n = childTree.children.size();
/* 104 */           for (int i = 0; i < n; i++) {
/* 105 */             Tree c = childTree.children.get(i);
/* 106 */             this.children.add(c);
/*     */             
/* 108 */             c.setParent(this);
/* 109 */             c.setChildIndex(this.children.size() - 1);
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 115 */           this.children = childTree.children;
/* 116 */           freshenParentAndChildIndexes();
/*     */         } 
/*     */       }
/*     */     } else {
/*     */       
/* 121 */       if (this.children == null) {
/* 122 */         this.children = createChildrenList();
/*     */       }
/* 124 */       this.children.add(t);
/* 125 */       childTree.setParent(this);
/* 126 */       childTree.setChildIndex(this.children.size() - 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChildren(List kids) {
/* 133 */     for (int i = 0; i < kids.size(); i++) {
/* 134 */       Tree t = kids.get(i);
/* 135 */       addChild(t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setChild(int i, Tree t) {
/* 140 */     if (t == null) {
/*     */       return;
/*     */     }
/* 143 */     if (t.isNil()) {
/* 144 */       throw new IllegalArgumentException("Can't set single child to a list");
/*     */     }
/* 146 */     if (this.children == null) {
/* 147 */       this.children = createChildrenList();
/*     */     }
/* 149 */     this.children.set(i, t);
/* 150 */     t.setParent(this);
/* 151 */     t.setChildIndex(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertChild(int i, Object t) {
/* 159 */     if (this.children == null)
/* 160 */       return;  this.children.add(i, t);
/*     */ 
/*     */     
/* 163 */     freshenParentAndChildIndexes(i);
/*     */   }
/*     */   
/*     */   public Object deleteChild(int i) {
/* 167 */     if (this.children == null) {
/* 168 */       return null;
/*     */     }
/* 170 */     Tree killed = this.children.remove(i);
/*     */     
/* 172 */     freshenParentAndChildIndexes(i);
/* 173 */     return killed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceChildren(int startChildIndex, int stopChildIndex, Object t) {
/* 187 */     if (this.children == null) {
/* 188 */       throw new IllegalArgumentException("indexes invalid; no children in list");
/*     */     }
/* 190 */     int replacingHowMany = stopChildIndex - startChildIndex + 1;
/*     */     
/* 192 */     BaseTree newTree = (BaseTree)t;
/* 193 */     List newChildren = null;
/*     */     
/* 195 */     if (newTree.isNil()) {
/* 196 */       newChildren = newTree.children;
/*     */     } else {
/*     */       
/* 199 */       newChildren = new ArrayList(1);
/* 200 */       newChildren.add(newTree);
/*     */     } 
/* 202 */     int replacingWithHowMany = newChildren.size();
/* 203 */     int numNewChildren = newChildren.size();
/* 204 */     int delta = replacingHowMany - replacingWithHowMany;
/*     */     
/* 206 */     if (delta == 0) {
/* 207 */       int j = 0;
/* 208 */       for (int i = startChildIndex; i <= stopChildIndex; i++) {
/* 209 */         BaseTree child = newChildren.get(j);
/* 210 */         this.children.set(i, child);
/* 211 */         child.setParent(this);
/* 212 */         child.setChildIndex(i);
/* 213 */         j++;
/*     */       }
/*     */     
/* 216 */     } else if (delta > 0) {
/*     */       
/* 218 */       for (int j = 0; j < numNewChildren; j++) {
/* 219 */         this.children.set(startChildIndex + j, newChildren.get(j));
/*     */       }
/* 221 */       int indexToDelete = startChildIndex + numNewChildren;
/* 222 */       for (int c = indexToDelete; c <= stopChildIndex; c++)
/*     */       {
/* 224 */         this.children.remove(indexToDelete);
/*     */       }
/* 226 */       freshenParentAndChildIndexes(startChildIndex);
/*     */     }
/*     */     else {
/*     */       
/* 230 */       for (int j = 0; j < replacingHowMany; j++) {
/* 231 */         this.children.set(startChildIndex + j, newChildren.get(j));
/*     */       }
/* 233 */       int numToInsert = replacingWithHowMany - replacingHowMany;
/* 234 */       for (int i = replacingHowMany; i < replacingWithHowMany; i++) {
/* 235 */         this.children.add(startChildIndex + i, newChildren.get(i));
/*     */       }
/* 237 */       freshenParentAndChildIndexes(startChildIndex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List createChildrenList() {
/* 244 */     return new ArrayList();
/*     */   }
/*     */   
/*     */   public boolean isNil() {
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void freshenParentAndChildIndexes() {
/* 253 */     freshenParentAndChildIndexes(0);
/*     */   }
/*     */   
/*     */   public void freshenParentAndChildIndexes(int offset) {
/* 257 */     int n = getChildCount();
/* 258 */     for (int c = offset; c < n; c++) {
/* 259 */       Tree child = getChild(c);
/* 260 */       child.setChildIndex(c);
/* 261 */       child.setParent(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void freshenParentAndChildIndexesDeeply() {
/* 266 */     freshenParentAndChildIndexesDeeply(0);
/*     */   }
/*     */   
/*     */   public void freshenParentAndChildIndexesDeeply(int offset) {
/* 270 */     int n = getChildCount();
/* 271 */     for (int c = offset; c < n; c++) {
/* 272 */       BaseTree child = (BaseTree)getChild(c);
/* 273 */       child.setChildIndex(c);
/* 274 */       child.setParent(this);
/* 275 */       child.freshenParentAndChildIndexesDeeply();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sanityCheckParentAndChildIndexes() {
/* 280 */     sanityCheckParentAndChildIndexes(null, -1);
/*     */   }
/*     */   
/*     */   public void sanityCheckParentAndChildIndexes(Tree parent, int i) {
/* 284 */     if (parent != getParent()) {
/* 285 */       throw new IllegalStateException("parents don't match; expected " + parent + " found " + getParent());
/*     */     }
/* 287 */     if (i != getChildIndex()) {
/* 288 */       throw new IllegalStateException("child indexes don't match; expected " + i + " found " + getChildIndex());
/*     */     }
/* 290 */     int n = getChildCount();
/* 291 */     for (int c = 0; c < n; c++) {
/* 292 */       CommonTree child = (CommonTree)getChild(c);
/* 293 */       child.sanityCheckParentAndChildIndexes(this, c);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildIndex() {
/* 299 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChildIndex(int index) {}
/*     */   
/*     */   public Tree getParent() {
/* 306 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParent(Tree t) {}
/*     */   
/*     */   public boolean hasAncestor(int ttype) {
/* 313 */     return (getAncestor(ttype) != null);
/*     */   }
/*     */   
/*     */   public Tree getAncestor(int ttype) {
/* 317 */     Tree t = this;
/* 318 */     t = t.getParent();
/* 319 */     while (t != null) {
/* 320 */       if (t.getType() == ttype) return t; 
/* 321 */       t = t.getParent();
/*     */     } 
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getAncestors() {
/* 330 */     if (getParent() == null) return null; 
/* 331 */     List ancestors = new ArrayList();
/* 332 */     Tree t = this;
/* 333 */     t = t.getParent();
/* 334 */     while (t != null) {
/* 335 */       ancestors.add(0, t);
/* 336 */       t = t.getParent();
/*     */     } 
/* 338 */     return ancestors;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringTree() {
/* 343 */     if (this.children == null || this.children.size() == 0) {
/* 344 */       return toString();
/*     */     }
/* 346 */     StringBuffer buf = new StringBuffer();
/* 347 */     if (!isNil()) {
/* 348 */       buf.append("(");
/* 349 */       buf.append(toString());
/* 350 */       buf.append(' ');
/*     */     } 
/* 352 */     for (int i = 0; this.children != null && i < this.children.size(); i++) {
/* 353 */       Tree t = this.children.get(i);
/* 354 */       if (i > 0) {
/* 355 */         buf.append(' ');
/*     */       }
/* 357 */       buf.append(t.toStringTree());
/*     */     } 
/* 359 */     if (!isNil()) {
/* 360 */       buf.append(")");
/*     */     }
/* 362 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 366 */     return 0;
/*     */   }
/*     */   
/*     */   public int getCharPositionInLine() {
/* 370 */     return 0;
/*     */   }
/*     */   
/*     */   public abstract String toString();
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\BaseTree.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */