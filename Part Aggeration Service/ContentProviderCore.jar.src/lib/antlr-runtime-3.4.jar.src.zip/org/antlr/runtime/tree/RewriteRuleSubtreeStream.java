/*    */ package org.antlr.runtime.tree;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RewriteRuleSubtreeStream
/*    */   extends RewriteRuleElementStream
/*    */ {
/*    */   public RewriteRuleSubtreeStream(TreeAdaptor adaptor, String elementDescription) {
/* 35 */     super(adaptor, elementDescription);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RewriteRuleSubtreeStream(TreeAdaptor adaptor, String elementDescription, Object oneElement) {
/* 43 */     super(adaptor, elementDescription, oneElement);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RewriteRuleSubtreeStream(TreeAdaptor adaptor, String elementDescription, List elements) {
/* 51 */     super(adaptor, elementDescription, elements);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object nextNode() {
/* 69 */     int n = size();
/* 70 */     if (this.dirty || (this.cursor >= n && n == 1)) {
/*    */ 
/*    */       
/* 73 */       Object object = _next();
/* 74 */       return this.adaptor.dupNode(object);
/*    */     } 
/*    */     
/* 77 */     Object tree = _next();
/* 78 */     while (this.adaptor.isNil(tree) && this.adaptor.getChildCount(tree) == 1) {
/* 79 */       tree = this.adaptor.getChild(tree, 0);
/*    */     }
/* 81 */     Object el = this.adaptor.dupNode(tree);
/* 82 */     return el;
/*    */   }
/*    */   
/*    */   protected Object dup(Object el) {
/* 86 */     return this.adaptor.dupTree(el);
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\RewriteRuleSubtreeStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */