/*     */ package org.antlr.runtime.tree;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.antlr.runtime.BaseRecognizer;
/*     */ import org.antlr.runtime.BitSet;
/*     */ import org.antlr.runtime.CommonToken;
/*     */ import org.antlr.runtime.IntStream;
/*     */ import org.antlr.runtime.MismatchedTreeNodeException;
/*     */ import org.antlr.runtime.RecognitionException;
/*     */ import org.antlr.runtime.RecognizerSharedState;
/*     */ import org.antlr.runtime.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeParser
/*     */   extends BaseRecognizer
/*     */ {
/*     */   public static final int DOWN = 2;
/*     */   public static final int UP = 3;
/*  44 */   static String dotdot = ".*[^.]\\.\\.[^.].*";
/*  45 */   static String doubleEtc = ".*\\.\\.\\.\\s+\\.\\.\\..*";
/*  46 */   static Pattern dotdotPattern = Pattern.compile(dotdot);
/*  47 */   static Pattern doubleEtcPattern = Pattern.compile(doubleEtc);
/*     */   
/*     */   protected TreeNodeStream input;
/*     */ 
/*     */   
/*     */   public TreeParser(TreeNodeStream input) {
/*  53 */     setTreeNodeStream(input);
/*     */   }
/*     */   
/*     */   public TreeParser(TreeNodeStream input, RecognizerSharedState state) {
/*  57 */     super(state);
/*  58 */     setTreeNodeStream(input);
/*     */   }
/*     */   
/*     */   public void reset() {
/*  62 */     super.reset();
/*  63 */     if (this.input != null) {
/*  64 */       this.input.seek(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTreeNodeStream(TreeNodeStream input) {
/*  70 */     this.input = input;
/*     */   }
/*     */   
/*     */   public TreeNodeStream getTreeNodeStream() {
/*  74 */     return this.input;
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/*  78 */     return this.input.getSourceName();
/*     */   }
/*     */   
/*     */   protected Object getCurrentInputSymbol(IntStream input) {
/*  82 */     return ((TreeNodeStream)input).LT(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getMissingSymbol(IntStream input, RecognitionException e, int expectedTokenType, BitSet follow) {
/*  90 */     String tokenText = "<missing " + getTokenNames()[expectedTokenType] + ">";
/*     */     
/*  92 */     TreeAdaptor adaptor = ((TreeNodeStream)e.input).getTreeAdaptor();
/*  93 */     return adaptor.create((Token)new CommonToken(expectedTokenType, tokenText));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void matchAny(IntStream ignore) {
/* 101 */     this.state.errorRecovery = false;
/* 102 */     this.state.failed = false;
/* 103 */     Object look = this.input.LT(1);
/* 104 */     if (this.input.getTreeAdaptor().getChildCount(look) == 0) {
/* 105 */       this.input.consume();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 110 */     int level = 0;
/* 111 */     int tokenType = this.input.getTreeAdaptor().getType(look);
/* 112 */     while (tokenType != -1 && (tokenType != 3 || level != 0)) {
/* 113 */       this.input.consume();
/* 114 */       look = this.input.LT(1);
/* 115 */       tokenType = this.input.getTreeAdaptor().getType(look);
/* 116 */       if (tokenType == 2) {
/* 117 */         level++; continue;
/*     */       } 
/* 119 */       if (tokenType == 3) {
/* 120 */         level--;
/*     */       }
/*     */     } 
/* 123 */     this.input.consume();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object recoverFromMismatchedToken(IntStream input, int ttype, BitSet follow) throws RecognitionException {
/* 135 */     throw new MismatchedTreeNodeException(ttype, (TreeNodeStream)input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorHeader(RecognitionException e) {
/* 143 */     return getGrammarFileName() + ": node from " + (e.approximateLineInfo ? "after " : "") + "line " + e.line + ":" + e.charPositionInLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage(RecognitionException e, String[] tokenNames) {
/* 151 */     if (this instanceof TreeParser) {
/* 152 */       TreeAdaptor adaptor = ((TreeNodeStream)e.input).getTreeAdaptor();
/* 153 */       e.token = adaptor.getToken(e.node);
/* 154 */       if (e.token == null) {
/* 155 */         e.token = (Token)new CommonToken(adaptor.getType(e.node), adaptor.getText(e.node));
/*     */       }
/*     */     } 
/*     */     
/* 159 */     return super.getErrorMessage(e, tokenNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean inContext(String context) {
/* 173 */     return inContext(this.input.getTreeAdaptor(), getTokenNames(), this.input.LT(1), context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean inContext(TreeAdaptor adaptor, String[] tokenNames, Object t, String context) {
/* 184 */     Matcher dotdotMatcher = dotdotPattern.matcher(context);
/* 185 */     Matcher doubleEtcMatcher = doubleEtcPattern.matcher(context);
/* 186 */     if (dotdotMatcher.find()) {
/* 187 */       throw new IllegalArgumentException("invalid syntax: ..");
/*     */     }
/* 189 */     if (doubleEtcMatcher.find()) {
/* 190 */       throw new IllegalArgumentException("invalid syntax: ... ...");
/*     */     }
/* 192 */     context = context.replaceAll("\\.\\.\\.", " ... ");
/* 193 */     context = context.trim();
/* 194 */     String[] nodes = context.split("\\s+");
/* 195 */     int ni = nodes.length - 1;
/* 196 */     t = adaptor.getParent(t);
/* 197 */     while (ni >= 0 && t != null) {
/* 198 */       if (nodes[ni].equals("...")) {
/*     */         
/* 200 */         if (ni == 0) return true; 
/* 201 */         String goal = nodes[ni - 1];
/* 202 */         Object ancestor = getAncestor(adaptor, tokenNames, t, goal);
/* 203 */         if (ancestor == null) return false; 
/* 204 */         t = ancestor;
/* 205 */         ni--;
/*     */       } 
/* 207 */       String name = tokenNames[adaptor.getType(t)];
/* 208 */       if (!name.equals(nodes[ni]))
/*     */       {
/* 210 */         return false;
/*     */       }
/*     */       
/* 213 */       ni--;
/* 214 */       t = adaptor.getParent(t);
/*     */     } 
/*     */     
/* 217 */     if (t == null && ni >= 0) return false; 
/* 218 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Object getAncestor(TreeAdaptor adaptor, String[] tokenNames, Object t, String goal) {
/* 223 */     while (t != null) {
/* 224 */       String name = tokenNames[adaptor.getType(t)];
/* 225 */       if (name.equals(goal)) return t; 
/* 226 */       t = adaptor.getParent(t);
/*     */     } 
/* 228 */     return null;
/*     */   }
/*     */   
/*     */   public void traceIn(String ruleName, int ruleIndex) {
/* 232 */     traceIn(ruleName, ruleIndex, this.input.LT(1));
/*     */   }
/*     */   
/*     */   public void traceOut(String ruleName, int ruleIndex) {
/* 236 */     traceOut(ruleName, ruleIndex, this.input.LT(1));
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\TreeParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */