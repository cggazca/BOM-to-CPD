package org.antlr.runtime.tree;

public interface TreeVisitorAction {
  Object pre(Object paramObject);
  
  Object post(Object paramObject);
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\TreeVisitorAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */