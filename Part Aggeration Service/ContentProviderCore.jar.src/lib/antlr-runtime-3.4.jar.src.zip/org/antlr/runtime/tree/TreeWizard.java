/*     */ package org.antlr.runtime.tree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.runtime.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeWizard
/*     */ {
/*     */   protected TreeAdaptor adaptor;
/*     */   protected Map tokenNameToTypeMap;
/*     */   
/*     */   public static abstract class Visitor
/*     */     implements ContextVisitor
/*     */   {
/*     */     public void visit(Object t, Object parent, int childIndex, Map labels) {
/*  64 */       visit(t);
/*     */     }
/*     */     
/*     */     public abstract void visit(Object param1Object);
/*     */   }
/*     */   
/*     */   public static class TreePattern
/*     */     extends CommonTree {
/*     */     public String label;
/*     */     public boolean hasTextArg;
/*     */     
/*     */     public TreePattern(Token payload) {
/*  76 */       super(payload);
/*     */     }
/*     */     public String toString() {
/*  79 */       if (this.label != null) {
/*  80 */         return "%" + this.label + ":" + super.toString();
/*     */       }
/*     */       
/*  83 */       return super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WildcardTreePattern
/*     */     extends TreePattern {
/*     */     public WildcardTreePattern(Token payload) {
/*  90 */       super(payload);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TreePatternTreeAdaptor
/*     */     extends CommonTreeAdaptor {
/*     */     public Object create(Token payload) {
/*  97 */       return new TreeWizard.TreePattern(payload);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeWizard(TreeAdaptor adaptor) {
/* 123 */     this.adaptor = adaptor;
/*     */   }
/*     */   
/*     */   public TreeWizard(TreeAdaptor adaptor, Map tokenNameToTypeMap) {
/* 127 */     this.adaptor = adaptor;
/* 128 */     this.tokenNameToTypeMap = tokenNameToTypeMap;
/*     */   }
/*     */   
/*     */   public TreeWizard(TreeAdaptor adaptor, String[] tokenNames) {
/* 132 */     this.adaptor = adaptor;
/* 133 */     this.tokenNameToTypeMap = computeTokenTypes(tokenNames);
/*     */   }
/*     */   
/*     */   public TreeWizard(String[] tokenNames) {
/* 137 */     this(new CommonTreeAdaptor(), tokenNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map computeTokenTypes(String[] tokenNames) {
/* 144 */     Map m = new HashMap();
/* 145 */     if (tokenNames == null) {
/* 146 */       return m;
/*     */     }
/* 148 */     for (int ttype = 4; ttype < tokenNames.length; ttype++) {
/* 149 */       String name = tokenNames[ttype];
/* 150 */       m.put(name, new Integer(ttype));
/*     */     } 
/* 152 */     return m;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTokenType(String tokenName) {
/* 157 */     if (this.tokenNameToTypeMap == null) {
/* 158 */       return 0;
/*     */     }
/* 160 */     Integer ttypeI = (Integer)this.tokenNameToTypeMap.get(tokenName);
/* 161 */     if (ttypeI != null) {
/* 162 */       return ttypeI.intValue();
/*     */     }
/* 164 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map index(Object t) {
/* 175 */     Map m = new HashMap();
/* 176 */     _index(t, m);
/* 177 */     return m;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _index(Object t, Map m) {
/* 182 */     if (t == null) {
/*     */       return;
/*     */     }
/* 185 */     int ttype = this.adaptor.getType(t);
/* 186 */     List elements = (List)m.get(new Integer(ttype));
/* 187 */     if (elements == null) {
/* 188 */       elements = new ArrayList();
/* 189 */       m.put(new Integer(ttype), elements);
/*     */     } 
/* 191 */     elements.add(t);
/* 192 */     int n = this.adaptor.getChildCount(t);
/* 193 */     for (int i = 0; i < n; i++) {
/* 194 */       Object child = this.adaptor.getChild(t, i);
/* 195 */       _index(child, m);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List find(Object t, int ttype) {
/* 201 */     final List nodes = new ArrayList();
/* 202 */     visit(t, ttype, new Visitor() { private final List val$nodes; private final TreeWizard this$0;
/*     */           public void visit(Object t) {
/* 204 */             nodes.add(t);
/*     */           } }
/*     */       );
/* 207 */     return nodes;
/*     */   }
/*     */ 
/*     */   
/*     */   public List find(Object t, String pattern) {
/* 212 */     final List subtrees = new ArrayList();
/*     */     
/* 214 */     TreePatternLexer tokenizer = new TreePatternLexer(pattern);
/* 215 */     TreePatternParser parser = new TreePatternParser(tokenizer, this, new TreePatternTreeAdaptor());
/*     */     
/* 217 */     final TreePattern tpattern = (TreePattern)parser.pattern();
/*     */     
/* 219 */     if (tpattern == null || tpattern.isNil() || tpattern.getClass() == WildcardTreePattern.class)
/*     */     {
/*     */ 
/*     */       
/* 223 */       return null;
/*     */     }
/* 225 */     int rootTokenType = tpattern.getType();
/* 226 */     visit(t, rootTokenType, new ContextVisitor() { private final TreeWizard.TreePattern val$tpattern;
/*     */           public void visit(Object t, Object parent, int childIndex, Map labels) {
/* 228 */             if (TreeWizard.this._parse(t, tpattern, null))
/* 229 */               subtrees.add(t); 
/*     */           }
/*     */           private final List val$subtrees; private final TreeWizard this$0; }
/*     */       );
/* 233 */     return subtrees;
/*     */   }
/*     */   
/*     */   public Object findFirst(Object t, int ttype) {
/* 237 */     return null;
/*     */   }
/*     */   
/*     */   public Object findFirst(Object t, String pattern) {
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Object t, int ttype, ContextVisitor visitor) {
/* 250 */     _visit(t, null, 0, ttype, visitor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _visit(Object t, Object parent, int childIndex, int ttype, ContextVisitor visitor) {
/* 255 */     if (t == null) {
/*     */       return;
/*     */     }
/* 258 */     if (this.adaptor.getType(t) == ttype) {
/* 259 */       visitor.visit(t, parent, childIndex, null);
/*     */     }
/* 261 */     int n = this.adaptor.getChildCount(t);
/* 262 */     for (int i = 0; i < n; i++) {
/* 263 */       Object child = this.adaptor.getChild(t, i);
/* 264 */       _visit(child, t, i, ttype, visitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Object t, String pattern, final ContextVisitor visitor) {
/* 275 */     TreePatternLexer tokenizer = new TreePatternLexer(pattern);
/* 276 */     TreePatternParser parser = new TreePatternParser(tokenizer, this, new TreePatternTreeAdaptor());
/*     */     
/* 278 */     final TreePattern tpattern = (TreePattern)parser.pattern();
/*     */     
/* 280 */     if (tpattern == null || tpattern.isNil() || tpattern.getClass() == WildcardTreePattern.class) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 286 */     final Map labels = new HashMap();
/* 287 */     int rootTokenType = tpattern.getType();
/* 288 */     visit(t, rootTokenType, new ContextVisitor() { private final Map val$labels; private final TreeWizard.TreePattern val$tpattern; private final TreeWizard.ContextVisitor val$visitor; private final TreeWizard this$0;
/*     */           
/*     */           public void visit(Object t, Object parent, int childIndex, Map unusedlabels) {
/* 291 */             labels.clear();
/* 292 */             if (TreeWizard.this._parse(t, tpattern, labels)) {
/* 293 */               visitor.visit(t, parent, childIndex, labels);
/*     */             }
/*     */           } }
/*     */       );
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean parse(Object t, String pattern, Map labels) {
/* 311 */     TreePatternLexer tokenizer = new TreePatternLexer(pattern);
/* 312 */     TreePatternParser parser = new TreePatternParser(tokenizer, this, new TreePatternTreeAdaptor());
/*     */     
/* 314 */     TreePattern tpattern = (TreePattern)parser.pattern();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     boolean matched = _parse(t, tpattern, labels);
/* 320 */     return matched;
/*     */   }
/*     */   
/*     */   public boolean parse(Object t, String pattern) {
/* 324 */     return parse(t, pattern, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _parse(Object t1, TreePattern tpattern, Map labels) {
/* 334 */     if (t1 == null || tpattern == null) {
/* 335 */       return false;
/*     */     }
/*     */     
/* 338 */     if (tpattern.getClass() != WildcardTreePattern.class) {
/* 339 */       if (this.adaptor.getType(t1) != tpattern.getType()) return false;
/*     */       
/* 341 */       if (tpattern.hasTextArg && !this.adaptor.getText(t1).equals(tpattern.getText())) {
/* 342 */         return false;
/*     */       }
/*     */     } 
/* 345 */     if (tpattern.label != null && labels != null)
/*     */     {
/* 347 */       labels.put(tpattern.label, t1);
/*     */     }
/*     */     
/* 350 */     int n1 = this.adaptor.getChildCount(t1);
/* 351 */     int n2 = tpattern.getChildCount();
/* 352 */     if (n1 != n2) {
/* 353 */       return false;
/*     */     }
/* 355 */     for (int i = 0; i < n1; i++) {
/* 356 */       Object child1 = this.adaptor.getChild(t1, i);
/* 357 */       TreePattern child2 = (TreePattern)tpattern.getChild(i);
/* 358 */       if (!_parse(child1, child2, labels)) {
/* 359 */         return false;
/*     */       }
/*     */     } 
/* 362 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object create(String pattern) {
/* 379 */     TreePatternLexer tokenizer = new TreePatternLexer(pattern);
/* 380 */     TreePatternParser parser = new TreePatternParser(tokenizer, this, this.adaptor);
/* 381 */     Object t = parser.pattern();
/* 382 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(Object t1, Object t2, TreeAdaptor adaptor) {
/* 395 */     return _equals(t1, t2, adaptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object t1, Object t2) {
/* 402 */     return _equals(t1, t2, this.adaptor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean _equals(Object t1, Object t2, TreeAdaptor adaptor) {
/* 407 */     if (t1 == null || t2 == null) {
/* 408 */       return false;
/*     */     }
/*     */     
/* 411 */     if (adaptor.getType(t1) != adaptor.getType(t2)) {
/* 412 */       return false;
/*     */     }
/* 414 */     if (!adaptor.getText(t1).equals(adaptor.getText(t2))) {
/* 415 */       return false;
/*     */     }
/*     */     
/* 418 */     int n1 = adaptor.getChildCount(t1);
/* 419 */     int n2 = adaptor.getChildCount(t2);
/* 420 */     if (n1 != n2) {
/* 421 */       return false;
/*     */     }
/* 423 */     for (int i = 0; i < n1; i++) {
/* 424 */       Object child1 = adaptor.getChild(t1, i);
/* 425 */       Object child2 = adaptor.getChild(t2, i);
/* 426 */       if (!_equals(child1, child2, adaptor)) {
/* 427 */         return false;
/*     */       }
/*     */     } 
/* 430 */     return true;
/*     */   }
/*     */   
/*     */   public static interface ContextVisitor {
/*     */     void visit(Object param1Object1, Object param1Object2, int param1Int, Map param1Map);
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\TreeWizard.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */