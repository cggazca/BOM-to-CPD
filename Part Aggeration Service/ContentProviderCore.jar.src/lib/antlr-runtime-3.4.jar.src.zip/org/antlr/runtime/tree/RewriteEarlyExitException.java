/*    */ package org.antlr.runtime.tree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RewriteEarlyExitException
/*    */   extends RewriteCardinalityException
/*    */ {
/*    */   public RewriteEarlyExitException() {
/* 33 */     super(null);
/*    */   }
/*    */   public RewriteEarlyExitException(String elementDescription) {
/* 36 */     super(elementDescription);
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\tree\RewriteEarlyExitException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */