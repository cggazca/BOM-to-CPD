/*    */ package org.antlr.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Parser
/*    */   extends BaseRecognizer
/*    */ {
/*    */   public TokenStream input;
/*    */   
/*    */   public Parser(TokenStream input) {
/* 40 */     setTokenStream(input);
/*    */   }
/*    */   
/*    */   public Parser(TokenStream input, RecognizerSharedState state) {
/* 44 */     super(state);
/* 45 */     this.input = input;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 49 */     super.reset();
/* 50 */     if (this.input != null) {
/* 51 */       this.input.seek(0);
/*    */     }
/*    */   }
/*    */   
/*    */   protected Object getCurrentInputSymbol(IntStream input) {
/* 56 */     return ((TokenStream)input).LT(1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getMissingSymbol(IntStream input, RecognitionException e, int expectedTokenType, BitSet follow) {
/* 64 */     String tokenText = null;
/* 65 */     if (expectedTokenType == -1) { tokenText = "<missing EOF>"; }
/* 66 */     else { tokenText = "<missing " + getTokenNames()[expectedTokenType] + ">"; }
/* 67 */      CommonToken t = new CommonToken(expectedTokenType, tokenText);
/* 68 */     Token current = ((TokenStream)input).LT(1);
/* 69 */     if (current.getType() == -1) {
/* 70 */       current = ((TokenStream)input).LT(-1);
/*    */     }
/* 72 */     t.line = current.getLine();
/* 73 */     t.charPositionInLine = current.getCharPositionInLine();
/* 74 */     t.channel = 0;
/* 75 */     t.input = current.getInputStream();
/* 76 */     return t;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTokenStream(TokenStream input) {
/* 81 */     this.input = null;
/* 82 */     reset();
/* 83 */     this.input = input;
/*    */   }
/*    */   
/*    */   public TokenStream getTokenStream() {
/* 87 */     return this.input;
/*    */   }
/*    */   
/*    */   public String getSourceName() {
/* 91 */     return this.input.getSourceName();
/*    */   }
/*    */   
/*    */   public void traceIn(String ruleName, int ruleIndex) {
/* 95 */     traceIn(ruleName, ruleIndex, this.input.LT(1));
/*    */   }
/*    */   
/*    */   public void traceOut(String ruleName, int ruleIndex) {
/* 99 */     traceOut(ruleName, ruleIndex, this.input.LT(1));
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\Parser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */