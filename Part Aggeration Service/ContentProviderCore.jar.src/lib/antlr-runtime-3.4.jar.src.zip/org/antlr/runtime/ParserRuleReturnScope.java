/*    */ package org.antlr.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserRuleReturnScope
/*    */   extends RuleReturnScope
/*    */ {
/*    */   public Token start;
/*    */   public Token stop;
/*    */   public Object tree;
/*    */   
/*    */   public Object getStart() {
/* 52 */     return this.start; } public Object getStop() {
/* 53 */     return this.stop;
/*    */   }
/*    */   public Object getTree() {
/* 56 */     return this.tree;
/*    */   }
/*    */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\ParserRuleReturnScope.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */