/*     */ package org.antlr.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenRewriteStream
/*     */   extends CommonTokenStream
/*     */ {
/*     */   public static final String DEFAULT_PROGRAM_NAME = "default";
/*     */   public static final int PROGRAM_INIT_SIZE = 100;
/*     */   public static final int MIN_TOKEN_INDEX = 0;
/*     */   
/*     */   class RewriteOperation
/*     */   {
/*     */     protected int instructionIndex;
/*     */     protected int index;
/*     */     protected Object text;
/*     */     private final TokenRewriteStream this$0;
/*     */     
/*     */     protected RewriteOperation(int index) {
/*  98 */       this.index = index;
/*     */     }
/*     */     
/*     */     protected RewriteOperation(int index, Object text) {
/* 102 */       this.index = index;
/* 103 */       this.text = text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int execute(StringBuffer buf) {
/* 109 */       return this.index;
/*     */     }
/*     */     public String toString() {
/* 112 */       String opName = getClass().getName();
/* 113 */       int $index = opName.indexOf('$');
/* 114 */       opName = opName.substring($index + 1, opName.length());
/* 115 */       return "<" + opName + "@" + TokenRewriteStream.this.tokens.get(this.index) + ":\"" + this.text + "\">";
/*     */     } }
/*     */   
/*     */   class InsertBeforeOp extends RewriteOperation {
/*     */     private final TokenRewriteStream this$0;
/*     */     
/*     */     public InsertBeforeOp(int index, Object text) {
/* 122 */       super(index, text);
/*     */     }
/*     */     public int execute(StringBuffer buf) {
/* 125 */       buf.append(this.text);
/* 126 */       if (((Token)TokenRewriteStream.this.tokens.get(this.index)).getType() != -1) {
/* 127 */         buf.append(((Token)TokenRewriteStream.this.tokens.get(this.index)).getText());
/*     */       }
/* 129 */       return this.index + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   class ReplaceOp
/*     */     extends RewriteOperation {
/*     */     protected int lastIndex;
/*     */     private final TokenRewriteStream this$0;
/*     */     
/*     */     public ReplaceOp(int from, int to, Object text) {
/* 139 */       super(from, text);
/* 140 */       this.lastIndex = to;
/*     */     }
/*     */     public int execute(StringBuffer buf) {
/* 143 */       if (this.text != null) {
/* 144 */         buf.append(this.text);
/*     */       }
/* 146 */       return this.lastIndex + 1;
/*     */     }
/*     */     public String toString() {
/* 149 */       if (this.text == null) {
/* 150 */         return "<DeleteOp@" + TokenRewriteStream.this.tokens.get(this.index) + ".." + TokenRewriteStream.this.tokens.get(this.lastIndex) + ">";
/*     */       }
/*     */       
/* 153 */       return "<ReplaceOp@" + TokenRewriteStream.this.tokens.get(this.index) + ".." + TokenRewriteStream.this.tokens.get(this.lastIndex) + ":\"" + this.text + "\">";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   protected Map programs = null;
/*     */ 
/*     */   
/* 165 */   protected Map lastRewriteTokenIndexes = null;
/*     */   
/*     */   public TokenRewriteStream() {
/* 168 */     init();
/*     */   }
/*     */   
/*     */   protected void init() {
/* 172 */     this.programs = new HashMap();
/* 173 */     this.programs.put("default", new ArrayList(100));
/* 174 */     this.lastRewriteTokenIndexes = new HashMap();
/*     */   }
/*     */   
/*     */   public TokenRewriteStream(TokenSource tokenSource) {
/* 178 */     super(tokenSource);
/* 179 */     init();
/*     */   }
/*     */   
/*     */   public TokenRewriteStream(TokenSource tokenSource, int channel) {
/* 183 */     super(tokenSource, channel);
/* 184 */     init();
/*     */   }
/*     */   
/*     */   public void rollback(int instructionIndex) {
/* 188 */     rollback("default", instructionIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(String programName, int instructionIndex) {
/* 196 */     List is = (List)this.programs.get(programName);
/* 197 */     if (is != null) {
/* 198 */       this.programs.put(programName, is.subList(0, instructionIndex));
/*     */     }
/*     */   }
/*     */   
/*     */   public void deleteProgram() {
/* 203 */     deleteProgram("default");
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteProgram(String programName) {
/* 208 */     rollback(programName, 0);
/*     */   }
/*     */   
/*     */   public void insertAfter(Token t, Object text) {
/* 212 */     insertAfter("default", t, text);
/*     */   }
/*     */   
/*     */   public void insertAfter(int index, Object text) {
/* 216 */     insertAfter("default", index, text);
/*     */   }
/*     */   
/*     */   public void insertAfter(String programName, Token t, Object text) {
/* 220 */     insertAfter(programName, t.getTokenIndex(), text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertAfter(String programName, int index, Object text) {
/* 225 */     insertBefore(programName, index + 1, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(Token t, Object text) {
/* 229 */     insertBefore("default", t, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(int index, Object text) {
/* 233 */     insertBefore("default", index, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(String programName, Token t, Object text) {
/* 237 */     insertBefore(programName, t.getTokenIndex(), text);
/*     */   }
/*     */   
/*     */   public void insertBefore(String programName, int index, Object text) {
/* 241 */     RewriteOperation op = new InsertBeforeOp(index, text);
/* 242 */     List rewrites = getProgram(programName);
/* 243 */     op.instructionIndex = rewrites.size();
/* 244 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void replace(int index, Object text) {
/* 248 */     replace("default", index, index, text);
/*     */   }
/*     */   
/*     */   public void replace(int from, int to, Object text) {
/* 252 */     replace("default", from, to, text);
/*     */   }
/*     */   
/*     */   public void replace(Token indexT, Object text) {
/* 256 */     replace("default", indexT, indexT, text);
/*     */   }
/*     */   
/*     */   public void replace(Token from, Token to, Object text) {
/* 260 */     replace("default", from, to, text);
/*     */   }
/*     */   
/*     */   public void replace(String programName, int from, int to, Object text) {
/* 264 */     if (from > to || from < 0 || to < 0 || to >= this.tokens.size()) {
/* 265 */       throw new IllegalArgumentException("replace: range invalid: " + from + ".." + to + "(size=" + this.tokens.size() + ")");
/*     */     }
/* 267 */     RewriteOperation op = new ReplaceOp(from, to, text);
/* 268 */     List rewrites = getProgram(programName);
/* 269 */     op.instructionIndex = rewrites.size();
/* 270 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void replace(String programName, Token from, Token to, Object text) {
/* 274 */     replace(programName, from.getTokenIndex(), to.getTokenIndex(), text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/* 281 */     delete("default", index, index);
/*     */   }
/*     */   
/*     */   public void delete(int from, int to) {
/* 285 */     delete("default", from, to);
/*     */   }
/*     */   
/*     */   public void delete(Token indexT) {
/* 289 */     delete("default", indexT, indexT);
/*     */   }
/*     */   
/*     */   public void delete(Token from, Token to) {
/* 293 */     delete("default", from, to);
/*     */   }
/*     */   
/*     */   public void delete(String programName, int from, int to) {
/* 297 */     replace(programName, from, to, (Object)null);
/*     */   }
/*     */   
/*     */   public void delete(String programName, Token from, Token to) {
/* 301 */     replace(programName, from, to, (Object)null);
/*     */   }
/*     */   
/*     */   public int getLastRewriteTokenIndex() {
/* 305 */     return getLastRewriteTokenIndex("default");
/*     */   }
/*     */   
/*     */   protected int getLastRewriteTokenIndex(String programName) {
/* 309 */     Integer I = (Integer)this.lastRewriteTokenIndexes.get(programName);
/* 310 */     if (I == null) {
/* 311 */       return -1;
/*     */     }
/* 313 */     return I.intValue();
/*     */   }
/*     */   
/*     */   protected void setLastRewriteTokenIndex(String programName, int i) {
/* 317 */     this.lastRewriteTokenIndexes.put(programName, new Integer(i));
/*     */   }
/*     */   
/*     */   protected List getProgram(String name) {
/* 321 */     List is = (List)this.programs.get(name);
/* 322 */     if (is == null) {
/* 323 */       is = initializeProgram(name);
/*     */     }
/* 325 */     return is;
/*     */   }
/*     */   
/*     */   private List initializeProgram(String name) {
/* 329 */     List is = new ArrayList(100);
/* 330 */     this.programs.put(name, is);
/* 331 */     return is;
/*     */   }
/*     */   
/*     */   public String toOriginalString() {
/* 335 */     fill();
/* 336 */     return toOriginalString(0, size() - 1);
/*     */   }
/*     */   
/*     */   public String toOriginalString(int start, int end) {
/* 340 */     StringBuffer buf = new StringBuffer();
/* 341 */     for (int i = start; i >= 0 && i <= end && i < this.tokens.size(); i++) {
/* 342 */       if (get(i).getType() != -1) buf.append(get(i).getText()); 
/*     */     } 
/* 344 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 348 */     fill();
/* 349 */     return toString(0, size() - 1);
/*     */   }
/*     */   
/*     */   public String toString(String programName) {
/* 353 */     fill();
/* 354 */     return toString(programName, 0, size() - 1);
/*     */   }
/*     */   
/*     */   public String toString(int start, int end) {
/* 358 */     return toString("default", start, end);
/*     */   }
/*     */   
/*     */   public String toString(String programName, int start, int end) {
/* 362 */     List rewrites = (List)this.programs.get(programName);
/*     */ 
/*     */     
/* 365 */     if (end > this.tokens.size() - 1) end = this.tokens.size() - 1; 
/* 366 */     if (start < 0) start = 0;
/*     */     
/* 368 */     if (rewrites == null || rewrites.size() == 0) {
/* 369 */       return toOriginalString(start, end);
/*     */     }
/* 371 */     StringBuffer buf = new StringBuffer();
/*     */ 
/*     */     
/* 374 */     Map indexToOp = reduceToSingleOperationPerIndex(rewrites);
/*     */ 
/*     */     
/* 377 */     int i = start;
/* 378 */     while (i <= end && i < this.tokens.size()) {
/* 379 */       RewriteOperation op = (RewriteOperation)indexToOp.get(new Integer(i));
/* 380 */       indexToOp.remove(new Integer(i));
/* 381 */       Token t = this.tokens.get(i);
/* 382 */       if (op == null) {
/*     */         
/* 384 */         if (t.getType() != -1) buf.append(t.getText()); 
/* 385 */         i++;
/*     */         continue;
/*     */       } 
/* 388 */       i = op.execute(buf);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 395 */     if (end == this.tokens.size() - 1) {
/*     */ 
/*     */       
/* 398 */       Iterator it = indexToOp.values().iterator();
/* 399 */       while (it.hasNext()) {
/* 400 */         RewriteOperation op = it.next();
/* 401 */         if (op.index >= this.tokens.size() - 1) buf.append(op.text); 
/*     */       } 
/*     */     } 
/* 404 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map reduceToSingleOperationPerIndex(List rewrites) {
/*     */     int i;
/* 460 */     for (i = 0; i < rewrites.size(); i++) {
/* 461 */       RewriteOperation op = rewrites.get(i);
/* 462 */       if (op != null && 
/* 463 */         op instanceof ReplaceOp) {
/* 464 */         ReplaceOp rop = (ReplaceOp)rewrites.get(i);
/*     */         
/* 466 */         List inserts = getKindOfOps(rewrites, InsertBeforeOp.class, i);
/* 467 */         for (int k = 0; k < inserts.size(); k++) {
/* 468 */           InsertBeforeOp iop = inserts.get(k);
/* 469 */           if (iop.index == rop.index) {
/*     */ 
/*     */             
/* 472 */             rewrites.set(iop.instructionIndex, null);
/* 473 */             rop.text = iop.text.toString() + ((rop.text != null) ? rop.text.toString() : "");
/*     */           }
/* 475 */           else if (iop.index > rop.index && iop.index <= rop.lastIndex) {
/*     */             
/* 477 */             rewrites.set(iop.instructionIndex, null);
/*     */           } 
/*     */         } 
/*     */         
/* 481 */         List prevReplaces = getKindOfOps(rewrites, ReplaceOp.class, i);
/* 482 */         for (int n = 0; n < prevReplaces.size(); n++) {
/* 483 */           ReplaceOp prevRop = prevReplaces.get(n);
/* 484 */           if (prevRop.index >= rop.index && prevRop.lastIndex <= rop.lastIndex) {
/*     */             
/* 486 */             rewrites.set(prevRop.instructionIndex, null);
/*     */           }
/*     */           else {
/*     */             
/* 490 */             boolean disjoint = (prevRop.lastIndex < rop.index || prevRop.index > rop.lastIndex);
/*     */             
/* 492 */             boolean same = (prevRop.index == rop.index && prevRop.lastIndex == rop.lastIndex);
/*     */ 
/*     */ 
/*     */             
/* 496 */             if (prevRop.text == null && rop.text == null && !disjoint) {
/*     */               
/* 498 */               rewrites.set(prevRop.instructionIndex, null);
/* 499 */               rop.index = Math.min(prevRop.index, rop.index);
/* 500 */               rop.lastIndex = Math.max(prevRop.lastIndex, rop.lastIndex);
/* 501 */               System.out.println("new rop " + rop);
/*     */             }
/* 503 */             else if (!disjoint && !same) {
/* 504 */               throw new IllegalArgumentException("replace op boundaries of " + rop + " overlap with previous " + prevRop);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 511 */     for (i = 0; i < rewrites.size(); i++) {
/* 512 */       RewriteOperation op = rewrites.get(i);
/* 513 */       if (op != null && 
/* 514 */         op instanceof InsertBeforeOp) {
/* 515 */         InsertBeforeOp iop = (InsertBeforeOp)rewrites.get(i);
/*     */         
/* 517 */         List prevInserts = getKindOfOps(rewrites, InsertBeforeOp.class, i);
/* 518 */         for (int k = 0; k < prevInserts.size(); k++) {
/* 519 */           InsertBeforeOp prevIop = prevInserts.get(k);
/* 520 */           if (prevIop.index == iop.index) {
/*     */ 
/*     */             
/* 523 */             iop.text = catOpText(iop.text, prevIop.text);
/*     */             
/* 525 */             rewrites.set(prevIop.instructionIndex, null);
/*     */           } 
/*     */         } 
/*     */         
/* 529 */         List prevReplaces = getKindOfOps(rewrites, ReplaceOp.class, i);
/* 530 */         for (int n = 0; n < prevReplaces.size(); n++) {
/* 531 */           ReplaceOp rop = prevReplaces.get(n);
/* 532 */           if (iop.index == rop.index) {
/* 533 */             rop.text = catOpText(iop.text, rop.text);
/* 534 */             rewrites.set(i, null);
/*     */           
/*     */           }
/* 537 */           else if (iop.index >= rop.index && iop.index <= rop.lastIndex) {
/* 538 */             throw new IllegalArgumentException("insert op " + iop + " within boundaries of previous " + rop);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 544 */     Map m = new HashMap();
/* 545 */     for (int j = 0; j < rewrites.size(); j++) {
/* 546 */       RewriteOperation op = rewrites.get(j);
/* 547 */       if (op != null) {
/* 548 */         if (m.get(new Integer(op.index)) != null) {
/* 549 */           throw new Error("should only be one op per index");
/*     */         }
/* 551 */         m.put(new Integer(op.index), op);
/*     */       } 
/*     */     } 
/* 554 */     return m;
/*     */   }
/*     */   
/*     */   protected String catOpText(Object a, Object b) {
/* 558 */     String x = "";
/* 559 */     String y = "";
/* 560 */     if (a != null) x = a.toString(); 
/* 561 */     if (b != null) y = b.toString(); 
/* 562 */     return x + y;
/*     */   }
/*     */   protected List getKindOfOps(List rewrites, Class kind) {
/* 565 */     return getKindOfOps(rewrites, kind, rewrites.size());
/*     */   }
/*     */ 
/*     */   
/*     */   protected List getKindOfOps(List rewrites, Class kind, int before) {
/* 570 */     List ops = new ArrayList();
/* 571 */     for (int i = 0; i < before && i < rewrites.size(); i++) {
/* 572 */       RewriteOperation op = rewrites.get(i);
/* 573 */       if (op != null && 
/* 574 */         op.getClass() == kind) ops.add(op); 
/*     */     } 
/* 576 */     return ops;
/*     */   }
/*     */   
/*     */   public String toDebugString() {
/* 580 */     return toDebugString(0, size() - 1);
/*     */   }
/*     */   
/*     */   public String toDebugString(int start, int end) {
/* 584 */     StringBuffer buf = new StringBuffer();
/* 585 */     for (int i = start; i >= 0 && i <= end && i < this.tokens.size(); i++) {
/* 586 */       buf.append(get(i));
/*     */     }
/* 588 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\lib\antlr-runtime-3.4.jar!\org\antlr\runtime\TokenRewriteStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */