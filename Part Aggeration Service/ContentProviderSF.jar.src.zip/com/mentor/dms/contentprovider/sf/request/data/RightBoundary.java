package com.mentor.dms.contentprovider.sf.request.data;

public class RightBoundary {
  private boolean inclusive = false;
  
  private Object value;
  
  public RightBoundary(Object paramObject, boolean paramBoolean) {
    this.value = paramObject;
    this.inclusive = paramBoolean;
  }
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderSF.jar!\com\mentor\dms\contentprovider\sf\request\data\RightBoundary.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */