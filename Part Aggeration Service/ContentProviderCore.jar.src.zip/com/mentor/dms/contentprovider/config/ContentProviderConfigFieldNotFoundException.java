package com.mentor.dms.contentprovider.config;

public class ContentProviderConfigFieldNotFoundException extends ContentProviderConfigException {
  public ContentProviderConfigFieldNotFoundException() {}
  
  public ContentProviderConfigFieldNotFoundException(String paramString) {
    super(paramString);
  }
  
  public ContentProviderConfigFieldNotFoundException(Throwable paramThrowable) {
    super(paramThrowable);
  }
  
  public ContentProviderConfigFieldNotFoundException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\com\mentor\dms\contentprovider\config\ContentProviderConfigFieldNotFoundException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */