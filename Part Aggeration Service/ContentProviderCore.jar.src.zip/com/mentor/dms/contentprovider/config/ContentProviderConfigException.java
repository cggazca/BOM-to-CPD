package com.mentor.dms.contentprovider.config;

import com.mentor.dms.contentprovider.ContentProviderException;

public class ContentProviderConfigException extends ContentProviderException {
  public ContentProviderConfigException() {}
  
  public ContentProviderConfigException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ContentProviderConfigException(String paramString) {
    super(paramString);
  }
  
  public ContentProviderConfigException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\com\mentor\dms\contentprovider\config\ContentProviderConfigException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */