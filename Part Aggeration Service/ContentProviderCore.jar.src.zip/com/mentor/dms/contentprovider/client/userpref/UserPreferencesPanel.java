package com.mentor.dms.contentprovider.client.userpref;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;
import org.jdesktop.swingx.JXPanel;

public class UserPreferencesPanel extends JXPanel implements ActionListener {
  public UserPreferencesPanel() {
    setBorder(new EmptyBorder(5, 5, 5, 5));
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {}
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\com\mentor\dms\contentprovider\clien\\userpref\UserPreferencesPanel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */