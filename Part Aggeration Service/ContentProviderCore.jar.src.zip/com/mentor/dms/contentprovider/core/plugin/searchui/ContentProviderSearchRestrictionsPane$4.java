package com.mentor.dms.contentprovider.core.plugin.searchui;

import java.util.Comparator;

class null implements Comparator<TabOrder> {
  public int compare(TabOrder paramTabOrder1, TabOrder paramTabOrder2) {
    return paramTabOrder1.getMinDisposeOrder().compareTo(paramTabOrder2.getMinDisposeOrder());
  }
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\com\mentor\dms\contentprovider\core\plugin\searchui\ContentProviderSearchRestrictionsPane$4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */