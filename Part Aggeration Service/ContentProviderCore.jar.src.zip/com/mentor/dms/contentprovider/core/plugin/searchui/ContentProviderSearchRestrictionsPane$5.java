package com.mentor.dms.contentprovider.core.plugin.searchui;

import com.mentor.dms.ui.searchmask.SearchMask;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class null implements ActionListener {
  public void actionPerformed(ActionEvent paramActionEvent) {
    JSearchRestrictionCheckBox jSearchRestrictionCheckBox = (JSearchRestrictionCheckBox)paramActionEvent.getSource();
    try {
      SearchMask searchMask = ContentProviderSearchRestrictionsPane.this.searchPanel.getTargetSearchMask();
      searchMask.setSelected(jSearchRestrictionCheckBox.getOIField(), jSearchRestrictionCheckBox.isSelected());
    } catch (Exception exception) {}
  }
}


/* Location:              C:\Users\z004ut2y\OneDrive - Siemens AG\Documents\01_Projects\Customers\Var Industries\varindustries_edm-eles-sample-dataset_2025-09-18_1349 (1)\Part Aggeration Service\ContentProviderCore.jar!\com\mentor\dms\contentprovider\core\plugin\searchui\ContentProviderSearchRestrictionsPane$5.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */